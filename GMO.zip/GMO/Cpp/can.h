#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>

class CANInterface {
public:
    explicit CANInterface(CAN_HandleTypeDef* hcan);

    bool init();
    bool receiveCommand(uint8_t& out_cmd_id, float& out_payload);

    // Gói 0x102: Status
    bool sendStatus(uint8_t state, uint8_t flags, float rpm, float vq, uint16_t raw_counts);

    // Gói 0x104: LUT
    bool sendLUTPoint(uint8_t index, float lut_val);

    // Gói 0x105: Truyền cả Ia, Ib, Id, Iq để quan sát đầy đủ trên máy tính
    bool sendCurrents(float ia, float ib, float id, float iq);

private:
    CAN_HandleTypeDef* hcan_;
};
