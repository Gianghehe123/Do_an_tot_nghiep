#include "main_cpp.h"
#include "stm32f4xx_hal.h"
#include "main.h"
#include "as5047p.h"
#include "can.h"
#include <algorithm>
#include <cmath>
#include <cstring>

extern SPI_HandleTypeDef hspi1;
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

static constexpr int SAMPLES_PER_POLE = 60;
static constexpr int TOTAL_SAMPLES    = 21 * SAMPLES_PER_POLE;
static float s_fwd_err[TOTAL_SAMPLES];
static float s_bwd_err[TOTAL_SAMPLES];
static float s_avg_err[TOTAL_SAMPLES];
static float s_lut[AS5047P::LUT_SIZE];

static AS5047P encoder(&hspi1, GPIOA, GPIO_PIN_15, 21);
static CANInterface can(&hcan1);

enum class MotorState : uint8_t {
    IDLE = 0,
    CALIBRATING = 1,
    RUNNING = 2,
    COLLISION_STOP = 3,
    ERROR = 4
};

enum class ControlMode : uint8_t {
    SPEED = 0,
    TORQUE = 1
};

static volatile MotorState g_state = MotorState::IDLE;
static ControlMode g_ctrl_mode = ControlMode::SPEED;

static bool  g_use_lut = true;
static bool  g_enable_fw = false;

static constexpr float CURRENT_SCALE = 0.16117f;

static float g_offset_b = 2048.0f;
static float g_offset_c = 2048.0f;

// Giới hạn an toàn
static constexpr float CURRENT_LIMIT = 2.2f;   // 2.2A đủ khỏe để vượt ngưỡng GMO
static constexpr float VOLTAGE_LIMIT = 8.0f;   // 8.0V chống sốc dòng
static constexpr float V_BUS         = 24.0f;

// Dòng điện
static float g_ia = 0.0f;
static float g_ib = 0.0f;
static float g_ic = 0.0f;
static float g_id_raw = 0.0f;
static float g_iq_raw = 0.0f;
static float g_id_filt = 0.0f;
static float g_iq_filt = 0.0f;

// Lọc sâu cho Telemetry phẳng lì
static float g_id_telemetry = 0.0f;
static float g_iq_telemetry = 0.0f;

// -----------------------------------------------------------------------------
// BỘ ƯỚC LƯỢNG VẬN TỐC 16-SAMPLE MOVING AVERAGE CHUẨN MIT (Trang 40)
// Giải quyết triệt để lỗi giật cục 50ms trong as5047p.cpp cũ
// -----------------------------------------------------------------------------
static constexpr int VEL_BUF_SIZE = 16;
static bool     s_vel_first_run = true;
static uint16_t s_prev_raw_cnt = 0;
static int64_t  s_total_counts = 0;
static int64_t  s_count_hist[VEL_BUF_SIZE]{0};
static uint8_t  s_hist_idx = 0;
static float    g_multi_turn_rad = 0.0f;
static float    g_vel_rad_s = 0.0f;
static float    g_vel_rpm = 0.0f;

static void updateFastVelocity5kHz() {
    uint16_t raw = encoder.getRawCounts();
    if (s_vel_first_run) {
        s_prev_raw_cnt = raw;
        s_total_counts = raw;
        for (int i = 0; i < VEL_BUF_SIZE; ++i) s_count_hist[i] = s_total_counts;
        s_vel_first_run = false;
    }

    int16_t d_cnt = static_cast<int16_t>(raw - s_prev_raw_cnt);
    if (d_cnt > 8192)  d_cnt -= 16384;
    if (d_cnt < -8192) d_cnt += 16384;
    s_prev_raw_cnt = raw;
    s_total_counts += d_cnt;

    g_multi_turn_rad = (static_cast<float>(s_total_counts) / 16384.0f) * (2.0f * M_PI);

    int64_t oldest = s_count_hist[s_hist_idx];
    s_count_hist[s_hist_idx] = s_total_counts;
    s_hist_idx = (s_hist_idx + 1) & (VEL_BUF_SIZE - 1);

    // Cửa sổ 16 mẫu ở 5 kHz = 16 * 0.0002s = 0.0032s
    float diff_turns = static_cast<float>(s_total_counts - oldest) / 16384.0f;
    float inst_rad_s = (diff_turns * 2.0f * M_PI) / (16.0f * 0.0002f);

    g_vel_rad_s += 0.15f * (inst_rad_s - g_vel_rad_s);
    g_vel_rpm = g_vel_rad_s * (60.0f / (2.0f * M_PI));

    if (std::abs(g_vel_rpm) < 0.25f) {
        g_vel_rpm = 0.0f;
        g_vel_rad_s = 0.0f;
    }
}

// Mục tiêu điều khiển
static float g_target_rpm = 0.0f;
static float g_ramped_rpm = 0.0f;
static float g_target_iq_cmd = 0.0f;

static float g_id_target = 0.0f;
static float g_iq_target = 0.0f;
static float g_ud = 0.0f;
static float g_uq = 0.0f;

static float g_id_integral = 0.0f;
static float g_iq_integral = 0.0f;

// Thông số PI rời rạc chuẩn MIT Appendix C
static constexpr float MIT_K_GAIN   = 0.60f;
static constexpr float MIT_K_KI     = 0.030f;
static constexpr float MOTOR_L      = 0.00018f;
static constexpr float LPF_ALPHA    = 0.12f;

// Thông số GMO & Va chạm
static constexpr float GMO_KT       = 0.0955f;
static constexpr float GMO_J        = 0.00018f;
static constexpr float GMO_B        = 0.00008f;
static constexpr float GMO_COULOMB  = 0.0150f;
static constexpr float GMO_KO       = 25.0f;
static constexpr float GMO_THRESH   = 0.035f;

static float    s_gmo_integral = 0.0f;
static float    s_p_0 = 0.0f;
static float    s_tau_ext_est = 0.0f;
static uint32_t g_collision_start_tick = 0;
static uint8_t  g_countdown_sec = 0;
static uint32_t g_run_start_tick = 0;

// -----------------------------------------------------------------------------
// HÀM TRUYỀN THÔNG CAN NỘI BỘ
// -----------------------------------------------------------------------------
struct MITCommandLocal {
    float p_des;
    float v_des;
    float kp;
    float kd;
    float t_ff;
};

static int float_to_uint(float x, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    x = std::max(x_min, std::min(x, x_max));
    return static_cast<int>((x - x_min) * (static_cast<float>((1 << bits) - 1)) / span);
}

static float uint_to_float(int x_int, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    return static_cast<float>(x_int) * span / static_cast<float>((1 << bits) - 1) + x_min;
}

static bool sendGMOPacket(float tau_ext, float tau_thresh, uint8_t collision_flag, uint8_t countdown_sec) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x106;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    int16_t tau_ext_mnm    = static_cast<int16_t>(tau_ext * 1000.0f);
    int16_t tau_thresh_mnm = static_cast<int16_t>(tau_thresh * 1000.0f);

    std::memcpy(&tx_data[0], &tau_ext_mnm, sizeof(int16_t));
    std::memcpy(&tx_data[2], &tau_thresh_mnm, sizeof(int16_t));
    tx_data[4] = collision_flag;
    tx_data[5] = countdown_sec;
    tx_data[6] = 0;
    tx_data[7] = 0;

    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0) {
        return (HAL_CAN_AddTxMessage(&hcan1, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

static bool sendMITReplyPacket(uint8_t motor_id, float pos_rad, float vel_rad_s, float torque_nm) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[6];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x002;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 6;
    tx_header.TransmitGlobalTime = DISABLE;

    int p_int = float_to_uint(pos_rad, -12.5f, 12.5f, 16);
    int v_int = float_to_uint(vel_rad_s, -45.0f, 45.0f, 12);
    int t_int = float_to_uint(torque_nm, -2.0f, 2.0f, 12);

    tx_data[0] = motor_id;
    tx_data[1] = p_int >> 8;
    tx_data[2] = p_int & 0xFF;
    tx_data[3] = v_int >> 4;
    tx_data[4] = ((v_int & 0x0F) << 4) | (t_int >> 8);
    tx_data[5] = t_int & 0xFF;

    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0) {
        return (HAL_CAN_AddTxMessage(&hcan1, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

static bool pollCANMessages(uint32_t& out_std_id, uint8_t& out_cmd_id, float& out_payload, MITCommandLocal& out_mit) {
    if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) > 0) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];

        if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK) {
            if (rx_header.IDE == CAN_ID_STD) {
                out_std_id = rx_header.StdId;
                if (rx_header.StdId == 0x001 && rx_header.DLC == 8) {
                    int p_int  = (rx_data[0] << 8) | rx_data[1];
                    int v_int  = (rx_data[2] << 4) | (rx_data[3] >> 4);
                    int kp_int = ((rx_data[3] & 0x0F) << 8) | rx_data[4];
                    int kd_int = (rx_data[5] << 4) | (rx_data[6] >> 4);
                    int t_int  = ((rx_data[6] & 0x0F) << 8) | rx_data[7];

                    out_mit.p_des = uint_to_float(p_int, -12.5f, 12.5f, 16);
                    out_mit.v_des = uint_to_float(v_int, -45.0f, 45.0f, 12);
                    out_mit.kp    = uint_to_float(kp_int, 0.0f, 500.0f, 12);
                    out_mit.kd    = uint_to_float(kd_int, 0.0f, 5.0f, 12);
                    out_mit.t_ff  = uint_to_float(t_int, -2.0f, 2.0f, 12);
                    return true;
                } else if (rx_header.StdId == 0x100 && rx_header.DLC >= 1) {
                    out_cmd_id = rx_data[0];
                    if (rx_header.DLC >= 5) {
                        std::memcpy(&out_payload, &rx_data[1], sizeof(float));
                    } else {
                        out_payload = 0.0f;
                    }
                    return true;
                }
            }
        }
    }
    return false;
}

static void setPWMDuty(float duty_u, float duty_v, float duty_w) {
    duty_u = std::max(0.02f, std::min(duty_u, 0.98f));
    duty_v = std::max(0.02f, std::min(duty_v, 0.98f));
    duty_w = std::max(0.02f, std::min(duty_w, 0.98f));

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(&htim1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, static_cast<uint32_t>(duty_u * arr));
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, static_cast<uint32_t>(duty_v * arr));
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, static_cast<uint32_t>(duty_w * arr));
}

static void resetDRV8301Gate() {
    setPWMDuty(0.5f, 0.5f, 0.5f);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
    HAL_Delay(50);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
    HAL_Delay(800);
}

static void applySVPWM(float vd, float vq, float theta_e) {
    float cos_th = std::cos(theta_e);
    float sin_th = std::sin(theta_e);
    float v_alpha = vd * cos_th - vq * sin_th;
    float v_beta  = vd * sin_th + vq * cos_th;

    float v_a = v_alpha;
    float v_b = -0.5f * v_alpha + 0.8660254f * v_beta;
    float v_c = -0.5f * v_alpha - 0.8660254f * v_beta;

    float v_min = std::min({v_a, v_b, v_c});
    float v_max = std::max({v_a, v_b, v_c});
    float v_center = 0.5f * (v_max + v_min);

    float duty_u = (v_a - v_center) / V_BUS + 0.5f;
    float duty_v = (v_b - v_center) / V_BUS + 0.5f;
    float duty_w = (v_c - v_center) / V_BUS + 0.5f;

    setPWMDuty(duty_u, duty_v, duty_w);
}

// -----------------------------------------------------------------------------
// VÒNG ĐIỀU KHIỂN FOC 5 kHz
// -----------------------------------------------------------------------------
extern "C" void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if (hadc->Instance == ADC1) {
        uint16_t raw_b = ADC1->JDR1;
        uint16_t raw_c = ADC2->JDR1;

        if (g_state == MotorState::CALIBRATING) {
            return;
        }

        static uint8_t prescaler = 0;
        static uint32_t acc_b = 0;
        static uint32_t acc_c = 0;

        acc_b += raw_b;
        acc_c += raw_c;
        prescaler++;

        if (prescaler < 4) {
            return;
        }

        float sample_b = static_cast<float>(acc_b) * 0.25f;
        float sample_c = static_cast<float>(acc_c) * 0.25f;
        prescaler = 0;
        acc_b = 0;
        acc_c = 0;

        if (g_state == MotorState::IDLE || g_state == MotorState::COLLISION_STOP) {
            constexpr float AUTO_ZERO_ALPHA = 0.005f;
            g_offset_b += AUTO_ZERO_ALPHA * (sample_b - g_offset_b);
            g_offset_c += AUTO_ZERO_ALPHA * (sample_c - g_offset_c);

            g_id_integral = 0.0f;
            g_iq_integral = 0.0f;
            g_ud = 0.0f;
            g_uq = 0.0f;
            setPWMDuty(0.5f, 0.5f, 0.5f);
        }

        g_ib = (sample_b - g_offset_b) * CURRENT_SCALE;
        g_ic = (sample_c - g_offset_c) * CURRENT_SCALE;
        g_ia = -(g_ib + g_ic);

        // Gọi hàm update() chuẩn (không tham số) và tính vận tốc 16-sample ở 5 kHz
        encoder.update();
        updateFastVelocity5kHz();

        float theta_e = (g_use_lut && encoder.isCalibrated()) ? encoder.getCalibElecRad() : encoder.getRawElecRad();

        float i_alpha = g_ia;
        float i_beta  = 0.57735027f * (g_ib - g_ic);

        float cos_th = std::cos(theta_e);
        float sin_th = std::sin(theta_e);
        g_id_raw =  i_alpha * cos_th + i_beta * sin_th;
        g_iq_raw = -i_alpha * sin_th + i_beta * cos_th;

        g_id_filt += LPF_ALPHA * (g_id_raw - g_id_filt);
        g_iq_filt += LPF_ALPHA * (g_iq_raw - g_iq_filt);

        g_id_telemetry += 0.03f * (g_id_filt - g_id_telemetry);
        g_iq_telemetry += 0.03f * (g_iq_filt - g_iq_telemetry);

        if (g_state == MotorState::RUNNING) {
            if (g_enable_fw) {
                float abs_rpm = std::abs(g_vel_rpm);
                if (abs_rpm > 120.0f) {
                    g_id_target = -std::min(0.8f, (abs_rpm - 120.0f) * 0.015f);
                } else {
                    g_id_target = 0.0f;
                }
            } else {
                g_id_target = 0.0f;
            }

            float lim_id = std::max(-CURRENT_LIMIT, std::min(g_id_target, CURRENT_LIMIT));
            float lim_iq = std::max(-CURRENT_LIMIT, std::min(g_iq_target, CURRENT_LIMIT));

            float omega_e = g_vel_rad_s * 21.0f;

            // PI Trục D
            float err_d = lim_id - g_id_filt;
            g_id_integral += MIT_K_KI * err_d;
            g_id_integral = std::max(-VOLTAGE_LIMIT, std::min(g_id_integral, VOLTAGE_LIMIT));
            float v_decouple_d = -omega_e * MOTOR_L * g_iq_filt;
            g_ud = MIT_K_GAIN * err_d + g_id_integral + v_decouple_d;
            g_ud = std::max(-VOLTAGE_LIMIT, std::min(g_ud, VOLTAGE_LIMIT));

            // PI Trục Q
            float err_q = lim_iq - g_iq_filt;
            g_iq_integral += MIT_K_KI * err_q;
            g_iq_integral = std::max(-VOLTAGE_LIMIT, std::min(g_iq_integral, VOLTAGE_LIMIT));
            float v_decouple_q = omega_e * MOTOR_L * g_id_filt;
            g_uq = MIT_K_GAIN * err_q + g_iq_integral + v_decouple_q;
            g_uq = std::max(-VOLTAGE_LIMIT, std::min(g_uq, VOLTAGE_LIMIT));

            applySVPWM(g_ud, g_uq, theta_e);
        }
    }
}

// -----------------------------------------------------------------------------
// BỘ QUAN SÁT ĐỘNG LƯỢNG TỔNG QUÁT GMO (1 kHz)
// -----------------------------------------------------------------------------
static void updateGMO(float dt_sec) {
    float omega_m = g_vel_rad_s;
    float p_current = GMO_J * omega_m;
    float tau_e = GMO_KT * g_iq_telemetry;

    float tau_friction = GMO_B * omega_m;
    if (omega_m > 0.3f) {
        tau_friction += GMO_COULOMB + 0.04f * std::abs(tau_e);
    } else if (omega_m < -0.3f) {
        tau_friction -= (GMO_COULOMB + 0.04f * std::abs(tau_e));
    } else {
        if (tau_e > GMO_COULOMB)       tau_friction = GMO_COULOMB;
        else if (tau_e < -GMO_COULOMB) tau_friction = -GMO_COULOMB;
        else                           tau_friction = tau_e;
    }

    if (g_state == MotorState::RUNNING) {
        s_gmo_integral += dt_sec * (tau_e - tau_friction - s_tau_ext_est);
        s_tau_ext_est = GMO_KO * (s_gmo_integral - (p_current - s_p_0));

        if (HAL_GetTick() - g_run_start_tick > 600) {
            if (std::abs(s_tau_ext_est) > GMO_THRESH) {
                g_state = MotorState::COLLISION_STOP;
                g_collision_start_tick = HAL_GetTick();
                g_iq_target = 0.0f;
            }
        }
    } else {
        s_gmo_integral = 0.0f;
        s_p_0 = p_current;
        s_tau_ext_est = 0.0f;
    }
}

static void runCalibration() {
    g_state = MotorState::CALIBRATING;
    resetDRV8301Gate();
    HAL_Delay(100);

    uint32_t sum_b = 0, sum_c = 0;
    for (int i = 0; i < 1024; ++i) {
        sum_b += ADC1->JDR1;
        sum_c += ADC2->JDR1;
        HAL_Delay(1);
    }
    g_offset_b = static_cast<float>(sum_b) / 1024.0f;
    g_offset_c = static_cast<float>(sum_c) / 1024.0f;

    const float v_calib = 1.4f;
    applySVPWM(v_calib, 0.0f, 0.0f);
    HAL_Delay(700);

    encoder.update();
    uint16_t prev_raw = encoder.getRawCounts();
    int32_t cum_raw = prev_raw;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float mech_ref = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        applySVPWM(v_calib, 0.0f, mech_ref * 21.0f);
        HAL_Delay(4);

        encoder.update();
        uint16_t cur_raw = encoder.getRawCounts();
        int32_t d_raw = static_cast<int32_t>(cur_raw) - static_cast<int32_t>(prev_raw);
        if (d_raw > 8192)  d_raw -= 16384;
        if (d_raw < -8192) d_raw += 16384;
        prev_raw = cur_raw;
        cum_raw += d_raw;

        float unwrapped_meas = (static_cast<float>(cum_raw) / 16384.0f) * (2.0f * M_PI);
        s_fwd_err[i] = unwrapped_meas - mech_ref;
    }

    for (int i = TOTAL_SAMPLES - 1; i >= 0; --i) {
        float mech_ref = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        applySVPWM(v_calib, 0.0f, mech_ref * 21.0f);
        HAL_Delay(4);

        encoder.update();
        uint16_t cur_raw = encoder.getRawCounts();
        int32_t d_raw = static_cast<int32_t>(cur_raw) - static_cast<int32_t>(prev_raw);
        if (d_raw > 8192)  d_raw -= 16384;
        if (d_raw < -8192) d_raw += 16384;
        prev_raw = cur_raw;
        cum_raw += d_raw;

        float unwrapped_meas = (static_cast<float>(cum_raw) / 16384.0f) * (2.0f * M_PI);
        s_bwd_err[i] = unwrapped_meas - mech_ref;
    }

    setPWMDuty(0.5f, 0.5f, 0.5f);

    double sum_zero = 0.0;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        s_avg_err[i] = 0.5f * (s_fwd_err[i] + s_bwd_err[i]);
        sum_zero += s_avg_err[i];
    }
    float zero_offset = static_cast<float>(sum_zero / TOTAL_SAMPLES);
    while (zero_offset >= 2.0f * M_PI) zero_offset -= 2.0f * M_PI;
    while (zero_offset < 0.0f)        zero_offset += 2.0f * M_PI;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) s_avg_err[i] -= zero_offset;

    const int window = SAMPLES_PER_POLE;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float sum_win = 0.0f;
        for (int w = -window / 2; w < window / 2; ++w) {
            int idx = (i + w + TOTAL_SAMPLES) % TOTAL_SAMPLES;
            sum_win += s_avg_err[idx];
        }
        s_fwd_err[i] = sum_win / static_cast<float>(window);
    }

    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) {
        int sample_idx = (i * TOTAL_SAMPLES) / AS5047P::LUT_SIZE;
        s_lut[i] = -s_fwd_err[sample_idx];
        can.sendLUTPoint(static_cast<uint8_t>(i), s_lut[i]);
        HAL_Delay(3);
    }

    encoder.setLUT(s_lut, zero_offset);
    g_use_lut = true;
    g_state = MotorState::IDLE;
}

void run_loop(void) {

	resetDRV8301Gate();
    can.init();

    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    setPWMDuty(0.5f, 0.5f, 0.5f);
    encoder.init();

    HAL_ADCEx_InjectedStart(&hadc2);
    HAL_ADCEx_InjectedStart_IT(&hadc1);

    uint32_t last_1khz_tick = 0;
    uint32_t last_telem_tick = 0;
    uint8_t  telem_slot = 0;

    uint32_t rx_std_id = 0;
    uint8_t  cmd_id = 0;
    float    cmd_payload = 0.0f;
    MITCommandLocal mit_cmd{};
    float    vel_integral = 0.0f;

    while (1) {
        uint32_t current_tick = HAL_GetTick();

        // 1. VẾT SẠCH HÀNG ĐỢI LỆNH CAN
        while (pollCANMessages(rx_std_id, cmd_id, cmd_payload, mit_cmd)) {
            if (rx_std_id == 0x001) {
                float pos_err = mit_cmd.p_des - g_multi_turn_rad;
                float vel_err = mit_cmd.v_des - g_vel_rad_s;
                float total_torque = mit_cmd.kp * pos_err + mit_cmd.kd * vel_err + mit_cmd.t_ff;

                g_ctrl_mode = ControlMode::TORQUE;
                g_target_iq_cmd = total_torque / GMO_KT;
                if (std::abs(g_target_iq_cmd) > 0.02f || mit_cmd.kp > 0.01f || mit_cmd.kd > 0.01f) {
                    if (g_state == MotorState::IDLE) g_run_start_tick = current_tick;
                    if (g_state != MotorState::COLLISION_STOP) g_state = MotorState::RUNNING;
                } else {
                    g_state = MotorState::IDLE;
                }
                sendMITReplyPacket(1, g_multi_turn_rad, g_vel_rad_s, g_iq_telemetry * GMO_KT);
            } else if (rx_std_id == 0x100) {
                switch (cmd_id) {
                    case 0x01: // Stop + Mở khóa lại DRV8301
                        g_state = MotorState::IDLE;
                        g_iq_target = 0.0f;
                        g_target_rpm = 0.0f;
                        g_target_iq_cmd = 0.0f;
                        vel_integral = 0.0f;
                        resetDRV8301Gate();
                        break;
                    case 0x02: // Arm
                        resetDRV8301Gate();
                        g_state = MotorState::RUNNING;
                        g_run_start_tick = current_tick;
                        break;
                    case 0x03: // Set Iq (Torque Mode)
                        g_ctrl_mode = ControlMode::TORQUE;
                        g_target_iq_cmd = cmd_payload;
                        if (std::abs(cmd_payload) > 0.02f) {
                            if (g_state == MotorState::IDLE) g_run_start_tick = current_tick;
                            if (g_state != MotorState::COLLISION_STOP) g_state = MotorState::RUNNING;
                        } else {
                            g_state = MotorState::IDLE;
                        }
                        break;
                    case 0x04: // Calib
                        runCalibration();
                        break;
                    case 0x05: // Toggle LUT
                        g_use_lut = (cmd_payload > 0.5f);
                        break;
                    case 0x06: // Toggle FW
                        g_enable_fw = (cmd_payload > 0.5f);
                        break;
                    case 0x07: // Set RPM (Speed Mode)
                        g_ctrl_mode = ControlMode::SPEED;
                        g_target_rpm = cmd_payload;
                        if (std::abs(cmd_payload) > 0.5f) {
                            if (g_state == MotorState::IDLE) {
                                g_run_start_tick = current_tick;
                                g_ramped_rpm = g_vel_rpm;
                            }
                            if (g_state != MotorState::COLLISION_STOP) g_state = MotorState::RUNNING;
                        } else {
                            g_state = MotorState::IDLE;
                        }
                        break;
                    default: break;
                }
            }
        }

        // 2. VÒNG LẶP 1 kHz: ĐIỀU KHIỂN VẬN TỐC & GMO
        if (current_tick - last_1khz_tick >= 1) {
            last_1khz_tick = current_tick;

            if (g_state == MotorState::COLLISION_STOP) {
                uint32_t elapsed = current_tick - g_collision_start_tick;
                if (elapsed < 5000) {
                    g_countdown_sec = static_cast<uint8_t>((5000 - elapsed) / 1000 + 1);
                } else {
                    g_countdown_sec = 0;
                    resetDRV8301Gate();
                    g_state = MotorState::RUNNING;
                    g_run_start_tick = current_tick;
                    g_ramped_rpm = g_vel_rpm;
                    vel_integral = 0.0f;
                    s_gmo_integral = 0.0f;
                    s_p_0 = GMO_J * g_vel_rad_s;
                    s_tau_ext_est = 0.0f;
                }
            } else {
                g_countdown_sec = 0;
            }

            if (g_state == MotorState::RUNNING) {
                if (g_ctrl_mode == ControlMode::SPEED) {
                    float actual_rpm = g_vel_rpm;
                    float ramp_step = 200.0f * 0.001f;
                    if (g_ramped_rpm < g_target_rpm) g_ramped_rpm = std::min(g_ramped_rpm + ramp_step, g_target_rpm);
                    else if (g_ramped_rpm > g_target_rpm) g_ramped_rpm = std::max(g_ramped_rpm - ramp_step, g_target_rpm);

                    float vel_err = g_ramped_rpm - actual_rpm;
                    vel_integral += 0.04f * vel_err * 0.001f;
                    vel_integral = std::max(-1.2f, std::min(vel_integral, 1.2f));

                    float iq_ff = (g_ramped_rpm / 100.0f) * 0.18f;
                    g_iq_target = iq_ff + (0.020f * vel_err) + vel_integral;
                    g_iq_target = std::max(-CURRENT_LIMIT, std::min(g_iq_target, CURRENT_LIMIT));
                } else {
                    g_iq_target = std::max(-CURRENT_LIMIT, std::min(g_target_iq_cmd, CURRENT_LIMIT));
                }
            } else {
                g_iq_target = 0.0f;
                vel_integral = 0.0f;
            }

            updateGMO(0.001f);
        }

        // 3. CHIA PHA GỬI TELEMETRY (Mỗi 15ms gửi 1 gói chống nghẽn cổ chai)
        if (current_tick - last_telem_tick >= 15) {
            last_telem_tick = current_tick;

            if (telem_slot == 0) {
                can.sendCurrents(g_ia, g_ib, g_id_telemetry, g_iq_telemetry);
                telem_slot = 1;
            } else if (telem_slot == 1) {
                uint8_t is_collided = (g_state == MotorState::COLLISION_STOP) ? 1 : 0;
                sendGMOPacket(s_tau_ext_est, GMO_THRESH, is_collided, g_countdown_sec);
                telem_slot = 2;
            } else {
                uint8_t flags = (g_use_lut ? 0x01 : 0x00) |
                                (g_enable_fw ? 0x02 : 0x00) |
                                (g_ctrl_mode == ControlMode::TORQUE ? 0x04 : 0x00);
                can.sendStatus(static_cast<uint8_t>(g_state), flags,
                               g_vel_rpm, g_uq, encoder.getRawCounts());
                telem_slot = 0;
            }
        }
    }
}
