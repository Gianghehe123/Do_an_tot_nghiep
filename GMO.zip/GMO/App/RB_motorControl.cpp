// App/RB_motorControl.cpp
#include "device.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* ============ EXTERNAL HAL HANDLES ============ */
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;

/* ============ COMPONENTS ============ */
AS5047P encoder(&hspi1, __ENC_SPI_PORT, __ENC_SPI_CS_PIN, __MOT_POLE_PAIRS);

DRV8301Driver driver(&htim1, __DRV_EN_GATE_PORT, __DRV_EN_GATE_PIN,
                     __V_BUS_VOLTS, __PWM_MIN_DUTY_RATIO, __PWM_MAX_DUTY_RATIO);

CurrentSensorInjected currentSensor(&hadc1, &hadc2,
                                    __ADC_CURRENT_SCALE_A_LSB,
                                    __ADC_OVERSAMPLE_COUNT,
                                    PhaseExclusion::EXCLUDE_PHASE_A);

LowpassFilter LPF_Id(__LPF_CURRENT_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Iq(__LPF_CURRENT_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Id_Telem(__LPF_TELEM_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Iq_Telem(__LPF_TELEM_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);

LowpassFilter LPF_vel(__LPF_VELOCITY_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
//KalmanFilter  KF_vel(__KALMAN_VEL_MEA_ERR, __KALMAN_VEL_EST_ERR, __KALMAN_VEL_PROC_NOISE);

Motor motor(__MOT_POLE_PAIRS, __MOT_INDUCTANCE_H, __VEL_LOOP_FREQ_KHZ);

static float s_gmoIntegral    = 0.0f;
static float s_p0             = 0.0f;
static u08   s_gmoDownsampler = 0;

static constexpr int SAMPLES_PER_POLE = 60;
static constexpr int TOTAL_SAMPLES    = __MOT_POLE_PAIRS * SAMPLES_PER_POLE;
static float s_fwdErr[TOTAL_SAMPLES];
static float s_bwdErr[TOTAL_SAMPLES];
static float s_avgErr[TOTAL_SAMPLES];
static float s_lut[AS5047P::LUT_SIZE];

/* ============ FUNCTIONS ============ */
void RB_initMotor()
{
    dev.motor         = &motor;
    dev.encoder       = &encoder;
    dev.currentSensor = &currentSensor;
    dev.driver        = &driver;

    // 1. Khởi tạo Gate Driver (Reset DRV8301, bật TIM1 CH1..3 + CH1N..3N, đặt duty 50%)
    driver.init();

    // 2. Bật TIM1_CH4 để phát xung trigger cho ADC Injected (trước khi bật ADC như main_cpp.cpp)
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    // 3. Khởi tạo Encoder AS5047P
    encoder.init();

    // 4. Bật ADC2 và ADC1 Injected (_IT)
    currentSensor.init();

    // 5. Hiệu chỉnh offset ADC (1024 mẫu khi CHƯA cấp dòng)
    currentSensor.calibrate(__ADC_CALIB_SAMPLES);
    while (!currentSensor.isCalibrationComplete()) {}

    // 6. Nối các object phần cứng và bộ lọc vào lõi Motor
    motor.appendDriver(&driver);
    motor.appendSensor(&encoder);
    motor.appendCurrentSensor(&currentSensor);
    motor.appendCurrentFilters(&LPF_Id, &LPF_Iq);
    motor.appendVelocityFilter(&LPF_vel, nullptr);
    motor.init();

    // 7 & 8. Cấu hình chế độ khởi động an toàn (DISABLED)
    motor.modulationType = ModulationType::FOC;
    motor.setControlType(ControlType::DISABLED);

    // 9. Nạp hệ số PID và giới hạn từ systemConfig.h
    motor.limitCurrent          = __CURRENT_LIMIT_AMPS;
    motor.limitVoltage          = __VOLTAGE_LIMIT_VOLTS;
    motor.velRampRate_RPM_per_s = __MOT_VEL_RAMP_RPM_PER_S;

    motor.pid_Id.kp    = __MOT_CURRENT_PID_KP;
    motor.pid_Id.ki    = __MOT_CURRENT_PID_KI;
    motor.pid_Id.limit = __VOLTAGE_LIMIT_VOLTS;

    motor.pid_Iq.kp    = __MOT_CURRENT_PID_KP;
    motor.pid_Iq.ki    = __MOT_CURRENT_PID_KI;
    motor.pid_Iq.limit = __VOLTAGE_LIMIT_VOLTS;

    motor.pid_velocity.kp    = __MOT_VEL_PID_KP;
    motor.pid_velocity.ki    = __MOT_VEL_PID_KI;
    motor.pid_velocity.limit = __MOT_VEL_INTEGRAL_LIM_AMPS;

    dev.state = SystemState::IDLE;
}

void RB_startControlClock()
{
    dev.controlLoopEnabled = true;
}

void RB_stopControlClock()
{
    dev.controlLoopEnabled = false;
    driver.setDutyCycle(0.5f, 0.5f, 0.5f);
}

void RB_updateMotor(u08 callbackFreq_kHz)
{
    if (!dev.controlLoopEnabled || dev.state == SystemState::CALIBRATING) return;

    motor.updateFOC(callbackFreq_kHz);
    motor.updateVelocity(callbackFreq_kHz);

    dev.idTelemetry = LPF_Id_Telem.update(motor.getId());
    dev.iqTelemetry = LPF_Iq_Telem.update(motor.getIq());
}

void RB_observeCollision(u08 callbackFreq_kHz)
{
    if (!dev.controlLoopEnabled || dev.state == SystemState::CALIBRATING) return;

    u08 ratio = callbackFreq_kHz / __GMO_LOOP_FREQ_KHZ;
    if (ratio == 0) ratio = 1;
    if (++s_gmoDownsampler < ratio) return;
    s_gmoDownsampler = 0;

    float dt_sec   = 1.0f / (static_cast<float>(__GMO_LOOP_FREQ_KHZ) * 1000.0f);
    float omega_m  = motor.getVelocityRadS();
    float pCurrent = __GMO_INERTIA_J * omega_m;
    float tau_e    = __GMO_KT_NM_PER_AMP * dev.iqTelemetry;

    float tauFriction = __GMO_VISCOUS_B * omega_m;
    if (omega_m > 0.3f) {
        tauFriction += __GMO_COULOMB_NM + 0.04f * std::abs(tau_e);
    } else if (omega_m < -0.3f) {
        tauFriction -= (__GMO_COULOMB_NM + 0.04f * std::abs(tau_e));
    } else {
        if (tau_e > __GMO_COULOMB_NM)       tauFriction = __GMO_COULOMB_NM;
        else if (tau_e < -__GMO_COULOMB_NM) tauFriction = -__GMO_COULOMB_NM;
        else                                tauFriction = tau_e;
    }

    if (dev.state == SystemState::RUNNING) {
        s_gmoIntegral += dt_sec * (tau_e - tauFriction - dev.tauExtEst_Nm);
        dev.tauExtEst_Nm = __GMO_GAIN_KO_RAD_S * (s_gmoIntegral - (pCurrent - s_p0));

        if (HAL_GetTick() - dev.runStartTick_ms > __GMO_HEADSTART_MS) {
            if (std::abs(dev.tauExtEst_Nm) > __GMO_THRESHOLD_NM) {
                dev.state = SystemState::COLLISION_STOP;
                dev.collisionStartTick_ms = HAL_GetTick();
                motor.setControlType(ControlType::DISABLED);
            }
        }
    } else {
        s_gmoIntegral    = 0.0f;
        s_p0             = pCurrent;
        dev.tauExtEst_Nm = 0.0f;
    }
}

void RB_runEncoderCalibrationBlocking()
{
    RB_stopControlClock();
    dev.state = SystemState::CALIBRATING;

    driver.resetGateBlocking();
    HAL_Delay(100);

    currentSensor.calibrate(__ADC_CALIB_SAMPLES);
    while (!currentSensor.isCalibrationComplete()) {}

    const float vCalib = 1.4f;
    motor.applyOpenLoopVoltage(vCalib, 0.0f, 0.0f);
    HAL_Delay(700);

    encoder.update();
    uint16_t prevRaw = encoder.getRawCounts();
    int32_t  cumRaw  = prevRaw;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float mechRef = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        motor.applyOpenLoopVoltage(vCalib, 0.0f, mechRef * __MOT_POLE_PAIRS);
        HAL_Delay(4);

        encoder.update();
        uint16_t curRaw = encoder.getRawCounts();
        int32_t  dRaw   = static_cast<int32_t>(curRaw) - static_cast<int32_t>(prevRaw);
        if (dRaw > 8192)  dRaw -= 16384;
        if (dRaw < -8192) dRaw += 16384;
        prevRaw = curRaw;
        cumRaw += dRaw;

        float unwrappedMeas = (static_cast<float>(cumRaw) / AS5047P::RESOLUTION) * (2.0f * M_PI);
        s_fwdErr[i] = unwrappedMeas - mechRef;
    }

    for (int i = TOTAL_SAMPLES - 1; i >= 0; --i) {
        float mechRef = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        motor.applyOpenLoopVoltage(vCalib, 0.0f, mechRef * __MOT_POLE_PAIRS);
        HAL_Delay(4);

        encoder.update();
        uint16_t curRaw = encoder.getRawCounts();
        int32_t  dRaw   = static_cast<int32_t>(curRaw) - static_cast<int32_t>(prevRaw);
        if (dRaw > 8192)  dRaw -= 16384;
        if (dRaw < -8192) dRaw += 16384;
        prevRaw = curRaw;
        cumRaw += dRaw;

        float unwrappedMeas = (static_cast<float>(cumRaw) / AS5047P::RESOLUTION) * (2.0f * M_PI);
        s_bwdErr[i] = unwrappedMeas - mechRef;
    }

    driver.setDutyCycle(0.5f, 0.5f, 0.5f);

    double sumZero = 0.0;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        s_avgErr[i] = 0.5f * (s_fwdErr[i] + s_bwdErr[i]);
        sumZero += s_avgErr[i];
    }
    float zeroOffset = static_cast<float>(sumZero / TOTAL_SAMPLES);
    while (zeroOffset >= 2.0f * M_PI) zeroOffset -= 2.0f * M_PI;
    while (zeroOffset < 0.0f)        zeroOffset += 2.0f * M_PI;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) s_avgErr[i] -= zeroOffset;

    const int window = SAMPLES_PER_POLE;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float sumWin = 0.0f;
        for (int w = -window / 2; w < window / 2; ++w) {
            int idx = (i + w + TOTAL_SAMPLES) % TOTAL_SAMPLES;
            sumWin += s_avgErr[idx];
        }
        s_fwdErr[i] = sumWin / static_cast<float>(window);
    }

    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) {
        int sampleIdx = (i * TOTAL_SAMPLES) / AS5047P::LUT_SIZE;
        s_lut[i] = -s_fwdErr[sampleIdx];
        if (dev.can != nullptr) {
            dev.can->sendLUTPoint(static_cast<uint8_t>(i), s_lut[i]);
        }
        HAL_Delay(3);
    }

    encoder.setLUT(s_lut, zeroOffset);
    motor.setUseLUT(true);
    motor.setControlType(ControlType::DISABLED);
    dev.state = SystemState::IDLE;
    RB_startControlClock();
}

/* ============ CALLBACKS ============ */
extern "C" void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance == currentSensor.getMasterADCInstance()) {
        // Chỉ khi gom đủ 4 mẫu ADC (tần số 5 kHz) mới chạy vòng FOC và GMO
        if (currentSensor.onConversionComplete_ISR()) {
            RB_updateMotor(__CTRL_LOOP_FREQ_KHZ);
            RB_observeCollision(__CTRL_LOOP_FREQ_KHZ);
        }
    }
}
