// App/device.h
#pragma once
#include "systemConfig.h"
#include "FOCLib/MotorController/motor.h"
#include "Libs/can.h"

enum class SystemState : uint8_t {
    IDLE           = 0,
    CALIBRATING    = 1,
    RUNNING        = 2,
    COLLISION_STOP = 3,
    ERROR          = 4
};

struct Device {
    Motor*                 motor{nullptr};
    AS5047P*               encoder{nullptr};
    CurrentSensorInjected* currentSensor{nullptr};
    DRV8301Driver*         driver{nullptr};
    CANInterface*          can{nullptr};

    volatile SystemState state{SystemState::IDLE};
    volatile bool        controlLoopEnabled{false};

    // Dữ liệu Telemetry & GMO dùng chung giữa ISR và loop()
    volatile float   idTelemetry{0.0f};
    volatile float   iqTelemetry{0.0f};
    volatile float   tauExtEst_Nm{0.0f};
    volatile uint32_t runStartTick_ms{0};
    volatile uint32_t collisionStartTick_ms{0};
    volatile uint8_t  countdown_sec{0};
};

inline Device dev;

/* ============ PROTOTYPES TẦNG 2 ============ */
void RB_initMotor();
void RB_startControlClock();
void RB_stopControlClock();
void RB_updateMotor(u08 callbackFreq_kHz);
void RB_observeCollision(u08 callbackFreq_kHz);
void RB_runEncoderCalibrationBlocking();
