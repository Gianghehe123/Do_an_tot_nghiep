// App/Libs/can.h
#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>

// Cấu trúc lệnh điều khiển vị trí/trở kháng chuẩn MIT (Gói 0x001)
struct MITCommand {
    float p_des{0.0f};
    float v_des{0.0f};
    float kp{0.0f};
    float kd{0.0f};
    float t_ff{0.0f};
};

class CANInterface {
public:
    explicit CANInterface(CAN_HandleTypeDef* hcan);

    bool init();

    // Đọc đồng thời cả gói lệnh 0x100 (GUI) và gói 0x001 (MIT Impedance Mode)
    bool pollMessages(uint32_t& out_std_id, uint8_t& out_cmd_id, float& out_payload, MITCommand& out_mit);

    // Gói 0x100 (hàm cũ giữ lại để tương thích ngược nếu chỉ đọc lệnh 0x100)
    bool receiveCommand(uint8_t& out_cmd_id, float& out_payload);

    // Gói 0x002: Phản hồi trạng thái chuẩn MIT (DLC = 6)
    bool sendMITReplyPacket(uint8_t motor_id, float pos_rad, float vel_rad_s, float torque_nm);

    // Gói 0x102: Trạng thái tổng quát (State, Flags, RPM, Vq, Raw Encoder Counts)
    bool sendStatus(uint8_t state, uint8_t flags, float rpm, float vq, uint16_t raw_counts);

    // Gói 0x104: Truyền từng điểm của bảng bù phi tuyến LUT 128 điểm lên máy tính
    bool sendLUTPoint(uint8_t index, float lut_val);

    // Gói 0x105: Truyền dòng điện Ia, Ib, Id, Iq (đơn vị mA)
    bool sendCurrents(float ia, float ib, float id, float iq);

    // Gói 0x106: Truyền thông số bộ quan sát va chạm GMO (tau_ext, tau_thresh, cờ va chạm, đếm ngược)
    bool sendGMOPacket(float tau_ext, float tau_thresh, uint8_t collision_flag, uint8_t countdown_sec);

private:
    CAN_HandleTypeDef* hcan_;

    static int   floatToUint(float x, float x_min, float x_max, int bits);
    static float uintToFloat(int x_int, float x_min, float x_max, int bits);
};
