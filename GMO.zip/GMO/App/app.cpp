// App/app.cpp
#include "app.h"
#include "device.h"
#include <cmath>

extern CAN_HandleTypeDef hcan1;
static CANInterface can(&hcan1);

void setup(void)
{
    dev.can = &can;
    can.init();

    // Khởi tạo driver, encoder, hiệu chỉnh offset ADC 1024 mẫu
    RB_initMotor();

    // Bật ngắt điều khiển sau cùng
    RB_startControlClock();
}

void loop(void)
{
    static uint32_t    lastTelemTick            = 0;
    static uint8_t     telemSlot                = 0;
    static ControlType savedModeBeforeCollision = ControlType::VELOCITY;
    static float       savedTargetRpm           = 0.0f;
    static float       savedTargetIq            = 0.0f;

    uint32_t currentTick = HAL_GetTick();

    // 1. Vét sạch hàng đợi lệnh CAN từ ESP32 gửi xuống
    uint32_t   rxStdId = 0;
    uint8_t    cmdId   = 0;
    float      payload = 0.0f;
    MITCommand mitCmd{};

    while (can.pollMessages(rxStdId, cmdId, payload, mitCmd)) {
        if (rxStdId == 0x001) {
            float posErr      = mitCmd.p_des - dev.motor->getMultiTurnRad();
            float velErr      = mitCmd.v_des - dev.motor->getVelocityRadS();
            float totalTorque = mitCmd.kp * posErr + mitCmd.kd * velErr + mitCmd.t_ff;
            float iqCmd       = totalTorque / __GMO_KT_NM_PER_AMP;

            savedModeBeforeCollision = ControlType::CURRENT;
            savedTargetIq            = iqCmd;

            if (std::abs(iqCmd) > 0.02f || mitCmd.kp > 0.01f || mitCmd.kd > 0.01f) {
                if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                if (dev.state != SystemState::COLLISION_STOP) {
                    dev.state = SystemState::RUNNING;
                    dev.motor->setControlType(ControlType::CURRENT);
                    dev.motor->setCurrent(iqCmd, 0.0f);
                }
            } else {
                dev.state = SystemState::IDLE;
                dev.motor->setControlType(ControlType::DISABLED);
            }
            can.sendMITReplyPacket(1, dev.motor->getMultiTurnRad(),
                                   dev.motor->getVelocityRadS(),
                                   dev.iqTelemetry * __GMO_KT_NM_PER_AMP);
        } else if (rxStdId == 0x100) {
            switch (cmdId) {
                case 0x01: // Stop + Mở khóa lại DRV8301
                    dev.state = SystemState::IDLE;
                    dev.motor->setControlType(ControlType::DISABLED);
                    savedTargetRpm = 0.0f;
                    savedTargetIq  = 0.0f;
                    dev.driver->resetGateBlocking();
                    break;
                case 0x02: // Arm
                    dev.driver->resetGateBlocking();
                    dev.runStartTick_ms = HAL_GetTick();
                    dev.state = SystemState::RUNNING;
                    dev.motor->setControlType(savedModeBeforeCollision);
                    if (savedModeBeforeCollision == ControlType::VELOCITY) {
                        dev.motor->setRPM(savedTargetRpm);
                    } else {
                        dev.motor->setCurrent(savedTargetIq, 0.0f);
                    }
                    break;
                case 0x03: // Set Iq (Torque/Current Mode)
                    savedModeBeforeCollision = ControlType::CURRENT;
                    savedTargetIq = payload;
                    if (std::abs(payload) > 0.02f) {
                        if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                        if (dev.state != SystemState::COLLISION_STOP) {
                            dev.state = SystemState::RUNNING;
                            dev.motor->setControlType(ControlType::CURRENT);
                            dev.motor->setCurrent(payload, 0.0f);
                        }
                    } else {
                        dev.state = SystemState::IDLE;
                        dev.motor->setControlType(ControlType::DISABLED);
                    }
                    break;
                case 0x04: // Calib LUT
                    RB_runEncoderCalibrationBlocking();
                    break;
                case 0x05: // Toggle LUT
                    dev.motor->setUseLUT(payload > 0.5f);
                    break;
                case 0x06: // Toggle Field Weakening
                    dev.motor->setFieldWeakening(payload > 0.5f);
                    break;
                case 0x07: // Set RPM (Speed Mode)
                    savedModeBeforeCollision = ControlType::VELOCITY;
                    savedTargetRpm = payload;
                    if (std::abs(payload) > 0.5f) {
                        if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                        if (dev.state != SystemState::COLLISION_STOP) {
                            dev.state = SystemState::RUNNING;
                            dev.motor->setControlType(ControlType::VELOCITY);
                            dev.motor->setRPM(payload);
                        }
                    } else {
                        dev.state = SystemState::IDLE;
                        dev.motor->setControlType(ControlType::DISABLED);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    // 2. Xử lý đếm ngược & tự phục hồi sau va chạm GMO (5 giây)
    if (dev.state == SystemState::COLLISION_STOP) {
        uint32_t elapsed = currentTick - dev.collisionStartTick_ms;
        if (elapsed < __GMO_RECOVERY_WAIT_MS) {
            dev.countdown_sec = static_cast<uint8_t>((__GMO_RECOVERY_WAIT_MS - elapsed) / 1000 + 1);
        } else {
            dev.countdown_sec = 0;
            dev.driver->resetGateBlocking();
            dev.runStartTick_ms = HAL_GetTick();
            dev.motor->setControlType(savedModeBeforeCollision);
            if (savedModeBeforeCollision == ControlType::VELOCITY) {
                dev.motor->setRPM(savedTargetRpm);
            } else if (savedModeBeforeCollision == ControlType::CURRENT) {
                dev.motor->setCurrent(savedTargetIq, 0.0f);
            }
            dev.state = SystemState::RUNNING;
        }
    } else {
        dev.countdown_sec = 0;
    }

    // 3. Chia pha gửi Telemetry CAN mỗi 15ms
    if (currentTick - lastTelemTick >= __TELEMETRY_PERIOD_MS) {
        lastTelemTick = currentTick;

        if (telemSlot == 0) {
            can.sendCurrents(dev.motor->getIa(), dev.motor->getIb(),
                             dev.idTelemetry, dev.iqTelemetry);
            telemSlot = 1;
        } else if (telemSlot == 1) {
            uint8_t isCollided = (dev.state == SystemState::COLLISION_STOP) ? 1 : 0;
            can.sendGMOPacket(dev.tauExtEst_Nm, __GMO_THRESHOLD_NM, isCollided, dev.countdown_sec);
            telemSlot = 2;
        } else {
            // Dùng savedModeBeforeCollision để báo đúng trạng thái TORQUE/SPEED ngay cả khi IDLE
            uint8_t flags = (dev.motor->getUseLUT() ? 0x01 : 0x00) |
                            (dev.motor->getFieldWeakening() ? 0x02 : 0x00) |
                            (savedModeBeforeCollision == ControlType::CURRENT ? 0x04 : 0x00);
            can.sendStatus(static_cast<uint8_t>(dev.state), flags,
                           dev.motor->getVelocityRPM(), dev.motor->getUq(),
                           dev.encoder->getRawCounts());
            telemSlot = 0;
        }
    }
}
