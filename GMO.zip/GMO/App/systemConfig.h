// App/systemConfig.h
#pragma once
#include "main.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* ===================== HARDWARE PINS ===================== */
#define __ENC_SPI_PORT                  (GPIOA)
#define __ENC_SPI_CS_PIN                (GPIO_PIN_15)
#define __DRV_EN_GATE_PORT              (GPIOB)
#define __DRV_EN_GATE_PIN               (GPIO_PIN_12)

/* ===================== CONTROL LOOP ====================== */
#define __ADC_TRIGGER_FREQ_KHZ          (20)
#define __ADC_OVERSAMPLE_COUNT          (4)
#define __CTRL_LOOP_FREQ_KHZ            (5)        // Vòng dòng chạy ở 5 kHz (dt = 200 us)
#define __VEL_LOOP_FREQ_KHZ             (1)        // Vòng vận tốc chạy ở 1 kHz (dt = 1 ms)
#define __GMO_LOOP_FREQ_KHZ             (1)        // Vòng GMO chạy ở 1 kHz
#define __TELEMETRY_PERIOD_MS           (15)

/* ============ GIM8108-8 (CỘT GDS68 - ĐẤU SAO Y) ========== */
#define __MOT_POLE_PAIRS                (21)
#define __MOT_GEAR_RATIO                (8.0f)

// Datasheet GDS68: R_ll = 0.67 Ohm, L_ll = 0.37 mH -> Đấu Y chia 2:
#define __MOT_PHASE_RESISTANCE_OHM      (0.335f)     // 0.67 / 2
#define __MOT_INDUCTANCE_H              (0.000185f)  // 0.37 mH / 2 = 0.185 mH

#define __V_BUS_VOLTS                   (24.0f)
#define __CURRENT_LIMIT_AMPS            (2.2f)
#define __VOLTAGE_LIMIT_VOLTS           (8.0f)
#define __PWM_MIN_DUTY_RATIO            (0.02f)
#define __PWM_MAX_DUTY_RATIO            (0.90f)      // Mục 8.3: Giới hạn max duty <= 90% để shunt low-side đủ thời gian dẫn

/* ===================== CURRENT SENSOR ==================== */
#define __ADC_CURRENT_SCALE_A_LSB       (0.16117f)
#define __ADC_CALIB_SAMPLES             (2000)       // Mục 8.6: Lấy trung bình 2000 mẫu khi chưa cấp dòng

/* =========== PI DÒNG TÍNH TỪ R, L (MỤC 8.3 .MD) ========== */
// Chọn 1: Băng thông thấp (150 Hz - cực êm) | Chọn 2: Băng thông cao (250 Hz - cứng vững)
#define __FOC_CURRENT_BW_PRESET         (1)

#if (__FOC_CURRENT_BW_PRESET == 1)
#define __FOC_CURRENT_BW_HZ             (150.0f)
#else
#define __FOC_CURRENT_BW_HZ             (250.0f)
#endif

#define __FOC_CURRENT_OMEGA_C           (2.0f * M_PI * __FOC_CURRENT_BW_HZ)

// Kp = L * omega_c ; Ki_discrete = (R * omega_c) / f_ctrl
#define __MOT_CURRENT_PID_KP            (__MOT_INDUCTANCE_H * __FOC_CURRENT_OMEGA_C)
#define __MOT_CURRENT_PID_KI            ((__MOT_PHASE_RESISTANCE_OHM * __FOC_CURRENT_OMEGA_C) / (__CTRL_LOOP_FREQ_KHZ * 1000.0f))

/* ===================== VELOCITY PID ====================== */
#define __MOT_VEL_PID_KP                (0.015f)
#define __MOT_VEL_PID_KI                (0.035f)
#define __MOT_VEL_INTEGRAL_LIM_AMPS     (1.2f)
#define __MOT_VEL_RAMP_RPM_PER_S        (200.0f)

/* ===================== SIGNAL FILTERS ==================== */
// Mục 8.3: Tần số cắt lọc Id/Iq phải cao hơn nhiều so với băng thông vòng dòng (150 Hz -> cắt ở 800 Hz)
#define __LPF_CURRENT_CUTOFF_HZ         (800.0f)
// Lọc sâu cho Telemetry gửi lên CAN (cắt ở 10 Hz để đường đồ thị phẳng mịn)
#define __LPF_TELEM_CUTOFF_HZ           (10.0f)
// Lọc vận tốc ở f_s = 5 kHz (cắt ở 50 Hz để triệt tiêu gai lượng tử hóa encoder)
#define __LPF_VELOCITY_CUTOFF_HZ        (50.0f)

/* ===================== GMO COLLISION ===================== */
// Datasheet GDS68: Kt trục ra = 1.0 N.m/A, tỉ số truyền 8:1 -> Kt tại rotor = 0.125 N.m/A
#define __GMO_KT_NM_PER_AMP             (0.125f)
#define __GMO_INERTIA_J                 (0.00018f)
#define __GMO_VISCOUS_B                 (0.00010f)
#define __GMO_COULOMB_NM                (0.0180f)
#define __GMO_GAIN_KO_RAD_S             (20.0f)      // Giảm nhẹ Ko từ 25 xuống 20 để Tau_ext mượt hơn
#define __GMO_THRESHOLD_NM              (0.045f)     // Tương ứng với Kt = 0.125 N.m/A
#define __GMO_HEADSTART_MS              (600)
#define __GMO_RECOVERY_WAIT_MS          (5000)
