// FOCLib/MotorController/motor.cpp
#include "motor.h"
#include <algorithm>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
static constexpr float TWO_PI       = 2.0f * M_PI;
static constexpr float HALF_PI      = 0.5f * M_PI;
static constexpr float ONE_BY_SQRT3 = 0.57735026919f;
static constexpr float SQRT3_BY_2   = 0.86602540378f;

Motor::Motor(uint8_t polePairs, float motorL_H, uint8_t velLoopFreq_kHz)
    : _polePairs(polePairs),
      _motorL(motorL_H),
      _velLoopFreq_kHz(velLoopFreq_kHz > 0 ? velLoopFreq_kHz : 1) {}

void Motor::init()
{
    pid_Id.reset();
    pid_Iq.reset();
    pid_velocity.reset();
    _velFirstRun = true;
    _velDownsampler = 0;
    controlType = ControlType::DISABLED;
}

float Motor::normalizeAngle(float rad)
{
    rad = std::fmod(rad, TWO_PI);
    if (rad < 0.0f) rad += TWO_PI;
    return rad;
}

// Xấp xỉ parabol có hiệu chỉnh độ chính xác cao (sai số < 0.001) cho ISR
float Motor::quickSin(float x)
{
    x = normalizeAngle(x);
    if (x > M_PI) x -= TWO_PI; // [-pi, pi]
    constexpr float B = 4.0f / M_PI;
    constexpr float C = -4.0f / (M_PI * M_PI);
    constexpr float P = 0.225f;
    float y = B * x + C * x * std::abs(x);
    return P * (y * std::abs(y) - y) + y;
}

float Motor::quickCos(float x)
{
    return quickSin(x + HALF_PI);
}

void Motor::updateMovingAvgVelocity(float dt_sec)
{
    uint16_t raw = _sensor->getRawCounts();
    if (_velFirstRun) {
        _prevRawCnt = raw;
        _totalCounts = raw;
        for (int i = 0; i < VEL_BUF_SIZE; ++i) _countHist[i] = _totalCounts;
        _velFirstRun = false;
    }

    int16_t d_cnt = static_cast<int16_t>(raw - _prevRawCnt);
    if (d_cnt > 8192)  d_cnt -= 16384;
    if (d_cnt < -8192) d_cnt += 16384;
    _prevRawCnt = raw;
    _totalCounts += d_cnt;

    _multiTurnRad = (static_cast<float>(_totalCounts) / AS5047P::RESOLUTION) * TWO_PI;

    int64_t oldest = _countHist[_histIdx];
    _countHist[_histIdx] = _totalCounts;
    _histIdx = (_histIdx + 1) & (VEL_BUF_SIZE - 1);

    float diffTurns = static_cast<float>(_totalCounts - oldest) / AS5047P::RESOLUTION;
    float instRadS  = (diffTurns * TWO_PI) / (static_cast<float>(VEL_BUF_SIZE) * dt_sec);

    if (_kfVel != nullptr) {
        instRadS = _kfVel->updateEstimate(instRadS);
    }
    if (_lpfVel != nullptr) {
        _velRadS = _lpfVel->update(instRadS);
    } else {
        _velRadS = instRadS;
    }

    _velRpm = _velRadS * (60.0f / TWO_PI);
    if (std::abs(_velRpm) < 0.25f) {
        _velRpm  = 0.0f;
        _velRadS = 0.0f;
    }
}

void Motor::outputMinMaxPhaseVoltage(float ud, float uq, float s, float c)
{
    // 8. Park ngược (dq -> alpha-beta) & Clarke ngược (alpha-beta -> abc)
    float uAlpha = ud * c - uq * s;
    float uBeta  = ud * s + uq * c;

    float ua = uAlpha;
    float ub = -0.5f * uAlpha + SQRT3_BY_2 * uBeta;
    float uc = -0.5f * uAlpha - SQRT3_BY_2 * uBeta;

    // 9. Dịch tâm Min-Max: cộng (Vbus/2 - (Umax + Umin)/2) cho cả 3 pha
    float uMax = std::max({ua, ub, uc});
    float uMin = std::min({ua, ub, uc});
    float vBus = _driver->getVBus();
    float centerOffset = 0.5f * vBus - 0.5f * (uMax + uMin);

    ua += centerOffset;
    ub += centerOffset;
    uc += centerOffset;

    // 10. Xuất điện áp 3 pha xuống Gate Driver
    _driver->setPhaseVoltage(ua, ub, uc);
}

void Motor::updateFOC(u08 updateFreq_kHz)
{
    if (_currentSensor == nullptr || _sensor == nullptr || _driver == nullptr) return;

    // 1. Lấy dòng điện từ CurrentSensorInjected
    _currentSensor->update();
    _ia = _currentSensor->getIa();
    _ib = _currentSensor->getIb();
    _ic = _currentSensor->getIc();

    // 2. Đọc góc từ encoder và cập nhật vận tốc cửa sổ 16 mẫu ở 5 kHz (dt = 0.0002s)
    _sensor->update();
    float dt_sec = 1.0f / (static_cast<float>(updateFreq_kHz) * 1000.0f);
    updateMovingAvgVelocity(dt_sec);

    // 3. Lấy góc điện và tính sin/cos MỘT lần
    float eAngle = (_useLut && _sensor->isCalibrated())
                       ? _sensor->getCalibElecRad()
                       : _sensor->getRawElecRad();
    float s = quickSin(eAngle);
    float c = quickCos(eAngle);

    // 4. Clarke: abc -> alpha-beta
    float iAlpha = _ia;
    float iBeta  = ONE_BY_SQRT3 * (_ib - _ic);

    // 5. Park: alpha-beta -> dq
    _idRaw =  c * iAlpha + s * iBeta;
    _iqRaw =  c * iBeta  - s * iAlpha;

    // 6. Lọc thông thấp Id, Iq
    _idFilt = (_lpfId != nullptr) ? _lpfId->update(_idRaw) : _idRaw;
    _iqFilt = (_lpfIq != nullptr) ? _lpfIq->update(_iqRaw) : _iqRaw;

    if (controlType == ControlType::DISABLED) {
        _currentSensor->updateAutoZeroWhenIdle(0.005f);
        pid_Id.reset();
        pid_Iq.reset();
        _ud = 0.0f;
        _uq = 0.0f;
        _driver->setDutyCycle(0.5f, 0.5f, 0.5f);
        return;
    }

    if (controlType == ControlType::VOLTAGE) {
        outputMinMaxPhaseVoltage(_ud, _uq, s, c);
        return;
    }

    if (_enableFW) {
        float absRpm = std::abs(_velRpm);
        _targetId = (absRpm > 120.0f) ? -std::min(0.8f, (absRpm - 120.0f) * 0.015f) : 0.0f;
    } else {
        _targetId = 0.0f;
    }

    float limId = __constrain(_targetId, -limitCurrent, limitCurrent);
    float limIq = __constrain(_targetIq, -limitCurrent, limitCurrent);

    // 7. Hai bộ PI dòng + Decoupling
    float omega_e = _velRadS * static_cast<float>(_polePairs);

    float errD = limId - _idFilt;
    pid_Id.integral = __constrain(pid_Id.integral + pid_Id.ki * errD, -limitVoltage, limitVoltage);
    _ud = __constrain(pid_Id.kp * errD + pid_Id.integral - omega_e * _motorL * _iqFilt,
                      -limitVoltage, limitVoltage);

    float errQ = limIq - _iqFilt;
    pid_Iq.integral = __constrain(pid_Iq.integral + pid_Iq.ki * errQ, -limitVoltage, limitVoltage);
    _uq = __constrain(pid_Iq.kp * errQ + pid_Iq.integral + omega_e * _motorL * _idFilt,
                      -limitVoltage, limitVoltage);

    // 8, 9, 10. Park ngược, Clarke ngược, Dịch tâm Min-Max, xuất PWM
    outputMinMaxPhaseVoltage(_ud, _uq, s, c);
}

void Motor::updateVelocity(u08 callbackFreq_kHz)
{
    uint8_t ratio = callbackFreq_kHz / _velLoopFreq_kHz;
    if (ratio == 0) ratio = 1;
    if (++_velDownsampler < ratio) return;
    _velDownsampler = 0;

    if (controlType != ControlType::VELOCITY) return;

    float dt_vel = 1.0f / (static_cast<float>(_velLoopFreq_kHz) * 1000.0f);
    float rampStep = velRampRate_RPM_per_s * dt_vel;

    if (_rampedRpm < _targetRpm) {
        _rampedRpm = std::min(_rampedRpm + rampStep, _targetRpm);
    } else if (_rampedRpm > _targetRpm) {
        _rampedRpm = std::max(_rampedRpm - rampStep, _targetRpm);
    }

    float velErr = _rampedRpm - _velRpm;
    pid_velocity.integral = __constrain(
        pid_velocity.integral + pid_velocity.ki * velErr * dt_vel,
        -pid_velocity.limit, pid_velocity.limit);

    float iqFF = _rampedRpm * velFeedforwardGain;
    _targetIq  = __constrain(iqFF + pid_velocity.kp * velErr + pid_velocity.integral,
                             -limitCurrent, limitCurrent);
}

void Motor::setControlType(ControlType mode)
{
    if (controlType != mode) {
        pid_Id.reset();
        pid_Iq.reset();
        pid_velocity.reset();
        if (mode == ControlType::VELOCITY) {
            _rampedRpm = _velRpm;
        }
        controlType = mode;
    }
}

void Motor::setVoltage(float ud, float uq)
{
    if (controlType != ControlType::VOLTAGE) return;
    _ud = __constrain(ud, -limitVoltage, limitVoltage);
    _uq = __constrain(uq, -limitVoltage, limitVoltage);
}

void Motor::setCurrent(float iqTarget, float idTarget)
{
    if (controlType != ControlType::CURRENT) return;
    _targetIq = __constrain(iqTarget, -limitCurrent, limitCurrent);
    _targetId = __constrain(idTarget, -limitCurrent, limitCurrent);
}

void Motor::setRPM(float rpmTarget)
{
    if (controlType != ControlType::VELOCITY) return;
    _targetRpm = rpmTarget;
}

void Motor::applyOpenLoopVoltage(float ud, float uq, float elecAngle_rad)
{
    float s = quickSin(elecAngle_rad);
    float c = quickCos(elecAngle_rad);
    outputMinMaxPhaseVoltage(ud, uq, s, c);
}
