// FOCLib/MotorController/motor.h
#pragma once
#include "../CurrentSensors/currentSensorInjected.h"
#include "../MotorDrivers/drv8301Driver.h"
#include "../SignalFilters/lowpassFilter.h"
#include "../SignalFilters/kalmanFilter.h"
#include "../../Libs/as5047p.h"
#include <cstdint>

enum class ModulationType : uint8_t {
    FOC = 0
};

enum class ControlType : uint8_t {
    DISABLED = 0,
    VOLTAGE  = 1,
    CURRENT  = 2,
    VELOCITY = 3,
    POSITION = 4
};

struct PIParams {
    float kp{0.0f};
    float ki{0.0f};
    float limit{0.0f};
    float integral{0.0f};

    void reset() { integral = 0.0f; }
};

class Motor {
public:
    Motor(uint8_t polePairs, float motorL_H, uint8_t velLoopFreq_kHz = 1);

    void appendDriver(DRV8301Driver* driver) { _driver = driver; }
    void appendSensor(AS5047P* sensor) { _sensor = sensor; }
    void appendCurrentSensor(CurrentSensorInjected* cs) { _currentSensor = cs; }
    void appendCurrentFilters(LowpassFilter* lpfId, LowpassFilter* lpfIq) {
        _lpfId = lpfId;
        _lpfIq = lpfIq;
    }
    void appendVelocityFilter(LowpassFilter* lpfVel, KalmanFilter* kfVel = nullptr) {
        _lpfVel = lpfVel;
        _kfVel  = kfVel;
    }

    void init();

    // Mục 8.3: Vòng dòng FOC chạy ở tần số PWM (hoặc tần số ngắt điều khiển)
    void updateFOC(u08 updateFreq_kHz);

    // Mục 8.4: Vòng tốc độ tự downsample bên trong
    void updateVelocity(u08 callbackFreq_kHz);

    // Mục 8.5: Chuyển chế độ và đặt target (có reset tích phân khi đổi chế độ)
    void setControlType(ControlType mode);
    ControlType getControlType() const { return controlType; }

    void setVoltage(float ud, float uq);
    void setCurrent(float iqTarget, float idTarget = 0.0f);
    void setRPM(float rpmTarget);

    // Áp điện áp trực tiếp theo góc điện bất kỳ (dùng khi hiệu chỉnh LUT)
    void applyOpenLoopVoltage(float ud, float uq, float elecAngle_rad);

    void setUseLUT(bool use) { _useLut = use; }
    bool getUseLUT() const { return _useLut; }

    void setFieldWeakening(bool enable) { _enableFW = enable; }
    bool getFieldWeakening() const { return _enableFW; }

    // Getters cho Telemetry & GMO
    float getIa() const { return _ia; }
    float getIb() const { return _ib; }
    float getIc() const { return _ic; }
    float getId() const { return _idFilt; }
    float getIq() const { return _iqFilt; }
    float getUd() const { return _ud; }
    float getUq() const { return _uq; }
    float getVelocityRPM() const { return _velRpm; }
    float getVelocityRadS() const { return _velRadS; }
    float getMultiTurnRad() const { return _multiTurnRad; }

    ModulationType modulationType{ModulationType::FOC};
    ControlType    controlType{ControlType::DISABLED};

    PIParams pid_Id;
    PIParams pid_Iq;
    PIParams pid_velocity;

    float limitCurrent{2.2f};
    float limitVoltage{8.0f};
    float velRampRate_RPM_per_s{200.0f};
    float velFeedforwardGain{0.0018f}; // (1 / 100) * 0.18f

private:
    static float quickSin(float rad);
    static float quickCos(float rad);
    static float normalizeAngle(float rad);
    void updateMovingAvgVelocity(float dt_sec);
    void outputMinMaxPhaseVoltage(float ud, float uq, float s, float c);

    uint8_t _polePairs{21};
    float   _motorL{0.00018f};
    uint8_t _velLoopFreq_kHz{1};
    uint8_t _velDownsampler{0};

    DRV8301Driver*         _driver{nullptr};
    AS5047P*               _sensor{nullptr};
    CurrentSensorInjected* _currentSensor{nullptr};
    LowpassFilter*         _lpfId{nullptr};
    LowpassFilter*         _lpfIq{nullptr};
    LowpassFilter*         _lpfVel{nullptr};
    KalmanFilter*          _kfVel{nullptr};

    bool _useLut{true};
    bool _enableFW{false};

    // Biến trạng thái FOC
    float _ia{0.0f}, _ib{0.0f}, _ic{0.0f};
    float _idRaw{0.0f}, _iqRaw{0.0f};
    float _idFilt{0.0f}, _iqFilt{0.0f};
    float _targetId{0.0f}, _targetIq{0.0f};
    float _ud{0.0f}, _uq{0.0f};

    // Biến vòng vận tốc & cửa sổ 16 mẫu
    static constexpr int VEL_BUF_SIZE = 16;
    bool     _velFirstRun{true};
    uint16_t _prevRawCnt{0};
    int64_t  _totalCounts{0};
    int64_t  _countHist[VEL_BUF_SIZE]{0};
    uint8_t  _histIdx{0};

    float _multiTurnRad{0.0f};
    float _velRadS{0.0f};
    float _velRpm{0.0f};
    float _targetRpm{0.0f};
    float _rampedRpm{0.0f};
};
