// App/FOCLib/CurrentSensors/currentSensorInjected.h
#pragma once
#include "stm32f4xx_hal.h"
#include <cstdint>

enum class PhaseExclusion : uint8_t {
    NONE = 0,
    EXCLUDE_PHASE_A,
    EXCLUDE_PHASE_B,
    EXCLUDE_PHASE_C
};

class CurrentSensorInjected {
public:
    CurrentSensorInjected(ADC_HandleTypeDef* hadc_master_b,
                          ADC_HandleTypeDef* hadc_slave_c,
                          float currentScale_A_per_LSB,
                          uint8_t oversampleRatio = 4,
                          PhaseExclusion exclusion = PhaseExclusion::EXCLUDE_PHASE_A);

    void init();
    void calibrate(uint16_t numSamples = 1024);
    bool isCalibrationComplete() const { return _isCalibComplete; }

    void update() {}

    // Trả về true khi đã gom đủ số mẫu oversampling và tính xong Ia, Ib, Ic
    bool onConversionComplete_ISR();

    void updateAutoZeroWhenIdle(float alpha = 0.005f);

    ADC_TypeDef* getMasterADCInstance() const { return _hadcMaster->Instance; }

    float getIa() const { return _ia; }
    float getIb() const { return _ib; }
    float getIc() const { return _ic; }

private:
    ADC_HandleTypeDef* _hadcB{nullptr};
    ADC_HandleTypeDef* _hadcC{nullptr};
    ADC_HandleTypeDef* _hadcMaster{nullptr};

    float          _scale{0.16117f};
    uint8_t        _oversampleRatio{4};
    uint8_t        _prescaler{0};
    PhaseExclusion _exclusion{PhaseExclusion::EXCLUDE_PHASE_A};

    uint32_t _sumB{0};
    uint32_t _sumC{0};
    float    _sampleB{2048.0f};
    float    _sampleC{2048.0f};

    float _offsetB{2048.0f};
    float _offsetC{2048.0f};

    volatile float _ia{0.0f};
    volatile float _ib{0.0f};
    volatile float _ic{0.0f};

    volatile bool     _isCalibrating{false};
    volatile bool     _isCalibComplete{false};
    uint16_t          _calibTargetSamples{1024};
    volatile uint16_t _calibCount{0};
    uint32_t          _calibAccB{0};
    uint32_t          _calibAccC{0};
};
