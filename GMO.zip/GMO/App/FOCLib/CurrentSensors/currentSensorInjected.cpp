// App/FOCLib/CurrentSensors/currentSensorInjected.cpp
#include "currentSensorInjected.h"

CurrentSensorInjected::CurrentSensorInjected(ADC_HandleTypeDef* hadc_master_b,
                                             ADC_HandleTypeDef* hadc_slave_c,
                                             float currentScale_A_per_LSB,
                                             uint8_t oversampleRatio,
                                             PhaseExclusion exclusion)
    : _hadcB(hadc_master_b),
      _hadcC(hadc_slave_c),
      _hadcMaster(hadc_master_b),
      _scale(currentScale_A_per_LSB),
      _oversampleRatio(oversampleRatio > 0 ? oversampleRatio : 1),
      _exclusion(exclusion) {}

void CurrentSensorInjected::init()
{
    HAL_ADCEx_InjectedStart(_hadcC);
    HAL_ADCEx_InjectedStart_IT(_hadcB);
}

void CurrentSensorInjected::calibrate(uint16_t numSamples)
{
    _calibTargetSamples = (numSamples > 0) ? numSamples : 1024;
    _calibAccB       = 0;
    _calibAccC       = 0;
    _calibCount      = 0;
    _isCalibComplete = false;
    _isCalibrating   = true;
}

bool CurrentSensorInjected::onConversionComplete_ISR()
{
    uint16_t rawB = static_cast<uint16_t>(_hadcB->Instance->JDR1);
    uint16_t rawC = static_cast<uint16_t>(_hadcC->Instance->JDR1);

    // 1. Hiệu chỉnh offset ban đầu khi chưa cấp dòng
    if (_isCalibrating) {
        _calibAccB += rawB;
        _calibAccC += rawC;
        _calibCount++;

        if (_calibCount >= _calibTargetSamples) {
            float invN = 1.0f / static_cast<float>(_calibTargetSamples);
            _offsetB = static_cast<float>(_calibAccB) * invN;
            _offsetC = static_cast<float>(_calibAccC) * invN;
            _isCalibrating   = false;
            _isCalibComplete = true;
        }
        return false;
    }

    // 2. Cộng dồn 4 mẫu (Oversampling 20 kHz -> 5 kHz như main_cpp.cpp gốc)
    _sumB += rawB;
    _sumC += rawC;
    _prescaler++;

    if (_prescaler < _oversampleRatio) {
        return false;
    }

    float invOvs = 1.0f / static_cast<float>(_oversampleRatio);
    _sampleB   = static_cast<float>(_sumB) * invOvs;
    _sampleC   = static_cast<float>(_sumC) * invOvs;
    _prescaler = 0;
    _sumB      = 0;
    _sumC      = 0;

    // 3. Quy đổi sang Ampe
    _ib = (_sampleB - _offsetB) * _scale;
    _ic = (_sampleC - _offsetC) * _scale;
    _ia = -(_ib + _ic);

    return true;
}

void CurrentSensorInjected::updateAutoZeroWhenIdle(float alpha)
{
    if (_isCalibrating) return;
    _offsetB += alpha * (_sampleB - _offsetB);
    _offsetC += alpha * (_sampleC - _offsetC);
}
