// FOCLib/MotorDrivers/drv8301Driver.h
#pragma once
#include "stm32f4xx_hal.h"
#include <algorithm>
#include <cstdint>

class DRV8301Driver {
public:
    DRV8301Driver(TIM_HandleTypeDef* htim, GPIO_TypeDef* enPort, uint16_t enPin,
                  float vBus_V, float minDuty = 0.02f, float maxDuty = 0.98f)
        : _htim(htim), _enPort(enPort), _enPin(enPin),
          _vBus(vBus_V), _minDuty(minDuty), _maxDuty(maxDuty) {}

    void init()
        {
            uint32_t arr = __HAL_TIM_GET_AUTORELOAD(_htim);
            // Mục 7: Đặt CCR4 sát đỉnh ARR để trigger ADC đúng tâm dẫn của Low-side Shunt
            __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_4, (arr > 2) ? (arr - 1) : arr);

            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_1);
            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_2);
            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_3);

            setDutyCycle(0.5f, 0.5f, 0.5f);
            resetGateBlocking();
        }

    // Chỉ gọi ở setup() hoặc loop() (có HAL_Delay)
    void resetGateBlocking()
    {
        setDutyCycle(0.5f, 0.5f, 0.5f);
        HAL_GPIO_WritePin(_enPort, _enPin, GPIO_PIN_RESET);
        HAL_Delay(50);
        HAL_GPIO_WritePin(_enPort, _enPin, GPIO_PIN_SET);
        HAL_Delay(800);
    }

    // Nhận điện áp pha [0 .. Vbus] sau bước dịch tâm Min-Max (Mục 8.3 bước 10)
    void setPhaseVoltage(float ua, float ub, float uc)
    {
        float invVbus = 1.0f / _vBus;
        setDutyCycle(ua * invVbus, ub * invVbus, uc * invVbus);
    }

    void setDutyCycle(float du, float dv, float dw)
    {
        du = std::max(_minDuty, std::min(du, _maxDuty));
        dv = std::max(_minDuty, std::min(dv, _maxDuty));
        dw = std::max(_minDuty, std::min(dw, _maxDuty));

        uint32_t arr = __HAL_TIM_GET_AUTORELOAD(_htim);
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_1, static_cast<uint32_t>(du * arr));
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_2, static_cast<uint32_t>(dv * arr));
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_3, static_cast<uint32_t>(dw * arr));
    }

    float getVBus() const { return _vBus; }

private:
    TIM_HandleTypeDef* _htim;
    GPIO_TypeDef*      _enPort;
    uint16_t           _enPin;
    float              _vBus;
    float              _minDuty;
    float              _maxDuty;
};
