#include "can.h"
#include <cstring>

CANInterface::CANInterface(CAN_HandleTypeDef* hcan) : hcan_(hcan) {}

bool CANInterface::init() {
    CAN_FilterTypeDef filter;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = 0x0000;
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = 0x0000;
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14;

    if (HAL_CAN_ConfigFilter(hcan_, &filter) != HAL_OK) return false;
    return (HAL_CAN_Start(hcan_) == HAL_OK);
}

bool CANInterface::receiveCommand(uint8_t& out_cmd_id, float& out_payload) {
    if (HAL_CAN_GetRxFifoFillLevel(hcan_, CAN_RX_FIFO0) > 0) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];

        if (HAL_CAN_GetRxMessage(hcan_, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK) {
            if (rx_header.IDE == CAN_ID_STD && rx_header.StdId == 0x100 && rx_header.DLC >= 1) {
                out_cmd_id = rx_data[0];
                if (rx_header.DLC >= 5) {
                    std::memcpy(&out_payload, &rx_data[1], sizeof(float));
                } else {
                    out_payload = 0.0f;
                }
                return true;
            }
        }
    }
    return false;
}

bool CANInterface::sendStatus(uint8_t state, uint8_t is_lut_active, float rpm, float vq, uint16_t raw_counts) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x102;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = state;
    tx_data[1] = is_lut_active;

    int16_t rpm_scaled = static_cast<int16_t>(rpm * 10.0f);
    int16_t vq_scaled  = static_cast<int16_t>(vq * 100.0f);

    std::memcpy(&tx_data[2], &rpm_scaled, sizeof(int16_t));
    std::memcpy(&tx_data[4], &vq_scaled, sizeof(int16_t));
    std::memcpy(&tx_data[6], &raw_counts, sizeof(uint16_t));

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendCurrents(float ia, float ib, float ic, uint8_t fw_state, float id) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x105;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    int16_t ia_ma = static_cast<int16_t>(ia * 1000.0f);
    int16_t ib_ma = static_cast<int16_t>(ib * 1000.0f);
    int16_t ic_ma = static_cast<int16_t>(ic * 1000.0f);
    int16_t id_ma = static_cast<int16_t>(id * 1000.0f);

    std::memcpy(&tx_data[0], &ia_ma, sizeof(int16_t));
    std::memcpy(&tx_data[2], &ib_ma, sizeof(int16_t));
    std::memcpy(&tx_data[4], &ic_ma, sizeof(int16_t));
    tx_data[6] = fw_state;
    tx_data[7] = static_cast<uint8_t>((id_ma / 100) & 0xFF); // Id dạng nén

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendLUTPoint(uint8_t index, float lut_val) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x104;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = index;
    std::memcpy(&tx_data[1], &lut_val, sizeof(float));
    tx_data[5] = 0; tx_data[6] = 0; tx_data[7] = 0;

    while (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) == 0) {
        HAL_Delay(1);
    }
    return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
}
