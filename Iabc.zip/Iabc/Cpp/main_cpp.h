#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void run_loop(void);

#ifdef __cplusplus
}
#endif
