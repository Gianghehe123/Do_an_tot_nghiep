#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>
#include <cmath>

class AS5047P {
public:
    static constexpr uint16_t CMD_ANGLECOM = 0xFFFF;
    static constexpr float    RESOLUTION   = 16384.0f; // 14-bit
    static constexpr int      LUT_SIZE     = 128;

    AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs = 21);

    void init();
    bool update();

    // Góc thô chưa bù (Dùng để kiểm chứng trước hiệu chuẩn)
    float getRawMechRad() const { return raw_mech_rad_; }
    float getRawElecRad() const { return raw_elec_rad_; }

    // Góc đã tuyến tính hóa qua LUT 128 điểm (Dùng sau hiệu chuẩn)
    float getCalibMechRad() const { return calib_mech_rad_; }
    float getCalibElecRad() const { return calib_elec_rad_; }

    float getVelocityRPM() const { return vel_rpm_; }
    uint16_t getRawCounts() const { return raw_data_; }
    bool isError() const { return has_error_; }

    void setLUT(const float* lut, float zero_offset);
    const float* getLUT() const { return lut_; }
    float getZeroOffset() const { return zero_offset_; }
    bool isCalibrated() const { return is_calibrated_; }

private:
    SPI_HandleTypeDef* hspi_;
    GPIO_TypeDef*      cs_port_;
    uint16_t           cs_pin_;
    uint8_t            pole_pairs_;

    uint16_t raw_data_{0};
    uint16_t prev_raw_data_{0};
    bool     has_error_{false};
    bool     first_run_{true};

    float raw_mech_rad_{0.0f};
    float raw_elec_rad_{0.0f};
    float calib_mech_rad_{0.0f};
    float calib_elec_rad_{0.0f};

    uint32_t last_vel_tick_{0};
    int32_t  accum_counts_{0};
    float    vel_rpm_{0.0f};

    bool  is_calibrated_{false};
    float zero_offset_{0.0f};
    float lut_[LUT_SIZE]{0.0f};

    uint16_t readRegister(uint16_t cmd);
    static bool checkParity(uint16_t data);
    float interpolateLUT(uint16_t counts);
};
