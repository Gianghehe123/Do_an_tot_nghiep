#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>

class CANInterface {
public:
    explicit CANInterface(CAN_HandleTypeDef* hcan);

    bool init();
    bool receiveCommand(uint8_t& out_cmd_id, float& out_payload);
    bool sendStatus(uint8_t state, uint8_t is_lut_active, float rpm, float vq, uint16_t raw_counts);
    bool sendLUTPoint(uint8_t index, float lut_val);

    // Gói 0x105: Gửi dòng pha Ia, Ib, Ic và trạng thái Field Weakening
    bool sendCurrents(float ia, float ib, float ic, uint8_t fw_state, float id);

private:
    CAN_HandleTypeDef* hcan_;
};
