#include "main_cpp.h"
#include "stm32f4xx_hal.h"
#include "main.h"
#include "as5047p.h"
#include "can.h"
#include <algorithm>
#include <cmath>

extern SPI_HandleTypeDef hspi1;
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

// Bộ đệm hiệu chuẩn 1260 mẫu LUT
static constexpr int SAMPLES_PER_POLE = 60;
static constexpr int TOTAL_SAMPLES    = 21 * SAMPLES_PER_POLE;
static float s_fwd_err[TOTAL_SAMPLES];
static float s_bwd_err[TOTAL_SAMPLES];
static float s_avg_err[TOTAL_SAMPLES];
static float s_lut[AS5047P::LUT_SIZE];

static AS5047P encoder(&hspi1, GPIOA, GPIO_PIN_15, 21);
static CANInterface can(&hcan1);

enum class MotorState : uint8_t {
    IDLE = 0,
    CALIBRATING = 1,
    RUNNING = 2,
    ERROR = 3
};

static MotorState g_state = MotorState::IDLE;
static bool  g_use_lut = false;
static bool  g_enable_fw = false;      // Bù từ trường
static float g_target_rpm = 0.0f;
static float g_ramped_rpm = 0.0f;
static float g_integral_err = 0.0f;
static float g_vq = 0.0f;
static float g_vd = 0.0f;

// Tỉ lệ đọc dòng ODrive 3.5: Rshunt=0.5mOhm, Gain=10 -> 0.16117 A/LSB
static constexpr float CURRENT_SCALE = 0.16117f;

// Biến Calib Shunt Offset trong ngắt
static volatile bool     g_offset_calib_done  = false;
static volatile bool     g_offset_calib_error = false;
static volatile uint32_t g_calib_sample_count = 0;
static volatile uint32_t g_calib_sum_b        = 0;
static volatile uint32_t g_calib_sum_c        = 0;

static uint16_t g_offset_b = 2048;
static uint16_t g_offset_c = 2048;

// Giá trị dòng điện
static float g_ia = 0.0f;
static float g_ib = 0.0f;
static float g_ic = 0.0f;
static float g_id = 0.0f;
static float g_iq = 0.0f;

// Bộ điều khiển dòng trục D cho Field Weakening
static float g_id_target   = 0.0f;
static float g_id_integral = 0.0f;

static void setPWMDuty(float duty_u, float duty_v, float duty_w) {
    duty_u = std::max(0.02f, std::min(duty_u, 0.98f));
    duty_v = std::max(0.02f, std::min(duty_v, 0.98f));
    duty_w = std::max(0.02f, std::min(duty_w, 0.98f));

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(&htim1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, static_cast<uint32_t>(duty_u * arr));
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, static_cast<uint32_t>(duty_v * arr));
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, static_cast<uint32_t>(duty_w * arr));
}

static void applySVPWM(float vd, float vq, float theta_e) {
    float cos_th = std::cos(theta_e);
    float sin_th = std::sin(theta_e);
    float v_alpha = vd * cos_th - vq * sin_th;
    float v_beta  = vd * sin_th + vq * cos_th;

    float v_a = v_alpha;
    float v_b = -0.5f * v_alpha + 0.8660254f * v_beta;
    float v_c = -0.5f * v_alpha - 0.8660254f * v_beta;

    float v_min = std::min({v_a, v_b, v_c});
    float v_max = std::max({v_a, v_b, v_c});
    float v_center = 0.5f * (v_max + v_min);

    float duty_u = (v_a - v_center) / 24.0f + 0.5f;
    float duty_v = (v_b - v_center) / 24.0f + 0.5f;
    float duty_w = (v_c - v_center) / 24.0f + 0.5f;

    setPWMDuty(duty_u, duty_v, duty_w);
}

// BƯỚC 1 & BƯỚC 3: NGẮT ADC INJECTED 15 CYCLES ĐỒNG BỘ TẠI ĐỈNH PWM
extern "C" void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if (hadc->Instance == ADC1) {
        uint16_t raw_b = ADC1->JDR1; // PC0
        uint16_t raw_c = ADC2->JDR1; // PC1

        // 1. Giai đoạn tích lũy 1024 mẫu Calib Offset khi khởi động
        if (!g_offset_calib_done) {
            g_calib_sum_b += raw_b;
            g_calib_sum_c += raw_c;
            g_calib_sample_count++;

            if (g_calib_sample_count >= 1024) {
                uint32_t avg_b = g_calib_sum_b / 1024;
                uint32_t avg_c = g_calib_sum_c / 1024;

                // Kiểm tra ngưỡng an toàn 1.65V +/- 150 LSB (1898 -> 2198)
                if (avg_b < 1898 || avg_b > 2198 || avg_c < 1898 || avg_c > 2198) {
                    g_offset_calib_error = true;
                } else {
                    g_offset_b = static_cast<uint16_t>(avg_b);
                    g_offset_c = static_cast<uint16_t>(avg_c);
                    g_offset_calib_done = true;
                }
            }
            return;
        }

        // 2. Chuyển đổi dòng thực tế đối xứng qua 0A
        g_ib = (static_cast<float>(raw_b) - static_cast<float>(g_offset_b)) * CURRENT_SCALE;
        g_ic = (static_cast<float>(raw_c) - static_cast<float>(g_offset_c)) * CURRENT_SCALE;
        g_ia = -(g_ib + g_ic); // KCL Ia = -(Ib + Ic)

        // 3. Biến đổi Clarke
        float i_alpha = g_ia;
        float i_beta  = 0.57735027f * (g_ib - g_ic);

        // 4. Biến đổi Park
        float theta_e = g_use_lut ? encoder.getCalibElecRad() : encoder.getRawElecRad();
        float cos_th = std::cos(theta_e);
        float sin_th = std::sin(theta_e);

        float raw_id =  i_alpha * cos_th + i_beta * sin_th;
        float raw_iq = -i_alpha * sin_th + i_beta * cos_th;

        // 5. BƯỚC 3: Bộ lọc số thông thấp bậc 1 (LPF) khử nhiễu chuyển mạch (alpha = 0.15)
        constexpr float LPF_ALPHA = 0.15f;
        g_id += LPF_ALPHA * (raw_id - g_id);
        g_iq += LPF_ALPHA * (raw_iq - g_iq);
    }
}

static void runCalibration() {
    g_state = MotorState::CALIBRATING;
    setPWMDuty(0.5f, 0.5f, 0.5f);
    HAL_Delay(100);

    const float v_calib = 1.3f;

    applySVPWM(v_calib, 0.0f, 0.0f);
    HAL_Delay(700);

    encoder.update();
    uint16_t prev_raw = encoder.getRawCounts();
    int32_t cum_raw = prev_raw;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float mech_ref = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        applySVPWM(v_calib, 0.0f, mech_ref * 21.0f);
        HAL_Delay(4);

        encoder.update();
        uint16_t cur_raw = encoder.getRawCounts();
        int32_t d_raw = static_cast<int32_t>(cur_raw) - static_cast<int32_t>(prev_raw);
        if (d_raw > 8192)  d_raw -= 16384;
        if (d_raw < -8192) d_raw += 16384;
        prev_raw = cur_raw;
        cum_raw += d_raw;

        float unwrapped_meas = (static_cast<float>(cum_raw) / 16384.0f) * (2.0f * M_PI);
        s_fwd_err[i] = unwrapped_meas - mech_ref;
    }

    for (int i = TOTAL_SAMPLES - 1; i >= 0; --i) {
        float mech_ref = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        applySVPWM(v_calib, 0.0f, mech_ref * 21.0f);
        HAL_Delay(4);

        encoder.update();
        uint16_t cur_raw = encoder.getRawCounts();
        int32_t d_raw = static_cast<int32_t>(cur_raw) - static_cast<int32_t>(prev_raw);
        if (d_raw > 8192)  d_raw -= 16384;
        if (d_raw < -8192) d_raw += 16384;
        prev_raw = cur_raw;
        cum_raw += d_raw;

        float unwrapped_meas = (static_cast<float>(cum_raw) / 16384.0f) * (2.0f * M_PI);
        s_bwd_err[i] = unwrapped_meas - mech_ref;
    }

    setPWMDuty(0.5f, 0.5f, 0.5f);

    double sum_zero = 0.0;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        s_avg_err[i] = 0.5f * (s_fwd_err[i] + s_bwd_err[i]);
        sum_zero += s_avg_err[i];
    }
    float zero_offset = static_cast<float>(sum_zero / TOTAL_SAMPLES);
    while (zero_offset >= 2.0f * M_PI) zero_offset -= 2.0f * M_PI;
    while (zero_offset < 0.0f)        zero_offset += 2.0f * M_PI;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) s_avg_err[i] -= zero_offset;

    const int window = SAMPLES_PER_POLE;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float sum_win = 0.0f;
        for (int w = -window / 2; w < window / 2; ++w) {
            int idx = (i + w + TOTAL_SAMPLES) % TOTAL_SAMPLES;
            sum_win += s_avg_err[idx];
        }
        s_fwd_err[i] = sum_win / static_cast<float>(window);
    }

    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) {
        int sample_idx = (i * TOTAL_SAMPLES) / AS5047P::LUT_SIZE;
        s_lut[i] = -s_fwd_err[sample_idx];
        can.sendLUTPoint(static_cast<uint8_t>(i), s_lut[i]);
        HAL_Delay(3);
    }

    encoder.setLUT(s_lut, zero_offset);
    g_use_lut = true;
    g_state = MotorState::IDLE;
}

void run_loop(void) {
    // 1. Reset chip DRV8301 phần cứng
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
    HAL_Delay(30);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
    HAL_Delay(50);

    encoder.init();
    can.init();

    // Khởi động PWM Timer 1
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);

    // Kênh 4 kích hoạt Injected ADC
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    // Mở van 50% để đo dòng bằng 0A tuyệt đối
    setPWMDuty(0.5f, 0.5f, 0.5f);

    // BẬT ADC ĐỒNG BỘ 15 CYCLES
    g_offset_calib_done = false;
    g_offset_calib_error = false;
    g_calib_sample_count = 0;
    g_calib_sum_b = 0;
    g_calib_sum_c = 0;

    HAL_ADCEx_InjectedStart(&hadc2);
    HAL_ADCEx_InjectedStart_IT(&hadc1);

    // Chờ ngắt ADC gom đủ 1024 mẫu (~52ms ở 20kHz)
    uint32_t wait_start = HAL_GetTick();
    while (!g_offset_calib_done && !g_offset_calib_error) {
        if (HAL_GetTick() - wait_start > 500) {
            g_offset_calib_error = true;
            break;
        }
    }

    if (g_offset_calib_error) {
        g_state = MotorState::ERROR;
    }

    uint32_t last_foc_tick = 0;
    uint32_t last_status_tick = 0;
    uint32_t last_current_tick = 0;
    uint8_t  cmd_id = 0;
    float    cmd_payload = 0.0f;

    while (1) {
        uint32_t current_tick = HAL_GetTick();

        // Chu kỳ FOC 1 kHz
        if (current_tick - last_foc_tick >= 1) {
            last_foc_tick = current_tick;
            encoder.update();

            if (g_state == MotorState::RUNNING) {
                float theta_e = g_use_lut ? encoder.getCalibElecRad() : encoder.getRawElecRad();
                float actual_rpm = encoder.getVelocityRPM();

                float ramp_step = 250.0f * 0.001f;
                if (g_ramped_rpm < g_target_rpm) g_ramped_rpm = std::min(g_ramped_rpm + ramp_step, g_target_rpm);
                else if (g_ramped_rpm > g_target_rpm) g_ramped_rpm = std::max(g_ramped_rpm - ramp_step, g_target_rpm);

                // PI Vận tốc ra Vq
                float err = g_ramped_rpm - actual_rpm;
                g_integral_err += 0.25f * err * 0.001f;
                g_integral_err = std::max(-5.0f, std::min(g_integral_err, 5.0f));

                float v_ff = (g_ramped_rpm / 100.0f) * 1.1f;
                g_vq = v_ff + (0.05f * err) + g_integral_err;
                g_vq = std::max(-6.0f, std::min(g_vq, 6.0f));

                // BƯỚC 2: KHÓA CHẶT Vd = 0V KHI CHƯA BẬT FW
                if (g_enable_fw) {
                    float abs_rpm = std::abs(actual_rpm);
                    if (abs_rpm > 120.0f) {
                        g_id_target = -std::min(4.0f, (abs_rpm - 120.0f) * 0.025f);
                    } else {
                        g_id_target = 0.0f;
                    }

                    // BƯỚC 3: Hạ Kp = 0.03 để chống rung chattering cho motor GIM8108
                    float err_id = g_id_target - g_id;
                    g_id_integral += 0.5f * err_id * 0.001f;
                    g_id_integral = std::max(-2.5f, std::min(g_id_integral, 2.5f));

                    g_vd = (0.03f * err_id) + g_id_integral;
                    g_vd = std::max(-2.5f, std::min(g_vd, 2.5f));
                } else {
                    g_id_target   = 0.0f;
                    g_id_integral = 0.0f;
                    g_vd          = 0.0f; // Khóa cứng 0V tuyệt đối
                }

                applySVPWM(g_vd, g_vq, theta_e);
            } else if (g_state == MotorState::IDLE) {
                setPWMDuty(0.5f, 0.5f, 0.5f);
                g_vq = 0.0f;
                g_vd = 0.0f;
                g_integral_err = 0.0f;
                g_id_integral = 0.0f;
            }
        }

        // Nhận lệnh CAN 0x100
        if (can.receiveCommand(cmd_id, cmd_payload)) {
            switch (cmd_id) {
                case 0x01: // Disarm
                    if (g_state != MotorState::ERROR) g_state = MotorState::IDLE;
                    g_target_rpm = 0.0f;
                    break;
                case 0x02: // Arm
                    if (g_state != MotorState::ERROR) {
                        g_state = MotorState::RUNNING;
                        g_ramped_rpm = encoder.getVelocityRPM();
                        g_integral_err = 0.0f;
                        g_id_integral = 0.0f;
                    }
                    break;
                case 0x03: // Set RPM
                    g_target_rpm = cmd_payload;
                    if (g_state == MotorState::IDLE && std::abs(cmd_payload) > 0.1f) {
                        g_state = MotorState::RUNNING;
                        g_ramped_rpm = encoder.getVelocityRPM();
                    }
                    break;
                case 0x04: // Calib LUT
                    if (g_state != MotorState::ERROR) runCalibration();
                    break;
                case 0x05: // Toggle LUT
                    g_use_lut = (cmd_payload > 0.5f);
                    break;
                case 0x06: // Toggle Field Weakening
                    g_enable_fw = (cmd_payload > 0.5f);
                    break;
                default: break;
            }
        }

        // Telemetry Status (50 ms)
        if (current_tick - last_status_tick >= 50) {
            last_status_tick = current_tick;
            can.sendStatus(static_cast<uint8_t>(g_state), g_use_lut ? 1 : 0,
                           encoder.getVelocityRPM(), g_vq, encoder.getRawCounts());
        }

        // Telemetry Dòng 3 pha (25 ms)
        if (current_tick - last_current_tick >= 25) {
            last_current_tick = current_tick;
            can.sendCurrents(g_ia, g_ib, g_ic, g_enable_fw ? 1 : 0, g_id);
        }
    }
}
