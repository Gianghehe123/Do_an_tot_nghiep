#include "as5047p.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

AS5047P::AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs)
    : hspi_(hspi), cs_port_(cs_port), cs_pin_(cs_pin), pole_pairs_(pole_pairs) {}

void AS5047P::init() {
    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_SET);
    HAL_Delay(10);
    readRegister(CMD_ANGLECOM);
    first_run_ = true;
    accum_counts_ = 0;
    vel_rpm_ = 0.0f;
    last_vel_tick_ = HAL_GetTick();
}

bool AS5047P::checkParity(uint16_t data) {
    uint8_t count = 0;
    for (int i = 0; i < 16; ++i) {
        if (data & (1 << i)) count++;
    }
    return (count % 2 == 0);
}

uint16_t AS5047P::readRegister(uint16_t cmd) {
    uint16_t rx_data = 0;
    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_RESET);
    for(volatile int i = 0; i < 15; ++i);

    HAL_SPI_TransmitReceive(hspi_, reinterpret_cast<uint8_t*>(&cmd),
                            reinterpret_cast<uint8_t*>(&rx_data), 1, 10);

    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_SET);
    for(volatile int i = 0; i < 25; ++i);

    return rx_data;
}

float AS5047P::interpolateLUT(uint16_t counts) {
    if (!is_calibrated_) return 0.0f;

    uint8_t idx = (counts >> 7) & 0x7F;
    uint8_t idx_next = (idx + 1) & 0x7F;
    float frac = static_cast<float>(counts & 0x7F) / 128.0f;

    return lut_[idx] + frac * (lut_[idx_next] - lut_[idx]);
}

bool AS5047P::update() {
    uint16_t rx_data = readRegister(CMD_ANGLECOM);
    if ((rx_data & (1 << 14)) || !checkParity(rx_data)) {
        has_error_ = true;
        return false;
    }

    has_error_ = false;
    raw_data_ = rx_data & 0x3FFF;

    if (first_run_) {
        prev_raw_data_ = raw_data_;
        first_run_ = false;
    }

    int16_t d_cnt = static_cast<int16_t>(raw_data_ - prev_raw_data_);
    if (d_cnt > 8192)  d_cnt -= 16384;
    if (d_cnt < -8192) d_cnt += 16384;
    prev_raw_data_ = raw_data_;
    accum_counts_ += d_cnt;

    // 1. Góc thô (Raw)
    raw_mech_rad_ = (static_cast<float>(raw_data_) / RESOLUTION) * (2.0f * M_PI);
    raw_elec_rad_ = std::fmod(raw_mech_rad_ * static_cast<float>(pole_pairs_), 2.0f * M_PI);
    if (raw_elec_rad_ < 0.0f) raw_elec_rad_ += 2.0f * M_PI;

    // 2. Góc bù LUT 128 điểm (Linearized)
    float correction = interpolateLUT(raw_data_);
    float corr_rad = raw_mech_rad_ + correction - zero_offset_;
    while (corr_rad >= 2.0f * M_PI) corr_rad -= 2.0f * M_PI;
    while (corr_rad < 0.0f)        corr_rad += 2.0f * M_PI;

    calib_mech_rad_ = corr_rad;
    calib_elec_rad_ = std::fmod(corr_rad * static_cast<float>(pole_pairs_), 2.0f * M_PI);
    if (calib_elec_rad_ < 0.0f) calib_elec_rad_ += 2.0f * M_PI;

    // 3. Tính vận tốc
    uint32_t now = HAL_GetTick();
    uint32_t dt_ms = now - last_vel_tick_;
    if (dt_ms >= 50) {
        last_vel_tick_ = now;
        float dt_sec = static_cast<float>(dt_ms) / 1000.0f;
        float turns = static_cast<float>(accum_counts_) / RESOLUTION;
        accum_counts_ = 0;

        float inst_rpm = (turns / dt_sec) * 60.0f;
        vel_rpm_ += 0.25f * (inst_rpm - vel_rpm_);
        if (std::abs(vel_rpm_) < 0.35f) vel_rpm_ = 0.0f;
    }

    return true;
}

void AS5047P::setLUT(const float* lut, float zero_offset) {
    for (int i = 0; i < LUT_SIZE; ++i) {
        lut_[i] = lut[i];
    }
    zero_offset_ = zero_offset;
    is_calibrated_ = true;
}
