import serial
import struct
import time
import threading
import sys
import msvcrt
from collections import deque
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

PORT = "COM6"
BAUDRATE = 115200

try:
    ser = serial.Serial(PORT, BAUDRATE, timeout=0.05)
except Exception as e:
    print(f"\n[LOI] Khong the mo cong {PORT}: {e}")
    sys.exit(1)

ser.write(b"C\r")
time.sleep(0.05)
ser.write(b"O\r")
time.sleep(0.1)

is_running = True
latest_state = 0
is_lut_active = 0
is_fw_active = 0
latest_rpm = 0.0
latest_vq = 0.0
latest_raw_counts = 0
current_target_rpm = 0.0

latest_ia = 0.0
latest_ib = 0.0
latest_ic = 0.0
latest_id = 0.0

STATE_NAMES = {0: "IDLE (Dung)", 1: "CALIBRATING (Quet 1260 mau)", 2: "RUNNING (Dang chay FOC)", 3: "ERROR (Offset Shunt loi!)"}

BUFFER_LEN = 300
start_time = time.time()
buf_time   = deque([0.0, 0.025], maxlen=BUFFER_LEN)
buf_ia     = deque([0.0, 0.0],   maxlen=BUFFER_LEN)
buf_ib     = deque([0.0, 0.0],   maxlen=BUFFER_LEN)
buf_ic     = deque([0.0, 0.0],   maxlen=BUFFER_LEN)
buf_id     = deque([0.0, 0.0],   maxlen=BUFFER_LEN)

received_lut = np.zeros(128)
received_mask = np.zeros(128, dtype=bool)

def send_can_cmd(cmd_id, payload=0.0):
    data = bytearray(8)
    data[0] = cmd_id
    data[1:5] = struct.pack('<f', float(payload))
    hex_str = data.hex().upper()
    ser.write(f"t1008{hex_str}\r".encode('ascii'))

def rx_listener():
    global latest_state, is_lut_active, is_fw_active, latest_rpm, latest_vq, latest_raw_counts
    global latest_ia, latest_ib, latest_ic, latest_id
    buffer = ""
    while is_running:
        try:
            if ser.in_waiting > 0:
                raw_bytes = ser.read(ser.in_waiting)
                buffer += raw_bytes.decode('ascii', errors='ignore')

                while '\r' in buffer:
                    line, buffer = buffer.split('\r', 1)
                    line = line.strip()

                    # 0x102: Status
                    if line.startswith("t1028") and len(line) == 21:
                        data = bytes.fromhex(line[5:21])
                        latest_state  = data[0]
                        is_lut_active = data[1]
                        rpm_scaled, vq_scaled, raw_counts = struct.unpack('<hhH', data[2:8])
                        latest_rpm = rpm_scaled / 10.0
                        latest_vq  = vq_scaled / 100.0
                        latest_raw_counts = raw_counts & 0x3FFF

                    # 0x105: Dòng 3 pha Ia, Ib, Ic và Id
                    elif line.startswith("t1058") and len(line) == 21:
                        data = bytes.fromhex(line[5:21])
                        ia_ma, ib_ma, ic_ma = struct.unpack('<hhh', data[0:6])
                        latest_ia = ia_ma / 1000.0
                        latest_ib = ib_ma / 1000.0
                        latest_ic = ic_ma / 1000.0
                        is_fw_active = data[6]
                        latest_id = float(struct.unpack('b', bytes([data[7]]))[0]) * 0.1

                        t_now = time.time() - start_time
                        buf_time.append(t_now)
                        buf_ia.append(latest_ia)
                        buf_ib.append(latest_ib)
                        buf_ic.append(latest_ic)
                        buf_id.append(latest_id)

                    # 0x104: LUT
                    elif line.startswith("t1048") and len(line) == 21:
                        data = bytes.fromhex(line[5:21])
                        idx = data[0]
                        if idx < 128:
                            val = struct.unpack('<f', data[1:5])[0]
                            received_lut[idx] = val
                            received_mask[idx] = True

        except Exception:
            pass
        time.sleep(0.001)

threading.Thread(target=rx_listener, daemon=True).start()

def show_3phase_current_scope():
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 8.5), sharex=True)
    fig.canvas.manager.set_window_title("3-PHASE CURRENTS & D-AXIS SCOPE (BALANCED VERIFICATION)")

    line_ia, = ax1.plot(list(buf_time), list(buf_ia), color="tab:red",   linewidth=1.8, label="Phase A (Ia)")
    line_ib, = ax1.plot(list(buf_time), list(buf_ib), color="tab:green", linewidth=1.8, label="Phase B (Ib)")
    line_ic, = ax1.plot(list(buf_time), list(buf_ic), color="tab:blue",  linewidth=1.8, label="Phase C (Ic)")
    ax1.axhline(0, color="black", linestyle="--", alpha=0.5, linewidth=1.0)
    ax1.set_ylabel("Current (Ampe)", fontsize=10)
    ax1.grid(True, linestyle=":")
    ax1.legend(loc="upper right")
    ax1.set_title("1. Real-Time 3-Phase AC Currents (Đối Xứng Qua Trục 0A)", fontweight="bold")

    line_id, = ax2.plot(list(buf_time), list(buf_id), color="crimson", linewidth=2.0, label="D-axis Current (Id - Đã Lọc LPF)")
    ax2.axhline(0, color="black", linestyle="--", alpha=0.5, linewidth=1.0)
    ax2.set_xlabel("Time (s)", fontsize=10)
    ax2.set_ylabel("Id (Ampe)", fontsize=10)
    ax2.set_ylim(-3.0, 3.0)
    ax2.grid(True, linestyle=":")
    ax2.legend(loc="upper right")
    ax2.set_title("2. D-axis Current (Khóa Vd=0 -> Id Nằm Im Phẳng Lì Quanh 0A)", fontweight="bold")

    def animate(frame):
        t = list(buf_time)
        ax1.set_xlim(t[0], max(t[-1], t[0] + 3.0))

        line_ia.set_data(t, list(buf_ia))
        line_ib.set_data(t, list(buf_ib))
        line_ic.set_data(t, list(buf_ic))
        line_id.set_data(t, list(buf_id))

        all_cur = list(buf_ia) + list(buf_ib) + list(buf_ic)
        if all_cur:
            max_c = max(max(np.abs(all_cur)), 0.6)
            ax1.set_ylim(-max_c * 1.35, max_c * 1.35)

        fw_str = "BAT (FW ON: Id < 0)" if is_fw_active == 1 else "KHOA (FW OFF: Vd = 0V)"
        fig.suptitle(f"RPM: {latest_rpm:+5.1f} | Ia: {latest_ia:+4.2f}A | Ib: {latest_ib:+4.2f}A | Ic: {latest_ic:+4.2f}A | Id: {latest_id:+4.2f}A | [{fw_str}]",
                     fontsize=11, fontweight="bold", color="darkblue")
        return line_ia, line_ib, line_ic, line_id

    ani = animation.FuncAnimation(fig, animate, interval=30, blit=False, cache_frame_data=False)
    plt.tight_layout()
    plt.show()

def run_menu():
    global current_target_rpm
    print("\n" + "="*72)
    print("      HE THONG DO DONG 3 PHA CAN BANG & BU TU TRUONG (ODRIVE 3.5)")
    print("="*72)
    print(" [ i ]            : MO DO THI DONG 3 PHA (Ia, Ib, Ic) & Id SCOPE")
    print(" [ 1 ]            : TEST SOG SIN CHUAN: DAT +5 RPM (Khử Aliasing)")
    print(" [ f ]            : BAT / TAT BU TU TRUONG (Field Weakening: Id < 0)")
    print(" [ m ]            : CHUYEN DOI GOC: [RAW CHUA BU] <---> [LUT DA BU]")
    print(" [ c ]            : CHAY QUET CALIB LUT 128 (Mat ~12s)")
    print(" [ + ] / [ - ]    : TANG / GIAM TOC DO (+/- 10 RPM)")
    print(" [ Space ] / [ s ]: DUNG KHAN CAP (0 RPM / Disarm)")
    print(" [ q ]            : THOAT")
    print("="*72)

    last_print = 0
    while True:
        if time.time() - last_print > 0.15:
            last_print = time.time()
            st_text = STATE_NAMES.get(latest_state, "Unknown")
            fw_text = "FW: ON" if is_fw_active == 1 else "FW: OFF (Vd=0)"
            lut_text = "LUT" if is_lut_active == 1 else "RAW"
            sys.stdout.write(f"\r>> RPM: {latest_rpm:+5.1f} | Ia: {latest_ia:+4.2f}A | Ib: {latest_ib:+4.2f}A | Ic: {latest_ic:+4.2f}A | [{lut_text}] | [{fw_text}] | {st_text}   ")
            sys.stdout.flush()

        if msvcrt.kbhit():
            ch = msvcrt.getch().decode('ascii', errors='ignore')

            if ch in ['i', 'I']:
                show_3phase_current_scope()
            elif ch == '1':
                current_target_rpm = 5.0
                send_can_cmd(0x03, current_target_rpm)
                print("\n[TEST SIN] Da dat van toc +5.0 RPM de giam tan so dien (Khử méo Aliasing)")
            elif ch in ['f', 'F']:
                new_fw = 0 if is_fw_active == 1 else 1
                send_can_cmd(0x06, float(new_fw))
                fw_label = "BAT (Field Weakening ON)" if new_fw == 1 else "KHOA (Field Weakening OFF: Vd = 0V)"
                print(f"\n[FIELD WEAKENING] {fw_label}")
            elif ch in ['m', 'M']:
                new_mode = 0 if is_lut_active == 1 else 1
                send_can_cmd(0x05, float(new_mode))
                mode_label = "LUT (Da Bu)" if new_mode == 1 else "RAW (Chua Bu)"
                print(f"\n[MODE] {mode_label}")
            elif ch in ['c', 'C']:
                print("\n[CALIB] Dang quet 1260 diem...")
                received_mask.fill(False)
                send_can_cmd(0x04)
            elif ch in ['+', '=']:
                current_target_rpm += 10.0
                send_can_cmd(0x03, current_target_rpm)
            elif ch in ['-', '_']:
                current_target_rpm -= 10.0
                send_can_cmd(0x03, current_target_rpm)
            elif ch in ['s', 'S', ' ', '0']:
                current_target_rpm = 0.0
                send_can_cmd(0x01)
                print("\n[STOP] DA DUNG DONG CO!")
            elif ch in ['q', 'Q']:
                current_target_rpm = 0.0
                send_can_cmd(0x01)
                print("\nDa thoat.")
                break
        time.sleep(0.01)

if __name__ == "__main__":
    try:
        run_menu()
    except KeyboardInterrupt:
        send_can_cmd(0x01)
        ser.close()