import os
import sys
import csv
import time
import queue
import struct
import threading
from datetime import datetime
from collections import deque

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import matplotlib.style as mplstyle
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

# Kích hoạt chế độ vẽ nhanh của Matplotlib
mplstyle.use('fast')
plt.rcParams['path.simplify'] = True
plt.rcParams['path.simplify_threshold'] = 1.0
plt.rcParams['agg.path.chunksize'] = 10000

# Vô hiệu hóa phím tắt mặc định của Matplotlib để không xung đột phím điều khiển
plt.rcParams['keymap.save'] = []
plt.rcParams['keymap.fullscreen'] = []
plt.rcParams['keymap.yscale'] = []
plt.rcParams['keymap.xscale'] = []

try:
    import serial
    import serial.tools.list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

STATE_SHORT = {0: "IDLE", 1: "CALIB", 2: "RUN", 3: "COLLISION", 4: "ERR"}
STATE_COLORS = {
    0: "#6c757d",  # IDLE - Xám
    1: "#fd7e14",  # CALIB - Cam
    2: "#198754",  # RUN - Xanh lá
    3: "#dc3545",  # COLLISION - Đỏ
    4: "#dc3545",  # ERR - Đỏ
}

# =============================================================================
# ĐƯỜNG TRUYỀN CAN <-> MÁY TÍNH
#   USB-CAN-A (chip CH340, giao thức Waveshare "biến độ dài"), serial 2 000 000 baud:
#     khung : AA | 0xC0 + (ext<<5) + (remote<<4) + DLC | ID (2 byte, byte thấp trước) | dữ liệu | 55
#     cài đặt (20 byte): AA 55 12 | tốc độ | loại khung | lọc 4B | mặt nạ 4B | chế độ | tự gửi lại | 4x00 | checksum
#   ESP32 (SLCAN, ASCII): "tIIIL<dữ liệu hex>\r"
# =============================================================================
TRANSPORT_USBCANA = "USB-CAN-A (CH340)"
TRANSPORT_SLCAN = "ESP32 (SLCAN)"
TRANSPORT_DEFAULT_BAUD = {TRANSPORT_USBCANA: 2000000, TRANSPORT_SLCAN: 115200}
# Mã tốc độ CAN của USB-CAN-A. STM32 đang chạy 250 kbit/s (CAN1: Prescaler 12, BS1 11TQ, BS2 2TQ, APB1 42 MHz)
USBCANA_BITRATE_CODE = {"1000k": 0x01, "500k": 0x03, "250k": 0x05, "125k": 0x07, "100k": 0x08}
CAN_BITRATE_DEFAULT = "250k"


def usbcana_config_packet(bitrate_code: int, auto_retransmit: bool = True) -> bytes:
    """Lệnh cài đặt 20 byte (kiểu 0x12 = giao thức biến độ dài), nhận mọi ID chuẩn (lọc 0, mặt nạ 0), chế độ thường."""
    p = bytearray(20)
    p[0], p[1], p[2] = 0xAA, 0x55, 0x12
    p[3] = bitrate_code & 0xFF
    p[4] = 0x01                                   # khung chuẩn 11 bit
    # p[5..8] = ID lọc, p[9..12] = mặt nạ: để 0 -> nhận tất cả
    p[13] = 0x00                                  # chế độ thường (không loopback, không im lặng)
    p[14] = 0x00 if auto_retransmit else 0x01     # 0x00 = tự gửi lại khi lỗi
    p[19] = sum(p[2:19]) & 0xFF                   # 8 bit thấp của tổng từ byte loại tới byte 18
    return bytes(p)


def usbcana_encode(can_id: int, data: bytes) -> bytes:
    """Khung dữ liệu chuẩn 11 bit."""
    data = bytes(data[:8])
    return bytes([0xAA, 0xC0 | len(data), can_id & 0xFF, (can_id >> 8) & 0x07]) + data + b"\x55"


def slcan_encode(can_id: int, data: bytes) -> bytes:
    data = bytes(data[:8])
    return f"t{can_id & 0x7FF:03X}{len(data)}{data.hex().upper()}\r".encode("ascii")


class UsbCanAParser:
    """Tách khung từ luồng byte USB-CAN-A. Tự đồng bộ lại khi mất byte: kiểm tra byte loại (2 bit cao = 11, DLC <= 8),
    byte kết thúc 0x55 và ID chuẩn <= 0x7FF; sai thì bỏ 1 byte và tìm 0xAA kế tiếp."""

    def __init__(self):
        self.buf = bytearray()
        self.bad_bytes = 0      # số byte bị bỏ do mất đồng bộ (để chẩn đoán)

    def feed(self, chunk: bytes):
        self.buf += chunk
        out = []
        while True:
            i = self.buf.find(0xAA)
            if i < 0:
                self.bad_bytes += len(self.buf)
                self.buf.clear()
                break
            if i > 0:
                self.bad_bytes += i
                del self.buf[:i]
            if len(self.buf) < 2:
                break
            t = self.buf[1]
            if (t & 0xC0) != 0xC0 or (t & 0x0F) > 8:      # không phải khung dữ liệu (vd gói 20 byte "AA 55 ...")
                del self.buf[:1]
                self.bad_bytes += 1
                continue
            ext = bool(t & 0x20)
            dlc = t & 0x0F
            id_len = 4 if ext else 2
            n = 2 + id_len + dlc + 1
            if len(self.buf) < n:
                break
            cid = int.from_bytes(self.buf[2:2 + id_len], "little")
            if self.buf[n - 1] != 0x55 or (not ext and cid > 0x7FF):
                del self.buf[:1]
                self.bad_bytes += 1
                continue
            data = bytes(self.buf[2 + id_len:2 + id_len + dlc])
            del self.buf[:n]
            if not (t & 0x10):                            # bỏ khung remote
                out.append((cid, data))
        if len(self.buf) > 4096:
            del self.buf[:-64]
        return out


class SlcanParser:
    """Tách khung SLCAN "tIIIL..." kết thúc bằng '\\r'."""

    def __init__(self):
        self.buf = ""
        self.bad_bytes = 0

    def feed(self, chunk: bytes):
        self.buf += chunk.decode("ascii", errors="ignore")
        out = []
        while "\r" in self.buf:
            line, self.buf = self.buf.split("\r", 1)
            line = line.strip()
            try:
                if len(line) >= 5 and line[0] == "t":
                    dlc = int(line[4])
                    if 0 <= dlc <= 8 and len(line) >= 5 + 2 * dlc:
                        out.append((int(line[1:4], 16), bytes.fromhex(line[5:5 + 2 * dlc])))
                        continue
                self.bad_bytes += len(line) + 1
            except ValueError:
                self.bad_bytes += len(line) + 1
        if len(self.buf) > 8192:
            self.buf = self.buf[-256:]
        return out


# Thư mục lưu log = thư mục chứa chính file .py này
LOG_DIR = os.path.dirname(os.path.abspath(__file__))
# Tên lệnh để ghi vào nhật ký sự kiện
CMD_NAMES = {
    0x01: "DỪNG", 0x02: "ARM", 0x03: "ĐẶT Iq (A)", 0x04: "CALIB LUT", 0x05: "LUT bật/tắt", 0x06: "FW bật/tắt",
    0x07: "ĐẶT TỐC ĐỘ (RPM)", 0x08: "NGƯỠNG GMO (N.m)", 0x09: "TRẦN TỐC ĐỘ MÔ-MEN (RPM)",
    0x0A: "TỐC ĐỘ CÁNH TAY (°/s)", 0x0B: "GÓC ĐÍCH (°)", 0x0C: "ĐẶT GÓC 0", 0x0D: "CHẠY CHU TRÌNH (1) / VỀ 0 (0)",
}

# Pha của chế độ vị trí (khớp enum PosPhase trong device.h)
POS_PHASE_NAMES = {
    0: "TẮT", 1: "ĐỨNG GIỮ", 2: "VỀ 0", 3: "ĐI -> ĐÍCH", 4: "DỪNG Ở ĐÍCH",
    5: "VỀ -> 0", 6: "DỪNG Ở 0", 7: "RÚT LUI!", 8: "CHỜ SAU VA CHẠM",
}
POS_SPEED_MAX = 180.0     # khớp __POS_SPEED_MAX_DEG_S
POS_TARGET_MAX = 350.0    # khớp __POS_TARGET_LIMIT_DEG

GUI_REFRESH_MS = 60           # ~16 FPS: mượt và dư thời gian CPU cho sự kiện chuột/bàn phím/Zoom
CMD_DEBOUNCE_S = 0.5          # Chỉ chống lặp cho Arm (0x02) và Calib (0x04), KHÔNG chặn lệnh Stop (0x01)
TARGET_THROTTLE_S = 0.030     # Gom lệnh khi giữ phím +/- (tối đa ~33 lệnh/giây xuống ESP32)


class FOCGMOTkApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("GIM8108-8 | 20kHz MIN-MAX FOC + GMO COLLISION DETECTION & DATA LOGGER")
        self.root.geometry("1420x890")
        self.root.minsize(1140, 740)
        self.root.configure(bg="#f4f6f9")

        # --- Biến truyền thông Serial / CAN (Tách khóa TX khỏi RX) ---
        self.ser = None
        self.is_connected = False
        self.is_running = True
        self.tx_lock = threading.Lock()
        self.tx_queue = queue.Queue()

        self._rx_count = 0
        self._drawn_rx_count = -1
        self._ylim_cache = {}
        self._widget_cache = {}
        self._last_cmd_time = {}
        self._pending_target_cmd = None
        self._last_target_send_t = 0.0
        self.pause_scope = False

        # --- Trạng thái động cơ & Cờ điều khiển ---
        self.latest_state = 0
        self.is_lut_active = 1
        self.is_fw_active = 0
        self.is_torque_mode = 0  # 0: SPEED Mode (RPM), 1: TORQUE Mode (Iq)
        self.is_position_mode = 0  # 1: chế độ vị trí (cánh tay gạt) - cờ bit3 gói 0x102
        self._rx_parser = UsbCanAParser()          # thay khi kết nối, theo thiết bị đã chọn
        self.rx_id_count = {}                      # số gói nhận được theo từng ID (chẩn đoán đường truyền)
        self.event_records = []                    # nhật ký sự kiện: va chạm, rút về, đổi trạng thái, lệnh gửi
        self._ev_last_state = None
        self._ev_last_phase = None
        self._ev_last_coll = 0
        self._diag_flags = set()
        self._connect_time = time.time()
        self._tx_transport = TRANSPORT_USBCANA

        # --- Chế độ vị trí (gói 0x109): góc trục ra [độ], dương = ngược chiều kim đồng hồ ---
        self.pos_angle = 0.0
        self.pos_ref = 0.0
        self.pos_phase = 0
        self.pos_flags = 0
        self.pos_speed = 60.0    # độ/s (lệnh 0x0A)
        self.pos_target = 90.0   # độ (lệnh 0x0B)

        # --- Giá trị đặt (Targets) ---
        self.current_target_rpm = 0.0
        self.current_target_iq = 0.00
        self.torque_speed_limit_rpm = 60.0  # Tốc độ bão hòa khi chạy ở chế độ Torque Mode (RPM)

        # --- Đo lường thực tế ---
        self.latest_rpm = 0.0
        self.latest_vq = 0.0
        self.latest_raw_counts = 0
        self.latest_ia = 0.0
        self.latest_ib = 0.0
        self.latest_ic = 0.0
        self.latest_id = 0.0
        self.latest_iq = 0.0

        # --- GMO & Phát hiện va chạm ---
        self.latest_tau_ext = 0.0
        self.latest_tau_thresh = 0.045
        self.is_collided = 0
        self.countdown_sec = 0

        # --- Chẩn đoán thời gian thực từ gói 0x107 ---
        self.timing_diag_str = "FOC: -- us | ISR: -- us | Mất: 0"

        # --- Bộ đệm hiển thị Real-time Scope (Cửa sổ trượt) ---
        self.buffer_len = 260
        self.start_time = time.time()
        self.buf_time       = deque([0.0, 0.025], maxlen=self.buffer_len)
        self.buf_rpm        = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_rpm_ref    = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_iq         = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_iq_ref     = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_id         = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_tau_ext    = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_tau_thresh = deque([0.045, 0.045], maxlen=self.buffer_len)
        self.buf_pos        = deque([0.0, 0.0],   maxlen=self.buffer_len)
        self.buf_pos_ref    = deque([0.0, 0.0],   maxlen=self.buffer_len)

        # --- Bộ đệm Ghi Log toàn phiên (Full-Session Data Logger) ---
        self.is_logging = True
        self.log_lock = threading.Lock()
        self.log_records = []

        # --- Bảng LUT 128 điểm ---
        self.received_lut = np.zeros(128)
        self.received_mask = np.zeros(128, dtype=bool)

        # Xây dựng giao diện
        self._build_ui()
        self._bind_shortcuts()
        self._set_torque_limit_ui_state(self.is_torque_mode == 1)

        # Tự động kết nối cổng mặc định (COM6) nếu có sẵn
        self.connect_serial(silent_on_fail=True)

        # Khởi chạy luồng đọc CAN, luồng gửi CAN và vòng lặp cập nhật đồ thị
        self.rx_thread = threading.Thread(target=self._rx_listener_loop, daemon=True)
        self.rx_thread.start()

        self.tx_thread = threading.Thread(target=self._tx_worker_loop, daemon=True)
        self.tx_thread.start()

        self.root.after(GUI_REFRESH_MS, self._update_gui_loop)
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    # =========================================================================
    # XÂY DỰNG GIAO DIỆN TKINTER
    # =========================================================================
    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#f4f6f9")
        style.configure("TLabelframe", background="#ffffff", borderwidth=1, relief="solid")
        style.configure("TLabelframe.Label", background="#ffffff", foreground="#1e293b", font=("Segoe UI", 9, "bold"))
        style.configure("TLabel", background="#ffffff", foreground="#1e293b", font=("Segoe UI", 9))

        # --- Thanh Banner Trạng Thái Trên Cùng ---
        self.top_banner = tk.Frame(self.root, bg="#1e3a8a", height=40)
        self.top_banner.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(6, 3))
        self.lbl_banner = tk.Label(
            self.top_banner,
            text="[SPEED MODE: RPM* = +0]  |  RPM: +0.0  |  Iq: +0.00A  |  Id: +0.00A  |  Uq: +0.0V  |  Tau: +0.000/0.045 Nm  |  [LUT:ON] [FW:OFF]",
            bg="#1e3a8a", fg="#ffffff", font=("Consolas", 10, "bold"), pady=7
        )
        self.lbl_banner.pack(fill=tk.X)

        # --- Khung Chính Chia Trái (Bảng điều khiển) & Phải (3 Biểu đồ Scope) ---
        main_pane = tk.Frame(self.root, bg="#f4f6f9")
        main_pane.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=3)

        # Cột trái CUỘN ĐƯỢC (con lăn chuột hoặc thanh cuộn): trên màn hình thấp hoặc Windows phóng to 125-150%,
        # các khung phía dưới (chế độ vị trí, xuất log) không bị khuất mất.
        left_outer = tk.Frame(main_pane, bg="#f4f6f9", width=378)
        left_outer.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 6))
        left_outer.pack_propagate(False)
        self._left_canvas = tk.Canvas(left_outer, bg="#f4f6f9", highlightthickness=0, bd=0)
        left_vsb = ttk.Scrollbar(left_outer, orient=tk.VERTICAL, command=self._left_canvas.yview)
        self._left_canvas.configure(yscrollcommand=left_vsb.set)
        left_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._left_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        left_panel = tk.Frame(self._left_canvas, bg="#f4f6f9")
        left_win = self._left_canvas.create_window((0, 0), window=left_panel, anchor="nw")
        left_panel.bind("<Configure>", lambda e: self._left_canvas.configure(scrollregion=self._left_canvas.bbox("all")))
        self._left_canvas.bind("<Configure>", lambda e: self._left_canvas.itemconfigure(left_win, width=e.width))

        def _left_wheel(e):
            # Chỉ cuộn khi con trỏ đang nằm trên cột trái
            w = self.root.winfo_containing(e.x_root, e.y_root)
            while w is not None and w is not left_outer:
                w = getattr(w, "master", None)
            if w is None:
                return
            if getattr(e, "num", None) == 4:
                step = -1
            elif getattr(e, "num", None) == 5:
                step = 1
            else:
                step = -1 if e.delta > 0 else 1
            self._left_canvas.yview_scroll(step * 2, "units")
        self.root.bind_all("<MouseWheel>", _left_wheel, add="+")
        self.root.bind_all("<Button-4>", _left_wheel, add="+")
        self.root.bind_all("<Button-5>", _left_wheel, add="+")

        right_panel = tk.Frame(main_pane, bg="#ffffff", bd=1, relief=tk.SOLID)
        right_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ---------------------------------------------------------------------
        # CỘT TRÁI: CÁC KHỐI ĐIỀU KHIỂN & XUẤT LOG
        # ---------------------------------------------------------------------
        # 1. Kết nối USB-CAN (ESP32 / SLCAN)
        frm_conn = ttk.LabelFrame(left_panel, text="1. Kết nối CAN-USB", padding=4)
        frm_conn.pack(fill=tk.X, pady=(0, 3))

        row_c0 = tk.Frame(frm_conn, bg="#ffffff")
        row_c0.pack(fill=tk.X, pady=1)
        tk.Label(row_c0, text="Thiết bị:", bg="#ffffff", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self.var_transport = tk.StringVar(value=TRANSPORT_USBCANA)
        self.cmb_transport = ttk.Combobox(row_c0, textvariable=self.var_transport, width=17, state="readonly",
                                          values=[TRANSPORT_USBCANA, TRANSPORT_SLCAN], font=("Segoe UI", 9))
        self.cmb_transport.pack(side=tk.LEFT, padx=4)
        self.cmb_transport.bind("<<ComboboxSelected>>", self._on_transport_changed)
        tk.Label(row_c0, text="CAN:", bg="#ffffff", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(4, 2))
        self.var_canrate = tk.StringVar(value=CAN_BITRATE_DEFAULT)
        self.cmb_canrate = ttk.Combobox(row_c0, textvariable=self.var_canrate, width=6, state="readonly",
                                        values=list(USBCANA_BITRATE_CODE.keys()), font=("Segoe UI", 9))
        self.cmb_canrate.pack(side=tk.LEFT, padx=2)

        row_c1 = tk.Frame(frm_conn, bg="#ffffff")
        row_c1.pack(fill=tk.X, pady=1)
        tk.Label(row_c1, text="Cổng COM:", bg="#ffffff", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self.var_port = tk.StringVar(value="COM6")
        self.cmb_port = ttk.Combobox(row_c1, textvariable=self.var_port, width=9, font=("Segoe UI", 9))
        self.cmb_port.pack(side=tk.LEFT, padx=4)
        self._refresh_com_ports()

        tk.Label(row_c1, text="Baud:", bg="#ffffff", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(4, 2))
        self.var_baud = tk.StringVar(value=str(TRANSPORT_DEFAULT_BAUD[TRANSPORT_USBCANA]))
        self.ent_baud = ttk.Entry(row_c1, textvariable=self.var_baud, width=8, font=("Segoe UI", 9))
        self.ent_baud.pack(side=tk.LEFT, padx=2)

        row_c2 = tk.Frame(frm_conn, bg="#ffffff")
        row_c2.pack(fill=tk.X, pady=(4, 1))
        self.btn_connect = tk.Button(
            row_c2, text="Kết nối COM", bg="#0d6efd", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, padx=8, pady=3,
            command=self.toggle_connection
        )
        self.btn_connect.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))

        btn_refresh = tk.Button(
            row_c2, text="Quét COM", bg="#e2e8f0", fg="#1e293b",
            font=("Segoe UI", 9), relief=tk.FLAT, padx=8, pady=3,
            command=self._refresh_com_ports
        )
        btn_refresh.pack(side=tk.LEFT)

        btn_quick_log = tk.Button(
            row_c2, text="💾 Lưu log", bg="#7c3aed", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, padx=8, pady=3,
            command=self.export_and_show_log_chart
        )
        btn_quick_log.pack(side=tk.LEFT, padx=(4, 0))

        # 2. Giám sát thông số Real-time
        frm_tele = ttk.LabelFrame(left_panel, text="2. Thông số Đo lường Thực tế", padding=4)
        frm_tele.pack(fill=tk.X, pady=4)

        grid_t = tk.Frame(frm_tele, bg="#ffffff")
        grid_t.pack(fill=tk.X)
        for col in range(2):
            grid_t.columnconfigure(col, weight=1)

        self.lbl_state_badge = tk.Label(
            grid_t, text="TRẠNG THÁI: IDLE", bg="#6c757d", fg="white",
            font=("Segoe UI", 9, "bold"), pady=3
        )
        self.lbl_state_badge.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))

        self.var_tele_rpm = tk.StringVar(value="0.0 RPM")
        self.var_tele_vq  = tk.StringVar(value="0.00 V")
        self.var_tele_iq  = tk.StringVar(value="0.000 A")
        self.var_tele_id  = tk.StringVar(value="0.000 A")
        self.var_tele_tau = tk.StringVar(value="0.000 Nm")
        self.var_tele_enc = tk.StringVar(value="0")

        self._create_metric_box(grid_t, 1, 0, "Vận tốc (RPM):", self.var_tele_rpm, "#0284c7")
        self._create_metric_box(grid_t, 1, 1, "Điện áp Uq:", self.var_tele_vq, "#4f46e5")
        self._create_metric_box(grid_t, 2, 0, "Dòng Iq (Mô-men):", self.var_tele_iq, "#1d4ed8")
        self._create_metric_box(grid_t, 2, 1, "Dòng Id (Từ thông):", self.var_tele_id, "#be123c")
        self._create_metric_box(grid_t, 3, 0, "Ngoại lực Tau_ext:", self.var_tele_tau, "#7e22ce")
        self._create_metric_box(grid_t, 3, 1, "Xung Encoder:", self.var_tele_enc, "#334155")

        self.var_timing_diag = tk.StringVar(value="FOC: -- us | ISR: -- us | Mất: 0")
        tk.Label(frm_tele, textvariable=self.var_timing_diag, bg="#ffffff", fg="#475569", font=("Consolas", 8)).pack(anchor="w", pady=(3, 0))

        # 3. Điều khiển Động cơ & Chế độ
        frm_ctrl = ttk.LabelFrame(left_panel, text="3. Bảng Điều khiển FOC & GMO", padding=4)
        frm_ctrl.pack(fill=tk.X, pady=4)

        self.btn_mode = tk.Button(
            frm_ctrl, text="[T] Chế độ: SPEED MODE (RPM)", bg="#0284c7", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('t')
        )
        self.btn_mode.pack(fill=tk.X, pady=(0, 4))

        # Tăng / Giảm mục tiêu
        row_step = tk.Frame(frm_ctrl, bg="#ffffff")
        row_step.pack(fill=tk.X, pady=1)
        btn_dec = tk.Button(
            row_step, text="[-] Giảm (-10 RPM / -0.05A)", bg="#e2e8f0", fg="#0f172a",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('-')
        )
        btn_dec.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))

        btn_inc = tk.Button(
            row_step, text="[+] Tăng (+10 RPM / +0.05A)", bg="#e2e8f0", fg="#0f172a",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('+')
        )
        btn_inc.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # Nhập trực tiếp giá trị đặt
        row_set = tk.Frame(frm_ctrl, bg="#ffffff")
        row_set.pack(fill=tk.X, pady=(4, 2))
        tk.Label(row_set, text="Đặt tốc độ/dòng:", bg="#ffffff", font=("Segoe UI", 8)).pack(side=tk.LEFT)
        self.var_direct_target = tk.StringVar(value="0.0")
        ent_target = ttk.Entry(row_set, textvariable=self.var_direct_target, width=8, font=("Segoe UI", 9))
        ent_target.pack(side=tk.LEFT, padx=4)
        ent_target.bind("<Return>", lambda e: self.apply_direct_target())
        btn_apply_target = tk.Button(
            row_set, text="Gửi Lệnh", bg="#0d9488", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, padx=6, pady=2,
            command=self.apply_direct_target
        )
        btn_apply_target.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Đặt tốc độ bão hòa khi ở chế độ TORQUE MODE (Lệnh 0x09 - Xám lại khi ở RPM Mode)
        row_tlim = tk.Frame(frm_ctrl, bg="#ffffff")
        row_tlim.pack(fill=tk.X, pady=(2, 2))
        self.lbl_trq_spd_lim = tk.Label(
            row_tlim, text="Bão hòa RPM (Torque):", bg="#ffffff", fg="#94a3b8", font=("Segoe UI", 8, "bold")
        )
        self.lbl_trq_spd_lim.pack(side=tk.LEFT)

        self.btn_trq_spd_dec = tk.Button(
            row_tlim, text="-", bg="#e2e8f0", fg="#94a3b8",
            font=("Consolas", 9, "bold"), relief=tk.FLAT, width=2, pady=1,
            command=lambda: self.step_torque_speed_limit(-10.0)
        )
        self.btn_trq_spd_dec.pack(side=tk.LEFT, padx=(3, 1))

        self.var_trq_spd_lim = tk.StringVar(value="60")
        self.ent_trq_spd_lim = ttk.Entry(row_tlim, textvariable=self.var_trq_spd_lim, width=5, font=("Segoe UI", 9))
        self.ent_trq_spd_lim.pack(side=tk.LEFT, padx=1)
        self.ent_trq_spd_lim.bind("<Return>", lambda e: self.apply_torque_speed_limit())

        self.btn_trq_spd_inc = tk.Button(
            row_tlim, text="+", bg="#e2e8f0", fg="#94a3b8",
            font=("Consolas", 9, "bold"), relief=tk.FLAT, width=2, pady=1,
            command=lambda: self.step_torque_speed_limit(10.0)
        )
        self.btn_trq_spd_inc.pack(side=tk.LEFT, padx=(1, 3))

        self.btn_apply_trq_spd = tk.Button(
            row_tlim, text="Set Bão Hòa", bg="#cbd5e1", fg="#64748b",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, padx=5, pady=2,
            command=self.apply_torque_speed_limit
        )
        self.btn_apply_trq_spd.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Đặt ngưỡng phát hiện va chạm GMO (Thresholding - Lệnh 0x08)
        row_thr = tk.Frame(frm_ctrl, bg="#ffffff")
        row_thr.pack(fill=tk.X, pady=(2, 3))
        tk.Label(row_thr, text="Ngưỡng GMO (Nm):", bg="#ffffff", fg="#b91c1c", font=("Segoe UI", 8, "bold")).pack(side=tk.LEFT)

        btn_thr_dec = tk.Button(
            row_thr, text="-", bg="#fee2e2", fg="#991b1b",
            font=("Consolas", 9, "bold"), relief=tk.FLAT, width=2, pady=1,
            command=lambda: self.step_gmo_threshold(-0.005)
        )
        btn_thr_dec.pack(side=tk.LEFT, padx=(3, 1))

        self.var_thresh_target = tk.StringVar(value="0.045")
        ent_thresh = ttk.Entry(row_thr, textvariable=self.var_thresh_target, width=6, font=("Segoe UI", 9))
        ent_thresh.pack(side=tk.LEFT, padx=1)
        ent_thresh.bind("<Return>", lambda e: self.apply_gmo_threshold())

        btn_thr_inc = tk.Button(
            row_thr, text="+", bg="#fee2e2", fg="#991b1b",
            font=("Consolas", 9, "bold"), relief=tk.FLAT, width=2, pady=1,
            command=lambda: self.step_gmo_threshold(0.005)
        )
        btn_thr_inc.pack(side=tk.LEFT, padx=(1, 3))

        btn_apply_thr = tk.Button(
            row_thr, text="Set Ngưỡng", bg="#e11d48", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, padx=5, pady=2,
            command=self.apply_gmo_threshold
        )
        btn_apply_thr.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Nút Dừng Khẩn Cấp & Arm
        row_emg = tk.Frame(frm_ctrl, bg="#ffffff")
        row_emg.pack(fill=tk.X, pady=3)
        btn_stop = tk.Button(
            row_emg, text="[Space] DỪNG KHẨN CẤP", bg="#dc2626", fg="white",
            font=("Segoe UI", 10, "bold"), relief=tk.FLAT, pady=5,
            command=lambda: self.process_key(' ')
        )
        btn_stop.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 3))

        btn_arm = tk.Button(
            row_emg, text="[A] ARM DRV", bg="#16a34a", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, padx=8, pady=5,
            command=lambda: self.process_key('a')
        )
        btn_arm.pack(side=tk.LEFT, padx=(3, 0))

        # Nút LUT, Field Weakening, Calib
        row_opt = tk.Frame(frm_ctrl, bg="#ffffff")
        row_opt.pack(fill=tk.X, pady=(3, 0))
        self.btn_lut = tk.Button(
            row_opt, text="[M] LUT: ON", bg="#15803d", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('m')
        )
        self.btn_lut.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))

        self.btn_fw = tk.Button(
            row_opt, text="[F] FW: OFF", bg="#64748b", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('f')
        )
        self.btn_fw.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)

        btn_calib = tk.Button(
            row_opt, text="[C] Calib LUT", bg="#d97706", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=lambda: self.process_key('c')
        )
        btn_calib.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # 4. Chế độ Vị trí - cánh tay gạt (lệnh 0x0A..0x0D, telemetry 0x109)
        frm_pos = ttk.LabelFrame(left_panel, text="4. Chế độ Vị trí - Cánh tay gạt (+ = ngược KĐH)", padding=5)
        frm_pos.pack(fill=tk.X, pady=4)

        row_p1 = tk.Frame(frm_pos, bg="#ffffff")
        row_p1.pack(fill=tk.X, pady=1)
        tk.Label(row_p1, text="Tốc độ (°/s):", bg="#ffffff", font=("Segoe UI", 8)).pack(side=tk.LEFT)
        self.var_pos_speed = tk.StringVar(value=f"{self.pos_speed:.0f}")
        ttk.Entry(row_p1, textvariable=self.var_pos_speed, width=5).pack(side=tk.LEFT, padx=(2, 6))
        tk.Label(row_p1, text="Góc đích (°):", bg="#ffffff", font=("Segoe UI", 8)).pack(side=tk.LEFT)
        self.var_pos_target = tk.StringVar(value=f"{self.pos_target:.0f}")
        ttk.Entry(row_p1, textvariable=self.var_pos_target, width=6).pack(side=tk.LEFT, padx=(2, 6))
        tk.Button(
            row_p1, text="Gửi", bg="#0d9488", fg="white", font=("Segoe UI", 8, "bold"),
            relief=tk.FLAT, padx=8, command=self.apply_pos_params
        ).pack(side=tk.LEFT, fill=tk.X, expand=True)

        row_p2 = tk.Frame(frm_pos, bg="#ffffff")
        row_p2.pack(fill=tk.X, pady=(3, 1))
        tk.Button(
            row_p2, text="Đặt góc 0 tại đây", bg="#64748b", fg="white", font=("Segoe UI", 8, "bold"),
            relief=tk.FLAT, pady=3, command=self.pos_set_zero
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
        tk.Button(
            row_p2, text="▶ Chạy 0 ↔ Đích", bg="#16a34a", fg="white", font=("Segoe UI", 8, "bold"),
            relief=tk.FLAT, pady=3, command=self.pos_start_cycle
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        tk.Button(
            row_p2, text="Về 0", bg="#0284c7", fg="white", font=("Segoe UI", 8, "bold"),
            relief=tk.FLAT, pady=3, command=self.pos_go_home
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # Dòng trạng thái: chữ CAM = chưa đặt góc 0 trong phiên này (góc 0 đang là vị trí lúc bật nguồn)
        self.var_pos_status = tk.StringVar(value="Góc  +0.00° | TẮT | VC 0")
        self.lbl_pos_status = tk.Label(frm_pos, textvariable=self.var_pos_status, bg="#ffffff", fg="#b45309",
                                       font=("Consolas", 9, "bold"))
        self.lbl_pos_status.pack(anchor="w", pady=(2, 0))

        # 5. Ghi & Xuất Log Biểu Đồ (Data Logger & Report)
        frm_log = ttk.LabelFrame(left_panel, text="5. Xuất Log & Hiển thị Biểu đồ Báo cáo", padding=4)
        frm_log.pack(fill=tk.X, pady=4)

        self.var_log_info = tk.StringVar(value="Đang ghi tự động: 0 mẫu")
        tk.Label(frm_log, textvariable=self.var_log_info, bg="#ffffff", fg="#0f172a", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 3))

        row_l1 = tk.Frame(frm_log, bg="#ffffff")
        row_l1.pack(fill=tk.X, pady=1)
        self.btn_toggle_log = tk.Button(
            row_l1, text="Tạm dừng Ghi", bg="#f59e0b", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=self.toggle_logging
        )
        self.btn_toggle_log.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))

        btn_clear_log = tk.Button(
            row_l1, text="Xóa Log Mới", bg="#64748b", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=self.clear_log_data
        )
        btn_clear_log.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)

        self.btn_pause_scope = tk.Button(
            row_l1, text="Đóng băng Zoom", bg="#0284c7", fg="white",
            font=("Segoe UI", 8, "bold"), relief=tk.FLAT, pady=4,
            command=self.toggle_pause_scope
        )
        self.btn_pause_scope.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # Nút chính: Xuất Log & Hiện Biểu Đồ
        row_l2 = tk.Frame(frm_log, bg="#ffffff")
        row_l2.pack(fill=tk.X, pady=(5, 1))
        btn_export_show = tk.Button(
            row_l2,
            text="📊 XUẤT LOG [L]",
            bg="#7c3aed", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, pady=5,
            command=self.export_and_show_log_chart
        )
        btn_export_show.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))

        btn_open_csv = tk.Button(
            row_l2,
            text="📂 Mở CSV cũ",
            bg="#e2e8f0", fg="#1e293b",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, pady=5,
            command=self.load_csv_and_show_chart
        )
        btn_open_csv.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # ---------------------------------------------------------------------
        # CỘT PHẢI: 3 BIỂU ĐỒ REAL-TIME (NHÚNG TRỰC TIẾP TRONG TKINTER)
        # ---------------------------------------------------------------------
        self.fig = Figure(figsize=(10.5, 8.6), dpi=95, facecolor="white")
        self.ax1 = self.fig.add_subplot(4, 1, 1)
        self.ax2 = self.fig.add_subplot(4, 1, 2, sharex=self.ax1)
        self.ax3 = self.fig.add_subplot(4, 1, 3, sharex=self.ax1)
        self.ax4 = self.fig.add_subplot(4, 1, 4, sharex=self.ax1)

        # BẢNG 1: RPM
        self.line_rpm,     = self.ax1.plot(list(self.buf_time), list(self.buf_rpm), color="tab:blue", linewidth=1.6, label="RPM Thực Tế")
        self.line_rpm_ref, = self.ax1.plot(list(self.buf_time), list(self.buf_rpm_ref), color="darkorange", linestyle="--", linewidth=1.4, label="RPM Target")
        self.ax1.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        self.ax1.set_ylabel("Vận Tốc (RPM)", fontsize=9)
        self.ax1.grid(True, linestyle=":")
        self.ax1.legend(loc="upper right", fontsize=8.5)
        self.ax1.set_title("1. Bảng Vận Tốc Rotor (RPM Scope - 1 kHz Loop)", fontweight="bold", fontsize=10)

        # BẢNG 2: DÒNG ĐIỆN IQ (sinh mô-men)
        self.line_iq,     = self.ax2.plot(list(self.buf_time), list(self.buf_iq), color="darkblue", linewidth=1.6, label="Iq Thực Tế (Mô-men)")
        self.line_iq_ref, = self.ax2.plot(list(self.buf_time), list(self.buf_iq_ref), color="orange", linestyle="--", linewidth=1.4, label="Iq Target")
        self.ax2.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        self.ax2.set_ylabel("Dòng Iq (A)", fontsize=9)
        self.ax2.grid(True, linestyle=":")
        self.ax2.legend(loc="upper right", fontsize=8.5)
        self.ax2.set_title("2. Bảng Dòng Điện Trục Q - Sinh Mô-men (Iq)", fontweight="bold", fontsize=10)

        # BẢNG 3: DÒNG ĐIỆN ID (từ thông)
        self.line_id,     = self.ax3.plot(list(self.buf_time), list(self.buf_id), color="crimson", linewidth=1.6, label="Id Thực Tế (Từ Thông/FW)")
        self.ax3.axhline(0, color="teal", linestyle="--", linewidth=1.2, alpha=0.8, label="Id Target (0 A)")
        self.ax3.set_ylabel("Dòng Id (A)", fontsize=9)
        self.ax3.grid(True, linestyle=":")
        self.ax3.legend(loc="upper right", fontsize=8.5)
        self.ax3.set_title("3. Bảng Dòng Điện Trục D - Từ Thông (Id)", fontweight="bold", fontsize=10)

        # BẢNG 4: BỘ QUAN SÁT GMO
        self.line_tau,   = self.ax4.plot(list(self.buf_time), list(self.buf_tau_ext), color="purple", linewidth=1.8, label="Tau_ext (Mô-men Ngoại Lực GMO)")
        self.line_th_up, = self.ax4.plot(list(self.buf_time), list(self.buf_tau_thresh), color="red", linestyle="--", linewidth=1.4, label="+Ngưỡng Va Chạm")
        self.line_th_dn, = self.ax4.plot(list(self.buf_time), [-x for x in self.buf_tau_thresh], color="red", linestyle="--", linewidth=1.4, label="-Ngưỡng Va Chạm")
        self.ax4.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        self.ax4.set_xlabel("Thời Gian (s)", fontsize=9)
        self.ax4.set_ylabel("Tau (N.m)", fontsize=9)
        self.ax4.grid(True, linestyle=":")
        self.ax4.legend(loc="upper right", fontsize=8.5)
        self.ax4.set_title("4. Bảng Giám Sát Va Chạm (Generalized Momentum Observer - 1 kHz)", fontweight="bold", fontsize=10)

        self.fig.tight_layout(pad=1.6)

        self.canvas = FigureCanvasTkAgg(self.fig, master=right_panel)
        self.canvas.draw()

        toolbar_frame = tk.Frame(right_panel, bg="#ffffff")
        toolbar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame)
        self.toolbar.update()
        # Nút lưu log ở thanh công cụ đồ thị: không bao giờ bị cuộn khuất như các nút ở cột trái
        tk.Button(
            self.toolbar, text="💾 LƯU LOG [L]", bg="#7c3aed", fg="white",
            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, padx=10, pady=2,
            command=self.export_and_show_log_chart
        ).pack(side=tk.RIGHT, padx=6, pady=2)

        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    def _create_metric_box(self, parent, row, col, title, var, color):
        box = tk.Frame(parent, bg="#f8fafc", bd=1, relief=tk.SOLID, padx=5, pady=3)
        box.grid(row=row, column=col, sticky="ew", padx=2, pady=1)
        tk.Label(box, text=title, bg="#f8fafc", fg="#475569", font=("Segoe UI", 8)).pack(anchor="w")
        tk.Label(box, textvariable=var, bg="#f8fafc", fg=color, font=("Consolas", 9, "bold")).pack(anchor="e")

    def _set_torque_limit_ui_state(self, is_torque: bool):
        """Bật sáng hàng đặt tốc độ bão hòa khi ở TORQUE Mode, làm xám (disabled) khi ở SPEED (RPM) Mode."""
        if self._widget_cache.get("trq_lim_state") == is_torque:
            return
        self._widget_cache["trq_lim_state"] = is_torque

        if is_torque:
            self.lbl_trq_spd_lim.config(fg="#6d28d9")
            self.btn_trq_spd_dec.config(state=tk.NORMAL, bg="#ede9fe", fg="#5b21b6")
            self.ent_trq_spd_lim.config(state="normal")
            self.btn_trq_spd_inc.config(state=tk.NORMAL, bg="#ede9fe", fg="#5b21b6")
            self.btn_apply_trq_spd.config(state=tk.NORMAL, bg="#7c3aed", fg="white")
        else:
            self.lbl_trq_spd_lim.config(fg="#94a3b8")
            self.btn_trq_spd_dec.config(state=tk.DISABLED, bg="#e2e8f0", fg="#94a3b8")
            self.ent_trq_spd_lim.config(state="disabled")
            self.btn_trq_spd_inc.config(state=tk.DISABLED, bg="#e2e8f0", fg="#94a3b8")
            self.btn_apply_trq_spd.config(state=tk.DISABLED, bg="#cbd5e1", fg="#64748b")

    def _bind_shortcuts(self):
        def _on_key(event):
            widget_class = event.widget.winfo_class()
            if widget_class in ("Entry", "TEntry", "TCombobox"):
                return
            if event.keysym == "space":
                self.process_key(' ')
            elif event.char:
                self.process_key(event.char)

        self.root.bind("<Key>", _on_key)

    # =========================================================================
    # KẾT NỐI SERIAL, LUỒNG TX ƯU TIÊN CAO & LUỒNG NHẬN DỮ LIỆU CAN
    # =========================================================================
    def _refresh_com_ports(self):
        ports = ["COM6"]
        ch340 = None
        if HAS_SERIAL:
            infos = list(serial.tools.list_ports.comports())
            if infos:
                ports = [p.device for p in infos]
            for p in infos:     # USB-CAN-A dùng chip CH340 (VID:PID 1A86:7523)
                txt = f"{p.description} {p.hwid}".upper()
                if "CH340" in txt or "1A86:7523" in txt:
                    ch340 = p.device
                    break
        self.cmb_port["values"] = ports
        if ch340 and self.var_transport.get() == TRANSPORT_USBCANA:
            self.var_port.set(ch340)

    def _on_transport_changed(self, _event=None):
        """Đổi thiết bị: đặt baud mặc định tương ứng; tốc độ CAN chỉ chỉnh được với USB-CAN-A
        (với ESP32, tốc độ CAN nằm trong firmware ESP32)."""
        tp = self.var_transport.get()
        self.var_baud.set(str(TRANSPORT_DEFAULT_BAUD.get(tp, 115200)))
        self.cmb_canrate.config(state="readonly" if tp == TRANSPORT_USBCANA else "disabled")
        self._refresh_com_ports()
        if self.is_connected:
            self.disconnect_serial()

    def toggle_connection(self):
        if self.is_connected:
            self.disconnect_serial()
        else:
            self.connect_serial(silent_on_fail=False)

    def connect_serial(self, silent_on_fail=False):
        if not HAS_SERIAL:
            if not silent_on_fail:
                messagebox.showerror("Thiếu thư viện", "Chưa cài đặt pyserial! Hãy chạy: pip install pyserial")
            return
        port = self.var_port.get().strip()
        transport = self.var_transport.get()
        try:
            baud = int(self.var_baud.get().strip())
        except ValueError:
            baud = TRANSPORT_DEFAULT_BAUD.get(transport, 115200)

        try:
            with self.tx_lock:
                if self.ser and self.ser.is_open:
                    self.ser.close()
                self.ser = serial.Serial(port, baud, timeout=0.02, write_timeout=0.05)
                if transport == TRANSPORT_USBCANA:
                    # Cài đặt bộ chuyển đổi: tốc độ CAN, khung chuẩn, nhận mọi ID, giao thức biến độ dài
                    code = USBCANA_BITRATE_CODE.get(self.var_canrate.get(), USBCANA_BITRATE_CODE[CAN_BITRATE_DEFAULT])
                    cfg = usbcana_config_packet(code)
                    self.ser.write(cfg)
                    self.ser.flush()
                    time.sleep(0.1)
                    print(f"[USB-CAN-A] {port} @ {baud} baud, CAN {self.var_canrate.get()}bps | lệnh cài đặt: {cfg.hex(' ').upper()}")
                    self._rx_parser = UsbCanAParser()
                else:
                    self.ser.write(b"C\r")
                    time.sleep(0.05)
                    self.ser.write(b"O\r")
                    time.sleep(0.1)
                    self._rx_parser = SlcanParser()
                self.ser.reset_input_buffer()
                self._tx_transport = transport
            self.rx_id_count = {}
            self._diag_flags = set()
            self._connect_time = time.time()
            self.is_connected = True
            self.btn_connect.config(text=f"Ngắt kết nối ({port})", bg="#dc2626")
        except Exception as e:
            self.is_connected = False
            self.btn_connect.config(text="Kết nối COM", bg="#0d6efd")
            if not silent_on_fail:
                messagebox.showwarning("Không thể mở cổng COM", f"Không thể mở {port}:\n{e}")

    def disconnect_serial(self):
        self.is_connected = False
        with self.tx_lock:
            try:
                if self.ser and self.ser.is_open:
                    self.ser.close()
            except Exception:
                pass
            self.ser = None
        self.btn_connect.config(text="Kết nối COM", bg="#0d6efd")

    def _cmd_data(self, cmd_id: int, payload: float = 0.0) -> bytes:
        """8 byte dữ liệu của gói lệnh 0x100: byte 0 = mã lệnh, byte 1..4 = float little-endian."""
        data = bytearray(8)
        data[0] = cmd_id
        data[1:5] = struct.pack('<f', float(payload))
        return bytes(data)

    def _encode_can_frame(self, cmd_id: int, payload: float = 0.0) -> bytes:
        """Gói lệnh 0x100 ở dạng byte đúng với thiết bị đang dùng (USB-CAN-A nhị phân hoặc SLCAN ASCII)."""
        data = self._cmd_data(cmd_id, payload)
        if getattr(self, "_tx_transport", TRANSPORT_USBCANA) == TRANSPORT_USBCANA:
            return usbcana_encode(0x100, data)
        return slcan_encode(0x100, data)

    def send_can_cmd(self, cmd_id: int, payload: float = 0.0, force: bool = False):
        if not self.is_connected or self.ser is None:
            return
        now = time.time()

        # 1. Lệnh DỪNG KHẨN CẤP (0x01): KHÔNG BAO GIỜ bị chặn bởi debounce!
        if cmd_id == 0x01:
            self._pending_target_cmd = None
            while not self.tx_queue.empty():
                try:
                    self.tx_queue.get_nowait()
                except queue.Empty:
                    break
            frame = self._encode_can_frame(0x01, 0.0)
            self.tx_queue.put(frame)
            self.tx_queue.put(frame)
            self._log_event("LENH", "DỪNG")
            return

        # 2. Chống lặp phím tự động (auto-repeat) cho lệnh Arm (0x02) và Calib (0x04)
        if cmd_id in (0x02, 0x04) and not force:
            if now - self._last_cmd_time.get(cmd_id, 0.0) < CMD_DEBOUNCE_S:
                return
            self._last_cmd_time[cmd_id] = now

        # 3. Gom lệnh đặt tốc độ / dòng (0x07, 0x03) khi người dùng đè phím +/- liên tục
        if cmd_id in (0x03, 0x07) and not force:
            if now - self._last_target_send_t < TARGET_THROTTLE_S:
                self._pending_target_cmd = (cmd_id, payload)
                return
            self._last_target_send_t = now
            self._pending_target_cmd = None

        self.tx_queue.put(self._encode_can_frame(cmd_id, payload))
        self._log_event("LENH", f"{CMD_NAMES.get(cmd_id, hex(cmd_id))} = {payload:g}")

    def _tx_worker_loop(self):
        while self.is_running:
            try:
                if self._pending_target_cmd is not None and (time.time() - self._last_target_send_t >= TARGET_THROTTLE_S):
                    cmd_id, payload = self._pending_target_cmd
                    self._pending_target_cmd = None
                    self._last_target_send_t = time.time()
                    self.tx_queue.put(self._encode_can_frame(cmd_id, payload))
                    self._log_event("LENH", f"{CMD_NAMES.get(cmd_id, hex(cmd_id))} = {payload:g}")

                frame_bytes = self.tx_queue.get(timeout=0.015)
                if self.is_connected and self.ser is not None:
                    with self.tx_lock:
                        self.ser.write(frame_bytes)
                        self.ser.flush()
            except queue.Empty:
                continue
            except Exception:
                pass

    def _rx_listener_loop(self):
        """Đọc byte từ cổng serial, bộ tách khung (USB-CAN-A hoặc SLCAN) trả về (ID, dữ liệu) -> xử lý theo ID."""
        while self.is_running:
            if not self.is_connected or self.ser is None:
                time.sleep(0.05)
                continue
            try:
                waiting = self.ser.in_waiting
                if waiting > 0:
                    raw_bytes = self.ser.read(min(waiting, 4096))
                    for can_id, data in self._rx_parser.feed(raw_bytes):
                        try:
                            self._handle_can_frame(can_id, data)
                        except Exception:
                            pass
                else:
                    time.sleep(0.002)
            except Exception:
                time.sleep(0.005)

    def _handle_can_frame(self, can_id: int, data: bytes):
        """Xử lý một gói CAN từ STM32 (dùng chung cho mọi thiết bị). Mọi gói telemetry đều dài 8 byte."""
        self.rx_id_count[can_id] = self.rx_id_count.get(can_id, 0) + 1
        if len(data) != 8:
            return
        # 0x102: Status
        if can_id == 0x102:
            self.latest_state   = data[0]
            flags               = data[1]
            self.is_lut_active  = 1 if (flags & 0x01) else 0
            self.is_fw_active   = 1 if (flags & 0x02) else 0
            self.is_torque_mode = 1 if (flags & 0x04) else 0
            self.is_position_mode = 1 if (flags & 0x08) else 0

            rpm_scaled, vq_scaled, raw_counts = struct.unpack('<hhH', data[2:8])
            self.latest_rpm = rpm_scaled / 10.0
            self.latest_vq  = vq_scaled / 100.0
            self.latest_raw_counts = raw_counts & 0x3FFF
            if self._ev_last_state is not None and self.latest_state != self._ev_last_state:
                self._log_event("TRANG_THAI", f"{STATE_SHORT.get(self._ev_last_state, '?')} -> {STATE_SHORT.get(self.latest_state, '?')}")
            self._ev_last_state = self.latest_state

        # 0x105: Dòng điện (Ia, Ib, Id, Iq)
        elif can_id == 0x105:
            ia_ma, ib_ma, id_ma, iq_ma = struct.unpack('<hhhh', data[0:8])
            self.latest_ia = ia_ma / 1000.0
            self.latest_ib = ib_ma / 1000.0
            self.latest_ic = -(self.latest_ia + self.latest_ib)
            self.latest_id = id_ma / 1000.0
            self.latest_iq = iq_ma / 1000.0

            t_now = time.time() - self.start_time
            rpm_ref = self.current_target_rpm if self.is_torque_mode == 0 else self.torque_speed_limit_rpm
            iq_ref  = self.current_target_iq if self.is_torque_mode == 1 else 0.0
            if self.is_position_mode == 1:
                rpm_ref, iq_ref = 0.0, 0.0
            mode_name = "POSITION" if self.is_position_mode == 1 else ("TORQUE" if self.is_torque_mode == 1 else "SPEED")

            self._rx_count += 1
            self.buf_time.append(t_now)
            self.buf_rpm.append(self.latest_rpm)
            self.buf_rpm_ref.append(rpm_ref)
            self.buf_iq.append(self.latest_iq)
            self.buf_iq_ref.append(iq_ref)
            self.buf_id.append(self.latest_id)
            self.buf_tau_ext.append(self.latest_tau_ext)
            self.buf_tau_thresh.append(self.latest_tau_thresh)
            self.buf_pos.append(self.pos_angle)
            self.buf_pos_ref.append(self.pos_ref)

            if self.is_logging:
                with self.log_lock:
                    self.log_records.append({
                        "Time_s": round(t_now, 4),
                        "State": STATE_SHORT.get(self.latest_state, "UNK"),
                        "Mode": mode_name,
                        "RPM_Target": round(rpm_ref, 2),
                        "RPM_Actual": round(self.latest_rpm, 2),
                        "Iq_Target_A": round(iq_ref, 4),
                        "Iq_Actual_A": round(self.latest_iq, 4),
                        "Id_Actual_A": round(self.latest_id, 4),
                        "Ia_A": round(self.latest_ia, 4),
                        "Ib_A": round(self.latest_ib, 4),
                        "Ic_A": round(self.latest_ic, 4),
                        "Uq_V": round(self.latest_vq, 3),
                        "Tau_ext_Nm": round(self.latest_tau_ext, 4),
                        "Tau_thresh_Nm": round(self.latest_tau_thresh, 4),
                        "Collision": int(self.is_collided),
                        "Raw_Counts": int(self.latest_raw_counts),
                        "Pos_deg": round(self.pos_angle, 3),
                        "Pos_ref_deg": round(self.pos_ref, 2),
                        "Pos_target_deg": round(self.pos_target, 2),
                        "Pos_phase": int(self.pos_phase),
                    })

        # 0x106: GMO Telemetry
        elif can_id == 0x106:
            tau_mnm, thresh_mnm = struct.unpack('<hh', data[0:4])
            self.latest_tau_ext    = tau_mnm / 1000.0
            if thresh_mnm > 0:
                self.latest_tau_thresh = thresh_mnm / 1000.0
            self.is_collided       = data[4]
            self.countdown_sec     = data[5]
            if self.is_position_mode == 0:          # chế độ vị trí ghi sự kiện theo pha ở gói 0x109
                if self.is_collided and not self._ev_last_coll:
                    self._log_event("VA_CHAM_GMO", f"tau_ext {self.latest_tau_ext:+.3f} / ngưỡng {self.latest_tau_thresh:.3f} N.m")
                elif not self.is_collided and self._ev_last_coll:
                    self._log_event("HET_VA_CHAM", "tự phục hồi / đã dừng")
            self._ev_last_coll = self.is_collided

        # 0x109: Chế độ vị trí - góc int32 [0.001 độ], tham chiếu int16 [0.1 độ], pha, cờ
        elif can_id == 0x109:
            ang_mdeg, ref_ddeg = struct.unpack('<ih', data[0:6])
            self.pos_angle = ang_mdeg / 1000.0
            self.pos_ref   = ref_ddeg / 10.0
            self.pos_phase = data[6]
            self.pos_flags = data[7]
            prev = self._ev_last_phase
            if prev is not None and self.pos_phase != prev:
                ph = self.pos_phase
                if ph == 7:
                    where = {3: "rút về 0", 5: "lùi về góc đích", 2: "lùi về chỗ bắt đầu về 0"}.get(prev, "rút lui")
                    self._log_event("VA_CHAM_VI_TRI", f"khi {POS_PHASE_NAMES.get(prev, '?')} tại {self.pos_angle:+.2f}° -> {where}")
                elif ph == 8:
                    self._log_event("DA_RUT_VE", f"dừng tại {self.pos_angle:+.2f}°")
                elif ph == 4 and prev == 3:
                    self._log_event("XONG_HANH_TRINH_DI", f"tới {self.pos_angle:+.2f}° (đích {self.pos_target:+.1f}°)")
                elif ph == 6 and prev == 5:
                    self._log_event("XONG_HANH_TRINH_VE", f"về {self.pos_angle:+.2f}°")
            self._ev_last_phase = self.pos_phase

        # 0x104: Bảng LUT
        elif can_id == 0x104:
            idx = data[0]
            if idx < 128:
                val = struct.unpack('<f', data[1:5])[0]
                self.received_lut[idx] = val
                self.received_mask[idx] = True

        # 0x107: Chẩn đoán thời gian thực
        elif can_id == 0x107:
            foc_avg, foc_max, isr_max = (v / 10.0 for v in struct.unpack('<HHH', data[0:6]))
            self.timing_diag_str = f"FOC: {foc_avg:.1f}us | ISR: {isr_max:.1f}us | Mất: {data[6]} | PWM: {data[7]}us"

        # 0x108: MCU tự báo cấu hình ĐANG CHẠY (chỉ có khi firmware đã có gói 0x108)
        elif can_id == 0x108:
            self._on_config_echo(data)

    # =========================================================================
    # XỬ LÝ LỆNH ĐIỀU KHIỂN (PHÍM TẮT, ĐẶT MỤC TIÊU, BÃO HÒA RPM & NGƯỠNG GMO)
    # =========================================================================
    def _pos_step_target(self, delta: float):
        """Chế độ vị trí: phím +/- đổi góc đích 5°, áp dụng từ hành trình đi kế tiếp."""
        self.pos_target = max(-POS_TARGET_MAX, min(POS_TARGET_MAX, self.pos_target + delta))
        self.var_pos_target.set(f"{self.pos_target:.0f}")
        self.send_can_cmd(0x0B, self.pos_target)

    def process_key(self, ch: str):
        if ch in ['+', '='] and self.is_position_mode == 1:
            self._pos_step_target(+5.0)
        elif ch in ['-', '_'] and self.is_position_mode == 1:
            self._pos_step_target(-5.0)
        elif ch in ['t', 'T'] and self.is_position_mode == 1:
            # Rời chế độ vị trí -> SPEED 0 rpm (dừng tại chỗ)
            self.is_torque_mode = 0
            self.current_target_rpm = 0.0
            self.var_direct_target.set("0")
            self.send_can_cmd(0x07, 0.0, force=True)
        elif ch in ['+', '=']:
            if self.is_torque_mode == 1:
                self.current_target_iq = round(self.current_target_iq + 0.05, 2)
                self.var_direct_target.set(f"{self.current_target_iq:.2f}")
                self.send_can_cmd(0x03, self.current_target_iq)
            else:
                self.current_target_rpm += 10.0
                self.var_direct_target.set(f"{self.current_target_rpm:.0f}")
                self.send_can_cmd(0x07, self.current_target_rpm)

        elif ch in ['-', '_']:
            if self.is_torque_mode == 1:
                self.current_target_iq = round(self.current_target_iq - 0.05, 2)
                self.var_direct_target.set(f"{self.current_target_iq:.2f}")
                self.send_can_cmd(0x03, self.current_target_iq)
            else:
                self.current_target_rpm -= 10.0
                self.var_direct_target.set(f"{self.current_target_rpm:.0f}")
                self.send_can_cmd(0x07, self.current_target_rpm)

        elif ch == '[':
            self.step_gmo_threshold(-0.005)

        elif ch == ']':
            self.step_gmo_threshold(0.005)

        elif ch in ['t', 'T']:
            if self.is_torque_mode == 1:
                self.is_torque_mode = 0
                self._set_torque_limit_ui_state(False)
                self.current_target_rpm = float(int(self.latest_rpm))
                self.var_direct_target.set(f"{self.current_target_rpm:.0f}")
                self.send_can_cmd(0x07, self.current_target_rpm, force=True)
            else:
                self.is_torque_mode = 1
                self._set_torque_limit_ui_state(True)
                self.current_target_iq = round(self.latest_iq, 2)
                self.var_direct_target.set(f"{self.current_target_iq:.2f}")
                # Đồng bộ luôn tốc độ bão hòa xuống STM32 khi chuyển sang Torque Mode
                self.send_can_cmd(0x09, self.torque_speed_limit_rpm, force=True)
                self.send_can_cmd(0x03, self.current_target_iq, force=True)

        elif ch in ['a', 'A']:
            self.send_can_cmd(0x02)

        elif ch in [' ', 's', 'S', '0']:
            self.current_target_iq = 0.00
            self.current_target_rpm = 0.0
            self.var_direct_target.set("0.0")
            self.send_can_cmd(0x01, force=True)

        elif ch in ['f', 'F']:
            new_fw = 0 if self.is_fw_active == 1 else 1
            self.send_can_cmd(0x06, float(new_fw), force=True)

        elif ch in ['m', 'M']:
            new_mode = 0 if self.is_lut_active == 1 else 1
            self.send_can_cmd(0x05, float(new_mode), force=True)

        elif ch in ['c', 'C']:
            self.received_mask.fill(False)
            self.send_can_cmd(0x04)

        elif ch in ['d', 'D']:
            self.print_diagnostics()

        elif ch in ['l', 'L']:
            self.export_and_show_log_chart()

    def apply_direct_target(self):
        try:
            val = float(self.var_direct_target.get().strip())
        except ValueError:
            messagebox.showwarning("Sai định dạng", "Vui lòng nhập một số hợp lệ!")
            return
        if self.is_torque_mode == 1:
            self.current_target_iq = round(val, 2)
            self.send_can_cmd(0x03, self.current_target_iq, force=True)
        else:
            self.current_target_rpm = val
            self.send_can_cmd(0x07, self.current_target_rpm, force=True)

    def step_torque_speed_limit(self, delta: float):
        if self.is_torque_mode != 1:
            return
        try:
            cur = float(self.var_trq_spd_lim.get().strip())
        except ValueError:
            cur = self.torque_speed_limit_rpm
        new_val = max(0.0, min(round(cur + delta, 1), 600.0))
        self.var_trq_spd_lim.set(f"{new_val:.0f}")
        self.apply_torque_speed_limit()

    def apply_torque_speed_limit(self):
        if self.is_torque_mode != 1:
            return
        try:
            val = float(self.var_trq_spd_lim.get().strip())
        except ValueError:
            messagebox.showwarning("Sai định dạng", "Vui lòng nhập tốc độ bão hòa hợp lệ (RPM)!")
            return
        if val < 0.0 or val > 600.0:
            messagebox.showwarning("Ngoài phạm vi", "Tốc độ bão hòa phải nằm trong khoảng 0 đến 600 RPM (0 = không giới hạn)!")
            return

        self.torque_speed_limit_rpm = round(val, 1)
        self.var_trq_spd_lim.set(f"{self.torque_speed_limit_rpm:.0f}")
        # Gửi lệnh CAN 0x09 xuống STM32 để cập nhật tốc độ bão hòa cho chế độ Torque
        self.send_can_cmd(0x09, self.torque_speed_limit_rpm, force=True)

    def step_gmo_threshold(self, delta: float):
        try:
            cur = float(self.var_thresh_target.get().strip())
        except ValueError:
            cur = self.latest_tau_thresh
        new_val = max(0.005, min(round(cur + delta, 3), 2.000))
        self.var_thresh_target.set(f"{new_val:.3f}")
        self.apply_gmo_threshold()

    def apply_gmo_threshold(self):
        try:
            val = float(self.var_thresh_target.get().strip())
        except ValueError:
            messagebox.showwarning("Sai định dạng", "Vui lòng nhập ngưỡng va chạm hợp lệ (ví dụ: 0.045)!")
            return
        if val < 0.005 or val > 2.0:
            messagebox.showwarning("Ngoài phạm vi", "Ngưỡng va chạm GMO phải nằm trong khoảng 0.005 đến 2.000 N.m!")
            return

        val = round(val, 3)
        self.var_thresh_target.set(f"{val:.3f}")
        self.latest_tau_thresh = val

        for i in range(len(self.buf_tau_thresh)):
            self.buf_tau_thresh[i] = val
        self._ylim_cache.pop(id(self.ax4), None)
        self._drawn_rx_count = -1

        self.send_can_cmd(0x08, val, force=True)

    # =========================================================================
    # CẬP NHẬT ĐỒ THỊ REAL-TIME TRONG TKINTER
    # =========================================================================
    # =========================================================================
    # CHẾ ĐỘ VỊ TRÍ (cánh tay gạt)
    # =========================================================================
    def _read_pos_params(self):
        """Đọc và kiểm tra tốc độ/góc đích từ ô nhập. Trả về (speed, target) hoặc None nếu sai."""
        try:
            speed = float(self.var_pos_speed.get().replace(",", "."))
            target = float(self.var_pos_target.get().replace(",", "."))
        except ValueError:
            messagebox.showwarning("Chế độ vị trí", "Tốc độ và góc đích phải là số.")
            return None
        if not (1.0 <= speed <= POS_SPEED_MAX):
            messagebox.showwarning("Chế độ vị trí", f"Tốc độ phải trong khoảng 1 - {POS_SPEED_MAX:.0f} °/s.")
            return None
        if abs(target) > POS_TARGET_MAX:
            messagebox.showwarning("Chế độ vị trí", f"|Góc đích| tối đa {POS_TARGET_MAX:.0f}°.")
            return None
        return speed, target

    def apply_pos_params(self, quiet=False):
        """Gửi tốc độ (0x0A) và góc đích (0x0B). Firmware áp dụng từ hành trình kế tiếp."""
        vals = self._read_pos_params()
        if vals is None:
            return False
        self.pos_speed, self.pos_target = vals
        self.send_can_cmd(0x0A, self.pos_speed, force=True)
        self.send_can_cmd(0x0B, self.pos_target, force=True)
        if not quiet:
            print(f"[POSITION] Tốc độ {self.pos_speed:.0f} °/s, góc đích {self.pos_target:+.1f}°")
        return True

    def pos_set_zero(self):
        """Đặt góc 0 tại vị trí hiện tại (0x0C). Firmware bỏ qua lệnh này khi đang chạy chế độ vị trí."""
        if self.is_position_mode == 1 and self.latest_state == 2:
            messagebox.showinfo("Đặt góc 0", "Đang chạy chế độ vị trí.\nBấm DỪNG (Space) trước, xoay tay tới vị trí muốn làm góc 0, rồi bấm lại.")
            return
        self.send_can_cmd(0x0C, 0.0, force=True)
        print(f"[POSITION] Đặt góc 0 tại vị trí hiện tại (đang đọc {self.pos_angle:+.2f}°)")

    def pos_start_cycle(self):
        """Gửi tốc độ + đích rồi chạy chu trình 0 -> đích -> 0 lặp lại (0x0D = 1)."""
        if not self.apply_pos_params(quiet=True):
            return
        if not (self.pos_flags & 0x01):
            if not messagebox.askyesno("Chạy chế độ vị trí",
                                       "Chưa đặt góc 0 trong phiên này (góc 0 = vị trí lúc bật nguồn).\nVẫn chạy?"):
                return
        self.send_can_cmd(0x0D, 1.0, force=True)
        print(f"[POSITION] Chạy chu trình 0 -> {self.pos_target:+.1f}° -> 0 @ {self.pos_speed:.0f} °/s")
        self.root.after(1200, lambda: self._check_pos_cmd_effect("Chạy"))

    def pos_go_home(self):
        """Về góc 0 rồi đứng giữ (0x0D = 0)."""
        vals = self._read_pos_params()
        if vals is not None:
            self.pos_speed = vals[0]
            self.send_can_cmd(0x0A, self.pos_speed, force=True)
        self.send_can_cmd(0x0D, 0.0, force=True)
        print("[POSITION] Về 0 rồi đứng giữ")
        self.root.after(1200, lambda: self._check_pos_cmd_effect("Về 0"))

    # =========================================================================
    # CHẨN ĐOÁN ĐƯỜNG TRUYỀN & LỆNH (in ra console)
    # =========================================================================
    def _log_event(self, kind: str, detail: str = ""):
        """Ghi 1 dòng nhật ký sự kiện (gọi được từ mọi luồng). Dùng chung mốc thời gian với log dữ liệu."""
        if not self.is_logging:
            return
        rec = {
            "Time_s": round(time.time() - self.start_time, 3),
            "Su_kien": kind,
            "Chi_tiet": detail,
            "Trang_thai": STATE_SHORT.get(self.latest_state, "?"),
            "Che_do": "POSITION" if self.is_position_mode == 1 else ("TORQUE" if self.is_torque_mode == 1 else "SPEED"),
            "Goc_deg": round(self.pos_angle, 3),
            "RPM": round(self.latest_rpm, 1),
            "Tau_ext_max_Nm": round(max((abs(x) for x in list(self.buf_tau_ext)[-8:]), default=0.0), 4),
            "Nguong_Nm": round(self.latest_tau_thresh, 4),
        }
        with self.log_lock:
            self.event_records.append(rec)

    def _diag_counts_str(self):
        c = self.rx_id_count
        ids = ", ".join(f"0x{k:03X}:{v}" for k, v in sorted(c.items())) or "không có gói nào"
        return f"{ids} | byte rác bộ tách bỏ: {getattr(self._rx_parser, 'bad_bytes', 0)}"

    def print_diagnostics(self):
        st = STATE_SHORT.get(self.latest_state, "?")
        print(f"[CHẨN ĐOÁN] Thiết bị {self._tx_transport} | đã kết nối {time.time() - self._connect_time:.0f} s"
              f" | gói nhận: {self._diag_counts_str()}")
        print(f"            trạng thái MCU: {st} | chế độ vị trí: {self.is_position_mode} | pha: "
              f"{POS_PHASE_NAMES.get(self.pos_phase, '?')} | cờ 0x109: 0x{self.pos_flags:02X}", flush=True)

    def _link_diagnostics(self):
        """Mỗi giây: phát hiện (1) không có dữ liệu từ STM32, (2) có dữ liệu nhưng thiếu gói 0x109 = firmware cũ."""
        try:
            if self.is_connected and time.time() - self._connect_time > 2.5:
                total = sum(self.rx_id_count.values())
                bad = getattr(self._rx_parser, "bad_bytes", 0)
                if total == 0 and "nodata" not in self._diag_flags:
                    self._diag_flags.add("nodata")
                    print("[CHẨN ĐOÁN] Đã mở cổng nhưng KHÔNG nhận được gói CAN nào từ STM32 -> lệnh cũng không tới được MCU.", flush=True)
                    if bad > 50:
                        print("            Có nhận byte nhưng không ghép ra khung: kiểm tra ô 'Thiết bị' (đang cắm USB-CAN-A mà chọn ESP32?)"
                              " và baud (USB-CAN-A = 2000000).", flush=True)
                    else:
                        print("            Kiểm tra: board đã cấp nguồn & firmware đang chạy? CANH-CANH, CANL-CANL, chung GND?"
                              " Điện trở 120 ohm trên USB-CAN-A đã bật? Tốc độ CAN = 250k?", flush=True)
                elif total > 0 and "nodata" in self._diag_flags:
                    self._diag_flags.discard("nodata")
                    print(f"[CHẨN ĐOÁN] Đã nhận dữ liệu từ STM32: {self._diag_counts_str()}", flush=True)
                if (self.rx_id_count.get(0x102, 0) > 5 and self.rx_id_count.get(0x109, 0) == 0
                        and "no109" not in self._diag_flags):
                    self._diag_flags.add("no109")
                    print("[CHẨN ĐOÁN] STM32 có gửi trạng thái (0x102) nhưng KHÔNG gửi gói 0x109 -> firmware trên board CHƯA CÓ"
                          " chế độ vị trí. Các lệnh 0x0A..0x0D bị bỏ qua nên động cơ đứng im.", flush=True)
                    print("            Cách sửa: chép 8 file trong firmware_position_mode.zip vào project, Clean -> Build -> nạp lại.", flush=True)
        except Exception:
            pass
        if self.is_running:
            self.root.after(1000, self._link_diagnostics)

    def _check_pos_cmd_effect(self, what: str):
        """1.2 s sau khi bấm Chạy / Về 0: MCU đã vào chế độ vị trí chưa? Nếu chưa, in lý do khả dĩ nhất."""
        if not self.is_connected:
            print(f"[CHẨN ĐOÁN] Bấm '{what}' nhưng GUI chưa kết nối cổng COM.", flush=True)
            return
        if self.is_position_mode == 1:
            print(f"[CHẨN ĐOÁN] MCU đã vào chế độ vị trí (pha: {POS_PHASE_NAMES.get(self.pos_phase, '?')}, "
                  f"góc {self.pos_angle:+.2f}°).", flush=True)
            return
        total = sum(self.rx_id_count.values())
        st = self.latest_state
        if total == 0:
            reason = "không nhận được gói nào từ STM32 -> đường CAN chưa thông (xem dòng chẩn đoán ở trên)."
        elif self.rx_id_count.get(0x109, 0) == 0:
            reason = "board không gửi gói 0x109 -> firmware chưa có chế độ vị trí, cần nạp firmware_position_mode."
        elif st in (3, 4):
            reason = (f"MCU đang ở trạng thái {STATE_SHORT.get(st)} -> mọi lệnh chạy bị chặn. "
                      "Bấm Space (Dừng), nếu là ERR thì bấm thêm [A] ARM, rồi bấm lại.")
        else:
            reason = "có dữ liệu và có gói 0x109 nhưng lệnh không có tác dụng -> có thể gói lệnh 0x100 không tới MCU (thử bấm D)."
        print(f"[CHẨN ĐOÁN] Bấm '{what}' nhưng sau 1.2 s MCU VẪN CHƯA vào chế độ vị trí: {reason}", flush=True)

    def _set_ylim_hyst(self, ax, need, step):
        quantized = float(np.ceil(need / step) * step)
        cur = self._ylim_cache.get(id(ax))
        if cur is None or quantized > cur or quantized < 0.45 * cur:
            ax.set_ylim(-quantized, quantized)
            self._ylim_cache[id(ax)] = quantized

    def _cfg(self, widget, key, **kw):
        if self._widget_cache.get(key) != kw:
            widget.config(**kw)
            self._widget_cache[key] = kw

    def _update_gui_loop(self):
        if not self.is_running:
            return

        user_zooming = bool(self.toolbar.mode) or self.pause_scope
        new_data = (self._rx_count != self._drawn_rx_count)

        if new_data and not user_zooming:
            self._drawn_rx_count = self._rx_count
            t = list(self.buf_time)
            rpm_list = list(self.buf_rpm)
            rpm_ref_list = list(self.buf_rpm_ref)
            iq_list = list(self.buf_iq)
            iq_ref_list = list(self.buf_iq_ref)
            id_list = list(self.buf_id)
            tau_list = list(self.buf_tau_ext)
            th_list = list(self.buf_tau_thresh)

            if len(t) >= 2:
                self.ax1.set_xlim(t[0], max(t[-1], t[0] + 3.0))

                # 1. Cập nhật Bảng 1: RPM, hoặc GÓC CÁNH TAY khi đang ở chế độ vị trí
                ax1_mode = "pos" if self.is_position_mode == 1 else "rpm"
                if self._widget_cache.get("ax1mode") != ax1_mode:
                    self._widget_cache["ax1mode"] = ax1_mode
                    if ax1_mode == "pos":
                        self.line_rpm.set_label("Góc Cánh Tay Thực Tế")
                        self.line_rpm_ref.set_label("Góc Tham Chiếu (Quỹ Đạo)")
                        self.ax1.set_ylabel("Góc Trục Ra (°)", fontsize=9)
                        self.ax1.set_title("1. Góc Cánh Tay (Position Mode)", fontweight="bold", fontsize=10)
                    else:
                        self.line_rpm.set_label("RPM Thực Tế")
                        self.line_rpm_ref.set_label("RPM Target")
                        self.ax1.set_ylabel("Vận Tốc (RPM)", fontsize=9)
                        self.ax1.set_title("1. Bảng Vận Tốc Rotor (RPM Scope - 1 kHz Loop)", fontweight="bold", fontsize=10)
                    self.ax1.legend(loc="upper right", fontsize=8.5)
                    self.ax1.set_ylim(-1.0, 1.0)          # buộc _set_ylim_hyst đặt lại thang
                if ax1_mode == "pos":
                    pos_list = list(self.buf_pos)
                    pos_ref_list = list(self.buf_pos_ref)
                    self.line_rpm.set_data(t, pos_list)
                    self.line_rpm_ref.set_data(t, pos_ref_list)
                    max_p = max(max(abs(x) for x in pos_list), abs(self.pos_target), 10.0)
                    self._set_ylim_hyst(self.ax1, max_p * 1.2, step=30.0)
                else:
                    self.line_rpm.set_data(t, rpm_list)
                    self.line_rpm_ref.set_data(t, rpm_ref_list)
                    ref_bound = self.torque_speed_limit_rpm if self.is_torque_mode == 1 else abs(self.current_target_rpm)
                    max_r = max(max(abs(x) for x in rpm_list), ref_bound, 25.0)
                    self._set_ylim_hyst(self.ax1, max_r * 1.25, step=50.0)

                # 2. Cập nhật Bảng 2 (Iq)
                self.line_iq.set_data(t, iq_list)
                self.line_iq_ref.set_data(t, iq_ref_list)
                max_iq = max(max(abs(x) for x in iq_list), abs(self.current_target_iq), 0.35)
                self._set_ylim_hyst(self.ax2, max_iq * 1.3, step=0.25)

                # 3. Cập nhật Bảng 3 (Id) - thang riêng nên thấy rõ dao động Id nhỏ
                self.line_id.set_data(t, id_list)
                max_id = max(max(abs(x) for x in id_list), 0.15)
                self._set_ylim_hyst(self.ax3, max_id * 1.3, step=0.1)

                # 4. Cập nhật Bảng 4 (GMO)
                self.line_tau.set_data(t, tau_list)
                self.line_th_up.set_data(t, th_list)
                self.line_th_dn.set_data(t, [-x for x in th_list])
                max_tau = max(max(abs(x) for x in tau_list), self.latest_tau_thresh * 2.2, 0.06)
                self._set_ylim_hyst(self.ax4, max_tau * 1.25, step=0.05)

                self.canvas.draw_idle()

        # Cập nhật nhãn thông số bên cột trái
        st_name = STATE_SHORT.get(self.latest_state, "UNK")
        st_color = STATE_COLORS.get(self.latest_state, "#6c757d")
        self._cfg(self.lbl_state_badge, "badge", text=f"TRẠNG THÁI: {st_name}", bg=st_color)

        self.var_tele_rpm.set(f"{self.latest_rpm:+6.1f} RPM")
        self.var_tele_vq.set(f"{self.latest_vq:+5.2f} V")
        self.var_tele_iq.set(f"{self.latest_iq:+6.3f} A")
        self.var_tele_id.set(f"{self.latest_id:+6.3f} A")
        self.var_tele_tau.set(f"{self.latest_tau_ext:+.3f} Nm")
        self.var_tele_enc.set(f"{self.latest_raw_counts:5d}")
        self.var_timing_diag.set(self.timing_diag_str)

        # Đồng bộ nút Mode và làm xám/bật sáng cụm "Bão hòa RPM (Torque)"
        self._set_torque_limit_ui_state(self.is_torque_mode == 1)
        hits = (self.pos_flags >> 4) & 0x0F
        if self.rx_id_count.get(0x109, 0) == 0:
            self.var_pos_status.set("Chưa nhận gói 0x109 từ board!" if self.is_connected else "Chưa kết nối")
            self._cfg(self.lbl_pos_status, "pos_zero", fg="#dc2626")
        else:
            self.var_pos_status.set(f"Góc {self.pos_angle:+7.2f}° | {POS_PHASE_NAMES.get(self.pos_phase, '?')} | VC {hits}")
            self._cfg(self.lbl_pos_status, "pos_zero", fg="#334155" if (self.pos_flags & 0x01) else "#b45309")
        if self.is_position_mode == 1:
            self._cfg(self.btn_mode, "mode", text="[T] Chế độ: POSITION (Cánh tay)", bg="#16a34a")
        elif self.is_torque_mode == 1:
            self._cfg(self.btn_mode, "mode", text="[T] Chế độ: TORQUE MODE (Iq)", bg="#7c3aed")
        else:
            self._cfg(self.btn_mode, "mode", text="[T] Chế độ: SPEED MODE (RPM)", bg="#0284c7")

        self._cfg(
            self.btn_lut, "lut",
            text=f"[M] LUT: {'ON' if self.is_lut_active else 'RAW'}",
            bg="#15803d" if self.is_lut_active else "#64748b"
        )
        self._cfg(
            self.btn_fw, "fw",
            text=f"[F] FW: {'ON' if self.is_fw_active else 'OFF'}",
            bg="#0284c7" if self.is_fw_active else "#64748b"
        )

        # Cập nhật Banner trên cùng & màu cảnh báo va chạm
        mode_str = "POSITION" if self.is_position_mode == 1 else ("TORQUE MODE" if self.is_torque_mode == 1 else "SPEED MODE")
        fw_str   = "FW:ON" if self.is_fw_active == 1 else "FW:OFF"
        lut_str  = "LUT:ON" if self.is_lut_active == 1 else "LUT:RAW"

        if self.is_collided == 1:
            if self._widget_cache.get("ax3bg") != "c":
                self.ax4.set_facecolor('#ffe6e6')
                self._widget_cache["ax3bg"] = "c"
                self.canvas.draw_idle()
            self._cfg(self.top_banner, "banner_bg", bg="#dc2626")
            if self.is_position_mode == 1 and self.pos_phase == 7:
                hit_txt = f"[VA CHẠM - CÁNH TAY] ĐANG DỪNG & RÚT LUI  |  Góc: {self.pos_angle:+.1f}°"
            elif self.is_position_mode == 1 and self.pos_phase == 8:
                hit_txt = f"[VA CHẠM - CÁNH TAY] ĐÃ RÚT VỀ {self.pos_angle:+.1f}° -> CHẠY TIẾP SAU: {self.countdown_sec}s"
            else:
                hit_txt = f"[CẢNH BÁO VA CHẠM GMO!] DỪNG KHẨN CẤP -> TÁI KHỞI ĐỘNG SAU: {self.countdown_sec}s"
            self._cfg(
                self.lbl_banner, "banner_lbl", bg="#dc2626",
                text=f"{hit_txt}  |  Tau_ext: {self.latest_tau_ext:+.3f}/{self.latest_tau_thresh:.3f} N.m"
            )
        else:
            if self._widget_cache.get("ax3bg") != "w":
                self.ax4.set_facecolor('white')
                self._widget_cache["ax3bg"] = "w"
                self.canvas.draw_idle()
            self._cfg(self.top_banner, "banner_bg", bg="#1e3a8a")
            if self.is_position_mode == 1:
                cmd_info = (f"0 <-> {self.pos_target:+.0f}° @ {self.pos_speed:.0f}°/s | Góc {self.pos_angle:+6.1f}° | "
                            f"{POS_PHASE_NAMES.get(self.pos_phase, '?')}")
            elif self.is_torque_mode == 1:
                lim_txt = f"{self.torque_speed_limit_rpm:.0f}RPM" if self.torque_speed_limit_rpm > 0 else "FREE"
                cmd_info = f"Iq*={self.current_target_iq:+.2f}A (Max:{lim_txt})"
            else:
                cmd_info = f"RPM* = {self.current_target_rpm:+5.0f}"
            self._cfg(
                self.lbl_banner, "banner_lbl", bg="#1e3a8a",
                text=f"[{mode_str}: {cmd_info}]  |  RPM: {self.latest_rpm:+5.1f}  |  Iq: {self.latest_iq:+.2f}A  |  Id: {self.latest_id:+.2f}A  |  Uq: {self.latest_vq:+.1f}V  |  Tau: {self.latest_tau_ext:+.3f}/{self.latest_tau_thresh:.3f}Nm  |  [{lut_str}] [{fw_str}]"
            )

        with self.log_lock:
            n_logs = len(self.log_records)
        status_log = "Đang ghi tự động" if self.is_logging else "Đã tạm dừng ghi"
        if user_zooming:
            status_log += " [Đang giữ Zoom]"
        self.var_log_info.set(f"{status_log}: {n_logs} mẫu")

        self.root.after(GUI_REFRESH_MS, self._update_gui_loop)

    # =========================================================================
    # QUẢN LÝ GHI LOG, XUẤT CSV/PNG & HIỂN THỊ CỬA SỐ 4 BIỂU ĐỒ BÁO CÁO
    # =========================================================================
    def toggle_logging(self):
        self.is_logging = not self.is_logging
        if self.is_logging:
            self.btn_toggle_log.config(text="Tạm dừng Ghi", bg="#f59e0b")
        else:
            self.btn_toggle_log.config(text="Tiếp tục Ghi", bg="#16a34a")

    def toggle_pause_scope(self):
        self.pause_scope = not self.pause_scope
        if self.pause_scope:
            self.btn_pause_scope.config(text="Tiếp tục Cuộn", bg="#16a34a")
        else:
            self.toolbar.mode = ""
            self._ylim_cache.clear()
            self._drawn_rx_count = -1
            self.btn_pause_scope.config(text="Đóng băng Zoom", bg="#0284c7")

    def clear_log_data(self):
        with self.log_lock:
            self.log_records.clear()
            self.event_records.clear()
        self.start_time = time.time()
        self.buf_time.clear()
        self.buf_rpm.clear()
        self.buf_rpm_ref.clear()
        self.buf_iq.clear()
        self.buf_iq_ref.clear()
        self.buf_id.clear()
        self.buf_tau_ext.clear()
        self.buf_tau_thresh.clear()
        self.buf_pos.clear()
        self.buf_pos_ref.clear()

        for d, val in [
            (self.buf_time, 0.0), (self.buf_rpm, 0.0), (self.buf_rpm_ref, 0.0),
            (self.buf_iq, 0.0), (self.buf_iq_ref, 0.0), (self.buf_id, 0.0),
            (self.buf_tau_ext, 0.0), (self.buf_tau_thresh, self.latest_tau_thresh),
            (self.buf_pos, self.pos_angle), (self.buf_pos_ref, self.pos_ref)
        ]:
            d.extend([val, val])
        self._ylim_cache.clear()
        self._drawn_rx_count = -1

    def export_and_show_log_chart(self):
        with self.log_lock:
            records = list(self.log_records)

        if not records:
            t_arr = list(self.buf_time)
            for i in range(len(t_arr)):
                records.append({
                    "Time_s": round(t_arr[i], 4),
                    "State": STATE_SHORT.get(self.latest_state, "IDLE"),
                    "Mode": "POSITION" if self.is_position_mode == 1 else ("TORQUE" if self.is_torque_mode == 1 else "SPEED"),
                    "RPM_Target": round(self.buf_rpm_ref[i], 2),
                    "RPM_Actual": round(self.buf_rpm[i], 2),
                    "Iq_Target_A": round(self.buf_iq_ref[i], 4),
                    "Iq_Actual_A": round(self.buf_iq[i], 4),
                    "Id_Actual_A": round(self.buf_id[i], 4),
                    "Ia_A": 0.0,
                    "Ib_A": 0.0,
                    "Ic_A": 0.0,
                    "Uq_V": round(self.latest_vq, 3),
                    "Tau_ext_Nm": round(self.buf_tau_ext[i], 4),
                    "Tau_thresh_Nm": round(self.buf_tau_thresh[i], 4),
                    "Collision": int(abs(self.buf_tau_ext[i]) >= self.buf_tau_thresh[i]),
                    "Raw_Counts": int(self.latest_raw_counts),
                    "Pos_deg": round(self.buf_pos[i], 3) if i < len(self.buf_pos) else 0.0,
                    "Pos_ref_deg": round(self.buf_pos_ref[i], 2) if i < len(self.buf_pos_ref) else 0.0,
                    "Pos_target_deg": round(self.pos_target, 2),
                    "Pos_phase": int(self.pos_phase),
                })

        with self.log_lock:
            events = list(self.event_records)

        # Lưu thẳng vào thư mục chứa file .py, tên theo ngày giờ (không hỏi chỗ lưu)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        try:
            os.makedirs(LOG_DIR, exist_ok=True)
        except Exception as e:
            messagebox.showerror("Lỗi tạo thư mục log", f"Không tạo được {LOG_DIR}:\n{e}")
            return
        base = os.path.join(LOG_DIR, f"log_FOC_GMO_{timestamp_str}")
        csv_path = base + ".csv"
        ev_path = base + "_su_kien.csv"

        fieldnames = [
            "Time_s", "State", "Mode",
            "RPM_Target", "RPM_Actual",
            "Iq_Target_A", "Iq_Actual_A", "Id_Actual_A",
            "Ia_A", "Ib_A", "Ic_A", "Uq_V",
            "Tau_ext_Nm", "Tau_thresh_Nm", "Collision", "Raw_Counts",
            "Pos_deg", "Pos_ref_deg", "Pos_target_deg", "Pos_phase"
        ]
        try:
            with open(csv_path, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(records)
        except Exception as e:
            messagebox.showerror("Lỗi ghi file CSV", f"Không thể lưu file CSV:\n{e}")
            return

        # Nhật ký sự kiện: utf-8-sig để Excel hiện đúng tiếng Việt
        if events:
            try:
                with open(ev_path, mode="w", newline="", encoding="utf-8-sig") as f:
                    writer = csv.DictWriter(f, fieldnames=list(events[0].keys()))
                    writer.writeheader()
                    writer.writerows(events)
            except Exception as e:
                messagebox.showerror("Lỗi ghi nhật ký sự kiện", f"Không thể lưu {ev_path}:\n{e}")
                ev_path = None
        else:
            ev_path = None

        png_path = base + ".png"
        print(f"[LOG] Đã lưu {len(records)} mẫu -> {csv_path}")
        if ev_path:
            print(f"[LOG] Đã lưu {len(events)} sự kiện -> {ev_path}")
        print(f"[LOG] Biểu đồ -> {png_path}", flush=True)
        self._show_log_report_window(records, title_suffix=os.path.basename(csv_path), save_png_path=png_path, events=events)
        files = [os.path.basename(csv_path)] + ([os.path.basename(ev_path)] if ev_path else []) + [os.path.basename(png_path)]
        messagebox.showinfo("Đã xuất log", f"Đã lưu {len(records)} mẫu, {len(events)} sự kiện vào thư mục:\n{LOG_DIR}\n\n" +
                            "\n".join(f"• {f}" for f in files))

    def load_csv_and_show_chart(self):
        csv_path = filedialog.askopenfilename(
            title="Chọn file Log CSV để vẽ biểu đồ",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not csv_path:
            return

        records = []
        try:
            with open(csv_path, mode="r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    records.append({
                        "Time_s": float(row.get("Time_s", 0.0)),
                        "RPM_Target": float(row.get("RPM_Target", 0.0)),
                        "RPM_Actual": float(row.get("RPM_Actual", 0.0)),
                        "Iq_Target_A": float(row.get("Iq_Target_A", 0.0)),
                        "Iq_Actual_A": float(row.get("Iq_Actual_A", 0.0)),
                        "Id_Actual_A": float(row.get("Id_Actual_A", 0.0)),
                        "Tau_ext_Nm": float(row.get("Tau_ext_Nm", 0.0)),
                        "Tau_thresh_Nm": float(row.get("Tau_thresh_Nm", 0.045)),
                        "Collision": int(float(row.get("Collision", 0))),
                        "Mode": row.get("Mode", ""),
                        "Pos_deg": float(row.get("Pos_deg", 0.0) or 0.0),
                        "Pos_ref_deg": float(row.get("Pos_ref_deg", 0.0) or 0.0),
                        "Pos_target_deg": float(row.get("Pos_target_deg", 0.0) or 0.0),
                        "Pos_phase": int(float(row.get("Pos_phase", 0) or 0)),
                    })
        except Exception as e:
            messagebox.showerror("Lỗi đọc CSV", f"File CSV không hợp lệ:\n{e}")
            return

        if not records:
            messagebox.showwarning("File rỗng", "File CSV không có dữ liệu!")
            return

        self._show_log_report_window(records, title_suffix=os.path.basename(csv_path), save_png_path=None)

    def _show_log_report_window(self, records, title_suffix="", save_png_path=None, events=None):
        t_arr      = np.array([r["Time_s"] for r in records], dtype=float)
        rpm_ref    = np.array([r["RPM_Target"] for r in records], dtype=float)
        rpm_act    = np.array([r["RPM_Actual"] for r in records], dtype=float)
        iq_ref     = np.array([r["Iq_Target_A"] for r in records], dtype=float)
        iq_act     = np.array([r["Iq_Actual_A"] for r in records], dtype=float)
        id_act     = np.array([r["Id_Actual_A"] for r in records], dtype=float)
        tau_ext    = np.array([r["Tau_ext_Nm"] for r in records], dtype=float)
        tau_thresh = np.array([r["Tau_thresh_Nm"] for r in records], dtype=float)
        collided   = np.array([r["Collision"] for r in records], dtype=int)
        has_pos    = any(r.get("Mode") == "POSITION" for r in records)
        pos_act    = np.array([r.get("Pos_deg", 0.0) for r in records], dtype=float)
        pos_ref    = np.array([r.get("Pos_ref_deg", 0.0) for r in records], dtype=float)
        pos_tgt    = np.array([r.get("Pos_target_deg", 0.0) for r in records], dtype=float)
        n_panels   = 5 if has_pos else 4

        win = tk.Toplevel(self.root)
        win.title(f"BIỂU ĐỒ XUẤT LOG DỮ LIỆU FOC & GMO ({n_panels} BẢNG) - {title_suffix}")
        win.geometry("1240x960" if has_pos else "1240x880")
        win.configure(bg="#ffffff")

        max_rpm = float(np.max(np.abs(rpm_act))) if len(rpm_act) else 0.0
        rms_iq  = float(np.sqrt(np.mean(iq_act ** 2))) if len(iq_act) else 0.0
        rms_id  = float(np.sqrt(np.mean(id_act ** 2))) if len(id_act) else 0.0
        max_tau = float(np.max(np.abs(tau_ext))) if len(tau_ext) else 0.0
        n_col_samples = int(np.sum(collided > 0))

        summary_banner = tk.Frame(win, bg="#0f172a", padx=12, pady=8)
        summary_banner.pack(side=tk.TOP, fill=tk.X)

        info_text = (
            f"TỔNG SỐ MẪU: {len(records)}  |  THỜI LƯỢNG: {t_arr[-1] - t_arr[0]:.2f}s  |  "
            f"|RPM| Max: {max_rpm:.1f} RPM  |  Iq RMS: {rms_iq:.3f} A  |  Id RMS: {rms_id:.3f} A  |  "
            f"|Tau_ext| Peak: {max_tau:.3f} Nm  |  Mẫu báo va chạm: {n_col_samples}"
        )
        if events:
            n_hit = sum(1 for e in events if e["Su_kien"] in ("VA_CHAM_VI_TRI", "VA_CHAM_GMO"))
            n_out = sum(1 for e in events if e["Su_kien"] == "XONG_HANH_TRINH_DI")
            info_text += f"  |  Va chạm: {n_hit} lần  |  Hành trình đi xong: {n_out}"
        if save_png_path:
            info_text += f"  |  Đã lưu vào thư mục: {os.path.dirname(save_png_path)}"

        tk.Label(
            summary_banner, text=info_text,
            bg="#0f172a", fg="#f8fafc", font=("Consolas", 10, "bold")
        ).pack(anchor="w")

        # 4 Biểu đồ tách riêng RPM, Iq, Id và GMO (+ bảng Góc cánh tay ở trên cùng nếu log có chế độ vị trí)
        fig_log = Figure(figsize=(11.5, 9.6 if has_pos else 8.0), dpi=95, facecolor="white")
        k0 = 1
        if has_pos:
            ax0 = fig_log.add_subplot(n_panels, 1, 1)
            ax0.plot(t_arr, pos_act, color="tab:blue", linewidth=1.6, label="Góc Cánh Tay Thực Tế")
            ax0.plot(t_arr, pos_ref, color="darkorange", linestyle="--", linewidth=1.3, label="Góc Tham Chiếu (Quỹ Đạo)")
            ax0.plot(t_arr, pos_tgt, color="gray", linestyle=":", linewidth=1.1, label="Góc Đích")
            ax0.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
            if np.any(collided > 0):
                ax0.fill_between(t_arr, 0, 1, where=(collided > 0), transform=ax0.get_xaxis_transform(),
                                 color="red", alpha=0.15, label="Va Chạm / Rút Lui")
            ax0.set_ylabel("Góc Trục Ra (°)", fontsize=9)
            ax0.grid(True, linestyle=":")
            ax0.legend(loc="upper right")
            ax0.set_title("1. Bảng Góc Cánh Tay (Position Mode, + = ngược chiều kim đồng hồ)", fontweight="bold", fontsize=10)
            k0 = 2
        ax1 = fig_log.add_subplot(n_panels, 1, k0, sharex=(ax0 if has_pos else None))
        ax2 = fig_log.add_subplot(n_panels, 1, k0 + 1, sharex=ax1)
        ax3 = fig_log.add_subplot(n_panels, 1, k0 + 2, sharex=ax1)
        ax4 = fig_log.add_subplot(n_panels, 1, k0 + 3, sharex=ax1)

        # 1. Biểu đồ Vận tốc
        ax1.plot(t_arr, rpm_act, color="tab:blue", linewidth=1.6, label="RPM Thực Tế")
        ax1.plot(t_arr, rpm_ref, color="darkorange", linestyle="--", linewidth=1.4, label="RPM Target / Trần Bão Hòa")
        ax1.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        ax1.set_ylabel("Vận Tốc (RPM)", fontsize=9)
        ax1.grid(True, linestyle=":")
        ax1.legend(loc="upper right")
        ax1.set_title(f"{k0 + 0}. Bảng Vận Tốc Rotor (RPM Scope)", fontweight="bold", fontsize=10)

        # 2. Biểu đồ Dòng điện Iq
        ax2.plot(t_arr, iq_act, color="darkblue", linewidth=1.6, label="Iq Thực Tế (Mô-men)")
        ax2.plot(t_arr, iq_ref, color="orange", linestyle="--", linewidth=1.4, label="Iq Target")
        ax2.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        ax2.set_ylabel("Dòng Iq (A)", fontsize=9)
        ax2.grid(True, linestyle=":")
        ax2.legend(loc="upper right")
        ax2.set_title(f"{k0 + 1}. Bảng Dòng Điện Trục Q - Sinh Mô-men (Iq Scope)", fontweight="bold", fontsize=10)

        # 3. Biểu đồ Dòng điện Id
        ax3.plot(t_arr, id_act, color="crimson", linewidth=1.6, label="Id Thực Tế (Từ Thông/FW)")
        ax3.axhline(0, color="teal", linestyle="--", linewidth=1.2, alpha=0.8, label="Id Target (0 A)")
        ax3.set_ylabel("Dòng Id (A)", fontsize=9)
        ax3.grid(True, linestyle=":")
        ax3.legend(loc="upper right")
        ax3.set_title(f"{k0 + 2}. Bảng Dòng Điện Trục D - Khử Từ Thông (Id Scope)", fontweight="bold", fontsize=10)

        # 4. Biểu đồ Giám sát Va chạm GMO
        ax4.plot(t_arr, tau_ext, color="purple", linewidth=1.8, label="Tau_ext (Mô-men Ngoại Lực GMO)")
        ax4.plot(t_arr, tau_thresh, color="red", linestyle="--", linewidth=1.4, label="+Ngưỡng Va Chạm")
        ax4.plot(t_arr, -tau_thresh, color="red", linestyle="--", linewidth=1.4, label="-Ngưỡng Va Chạm")
        ax4.axhline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)

        if np.any(collided > 0):
            ax4.fill_between(
                t_arr, -np.max(tau_thresh) * 2.5, np.max(tau_thresh) * 2.5,
                where=(collided > 0), color="red", alpha=0.18, label="Vùng Phát Hiện Va Chạm"
            )

        max_y_tau = max(max_tau, float(np.max(tau_thresh)) * 2.2, 0.06)
        ax4.set_ylim(-max_y_tau * 1.25, max_y_tau * 1.25)
        ax4.set_xlabel("Thời Gian (s)", fontsize=9)
        ax4.set_ylabel("Tau (N.m)", fontsize=9)
        ax4.grid(True, linestyle=":")
        ax4.legend(loc="upper right")
        ax4.set_title(f"{k0 + 3}. Bảng Giám Sát Va Chạm (Generalized Momentum Observer)", fontweight="bold", fontsize=10)

        if len(t_arr) > 1 and t_arr[-1] > t_arr[0]:
            ax1.set_xlim(t_arr[0], t_arr[-1])

        fig_log.tight_layout(pad=1.6)

        if save_png_path:
            try:
                fig_log.savefig(save_png_path, dpi=300, bbox_inches="tight")
            except Exception:
                pass

        canvas_log = FigureCanvasTkAgg(fig_log, master=win)
        canvas_log.draw()

        toolbar_frame = tk.Frame(win, bg="#ffffff")
        toolbar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        toolbar_log = NavigationToolbar2Tk(canvas_log, toolbar_frame)
        toolbar_log.update()

        canvas_log.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    # =========================================================================
    # [THÊM] CHẨN ĐOÁN GIỚI HẠN TỐC ĐỘ CHẾ ĐỘ MÔ-MEN
    # Chỉ in ra console (chạy GUI từ terminal để xem), không thêm/sửa widget nào của giao diện.
    # =========================================================================
    def _on_config_echo(self, data: bytes):
        """Gói 0x108 (cần firmware có gói này): giá trị THẬT trong MCU. Chạy trong luồng đọc serial."""
        try:
            lim = struct.unpack('<H', data[0:2])[0] / 10.0
            thr = struct.unpack('<h', data[2:4])[0] / 1000.0
            flags = data[4]
            build = f"{data[5]:02d}:{data[6]:02d}:{data[7]:02d}"
            self.mcu_config = {"limit_rpm": lim, "gmo_thr": thr, "flags": flags, "build": build,
                               "t": time.time()}
            cfg = (lim, thr, flags, build)
            if cfg != getattr(self, "_last_cfg_echo", None):     # chỉ in khi đổi, không in mỗi 0.5 s
                self._last_cfg_echo = cfg
                state = "TAT (khong gioi han)" if lim <= 1.0 else f"{lim:.1f} RPM"
                print(f"[MCU 0x108] gioi han toc do che do mo-men = {state} | nguong GMO = {thr:.3f} N.m"
                      f" | co = 0x{flags:02X} | firmware build luc {build}", flush=True)
        except Exception:
            pass

    def _torque_limit_watchdog(self):
        """Không cần firmware mới. Chế độ mô-men mà tốc độ vượt XA giới hạn đã đặt (quá phần vượt cho phép
        của bộ kẹp mềm, ~(Iq + bù ma sát) / 0.015 A/RPM <= ~36 RPM) trong > 1.5 s -> firmware KHÔNG áp dụng."""
        try:
            now = time.time()
            lim = float(self.torque_speed_limit_rpm)
            rpm = abs(float(self.latest_rpm))
            over = (self.is_torque_mode == 1 and self.latest_state == 2 and lim > 1.0
                    and rpm > lim + 40.0 and rpm > 1.3 * lim)
            if over:
                if getattr(self, "_trq_over_since", None) is None:
                    self._trq_over_since = now
                elif not getattr(self, "_trq_over_warned", False) and now - self._trq_over_since > 1.5:
                    self._trq_over_warned = True
                    frame = "0x100: " + self._cmd_data(0x09, lim).hex(' ').upper()
                    print(f"[CANH BAO] Che do mo-men: toc do {rpm:.0f} RPM vuot xa gioi han {lim:.0f} RPM."
                          f" GUI da gui lenh 0x09 dung (khung {frame} = {lim:.1f} RPM), va firmware mac dinh"
                          f" 60 RPM ngay ca khi lenh bi roi -> board dang chay ban firmware KHONG co bo gioi han."
                          f" Hay Clean + Build lai va nap lai firmware.", flush=True)
            else:
                self._trq_over_since = None
                self._trq_over_warned = False

            # Nếu firmware có gói 0x108: so giá trị trong MCU với giá trị GUI đang hiển thị
            cfg = getattr(self, "mcu_config", None)
            if cfg is not None and now - cfg.get("t", 0.0) < 2.0 and self.is_torque_mode == 1:
                mismatch = abs(cfg["limit_rpm"] - lim) > 0.5
                if mismatch:
                    if getattr(self, "_cfg_mis_since", None) is None:
                        self._cfg_mis_since = now
                    elif not getattr(self, "_cfg_mis_warned", False) and now - self._cfg_mis_since > 2.0:
                        self._cfg_mis_warned = True
                        print(f"[CANH BAO] GUI hien thi gioi han {lim:.0f} RPM nhung MCU dang dung"
                              f" {cfg['limit_rpm']:.1f} RPM (lenh 0x09 khong toi duoc MCU).", flush=True)
                else:
                    self._cfg_mis_since = None
                    self._cfg_mis_warned = False
        except Exception:
            pass
        if self.is_running:
            self.root.after(500, self._torque_limit_watchdog)

    def on_closing(self):
        self.is_running = False
        try:
            self.send_can_cmd(0x01, force=True)
            time.sleep(0.04)
            self.disconnect_serial()
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = FOCGMOTkApp(root)
    root.after(1000, app._torque_limit_watchdog)
    root.after(1500, app._link_diagnostics)          # tự chẩn đoán đường truyền CAN (in ra console)   # canh giới hạn tốc độ chế độ mô-men (in ra console)
    root.mainloop()