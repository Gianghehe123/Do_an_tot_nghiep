// App/Libs/can.h
#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>

// Cấu trúc lệnh điều khiển vị trí/trở kháng chuẩn MIT (Gói 0x001)
struct MITCommand {
    float p_des{0.0f};
    float v_des{0.0f};
    float kp{0.0f};
    float kd{0.0f};
    float t_ff{0.0f};
};

class CANInterface {
public:
    explicit CANInterface(CAN_HandleTypeDef* hcan);

    bool init();

    // Đọc đồng thời cả gói lệnh 0x100 (GUI) và gói 0x001 (MIT Impedance Mode)
    bool pollMessages(uint32_t& out_std_id, uint8_t& out_cmd_id, float& out_payload, MITCommand& out_mit);

    // Gói 0x100 (hàm cũ giữ lại để tương thích ngược nếu chỉ đọc lệnh 0x100)
    bool receiveCommand(uint8_t& out_cmd_id, float& out_payload);

    // Gói 0x002: Phản hồi trạng thái chuẩn MIT (DLC = 6)
    bool sendMITReplyPacket(uint8_t motor_id, float pos_rad, float vel_rad_s, float torque_nm);

    // Gói 0x102: Trạng thái tổng quát (State, Flags, RPM, Vq, Raw Encoder Counts)
    bool sendStatus(uint8_t state, uint8_t flags, float rpm, float vq, uint16_t raw_counts);

    // Gói 0x104: Truyền từng điểm của bảng bù phi tuyến LUT 128 điểm lên máy tính
    bool sendLUTPoint(uint8_t index, float lut_val);

    // Gói 0x105: Truyền dòng điện Ia, Ib, Id, Iq (đơn vị mA)
    bool sendCurrents(float ia, float ib, float id, float iq);

    // Gói 0x106: Truyền thông số bộ quan sát va chạm GMO (tau_ext, tau_thresh, cờ va chạm, đếm ngược)
    // byte 6, 7 (trước đây luôn = 0): dùng cho chẩn đoán, GUI cũ bỏ qua nên vẫn tương thích.
    bool sendGMOPacket(float tau_ext, float tau_thresh, uint8_t collision_flag, uint8_t countdown_sec,
                       uint8_t extra6 = 0, uint8_t extra7 = 0);

    // Gói 0x107: thời gian thực của vòng lặp (đơn vị 0.1 us): chu kỳ FOC trung bình, lớn nhất, thời gian chạy
    // lớn nhất của FOC+GMO, số mẫu ADC bị mất trong cửa sổ (bão hòa 255), chu kỳ PWM (us, làm tròn).
    bool sendTimingDiag(uint16_t focAvg_01us, uint16_t focMax_01us, uint16_t execMax_01us,
                        uint8_t lostSamples, uint8_t pwmPeriod_us);

    // Gói 0x109: chế độ vị trí (cánh tay gạt). byte 0-3: góc đo int32 [0.001 độ], byte 4-5: góc tham chiếu
    // int16 [0.1 độ], byte 6: pha (PosPhase), byte 7: cờ (bit0 đã đặt góc 0, bit1 đang chạy chu trình,
    // bit2 quỹ đạo đã tới đích, bit4-7 số lần va chạm mod 16). Góc ở trục ra, dương = ngược chiều kim đồng hồ.
    bool sendPositionStatus(float angle_deg, float ref_deg, uint8_t phase, uint8_t flags);

private:
    CAN_HandleTypeDef* hcan_;

    static int   floatToUint(float x, float x_min, float x_max, int bits);
    static float uintToFloat(int x_int, float x_min, float x_max, int bits);
};
