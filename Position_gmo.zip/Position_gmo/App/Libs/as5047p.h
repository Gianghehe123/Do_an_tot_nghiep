// App/Libs/as5047p.h
#pragma once

#include "stm32f4xx_hal.h"
#include "main.h"
#include <cstdint>
#include <cmath>

class AS5047P {
public:
    static constexpr uint16_t CMD_ANGLECOM = 0xFFFF;   // đọc 0x3FFF + parity
    static constexpr uint16_t CMD_DIAAGC   = 0xFFFC;   // đọc 0x3FFC + parity
    static constexpr float    RESOLUTION   = 16384.0f; // 14-bit
    static constexpr int      LUT_SIZE     = 128;
    // Hằng số FLOAT: dùng M_PI (double) trong ISR khiến Cortex-M4F phải giả lập double bằng phần mềm.
    static constexpr float    TWO_PI_F     = 6.28318530717958647692f;
    static constexpr float    CNT2RAD      = TWO_PI_F / RESOLUTION;

    AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs = 21);

    void init();
    bool update();

    // Đọc thanh ghi chẩn đoán DIAAGC: bit 7..0 = AGC (0 = từ trường mạnh, 255 = yếu),
    // bit 8 LF, bit 9 COF, bit 10 MAGH (quá mạnh), bit 11 MAGL (quá yếu).
    // AGC sát 255 hoặc cờ MAGL -> nam châm xa/lệch tâm, nhiễu góc tăng.
    // CHỈ gọi khi vòng điều khiển KHÔNG chạy (tránh tranh chấp SPI với ISR).
    bool readDiagAgc(uint16_t& diag);

    float getRawMechRad() const { return raw_mech_rad_; }
    float getRawElecRad() const { return raw_elec_rad_; }

    float getCalibMechRad() const { return calib_mech_rad_; }
    float getCalibElecRad() const { return calib_elec_rad_; }

    uint16_t getRawCounts() const { return raw_data_; }
    bool isError() const { return has_error_; }

    void setLUT(const float* lut, float zero_offset);
    const float* getLUT() const { return lut_; }
    float getZeroOffset() const { return zero_offset_; }
    bool isCalibrated() const { return is_calibrated_; }

private:
    SPI_HandleTypeDef* hspi_;
    GPIO_TypeDef*      cs_port_;
    uint16_t           cs_pin_;
    uint8_t            pole_pairs_;

    uint16_t raw_data_{0};
    bool     has_error_{false};

    float raw_mech_rad_{0.0f};
    float raw_elec_rad_{0.0f};
    float calib_mech_rad_{0.0f};
    float calib_elec_rad_{0.0f};

    bool  is_calibrated_{false};
    float zero_offset_{0.0f};
    float lut_[LUT_SIZE]{0.0f};

    uint16_t readRegister(uint16_t cmd);
    static bool checkParity(uint16_t data);
    float interpolateLUT(uint16_t counts);
};
