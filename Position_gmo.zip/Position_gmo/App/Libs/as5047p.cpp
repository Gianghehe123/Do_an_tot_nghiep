// App/Libs/as5047p.cpp
#pragma GCC optimize ("O2")
#include "as5047p.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

AS5047P::AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs)
    : hspi_(hspi), cs_port_(cs_port), cs_pin_(cs_pin), pole_pairs_(pole_pairs) {}

void AS5047P::init() {
    cs_port_->BSRR = cs_pin_; // CS High
    // Đảm bảo tốc độ SPI1 đạt ~10.5 MHz (Prescaler /8 trên APB2 84 MHz) để truyền 16-bit chỉ mất ~1.5 us
    MODIFY_REG(hspi_->Instance->CR1, SPI_CR1_BR_Msk, SPI_BAUDRATEPRESCALER_8);
    __HAL_SPI_ENABLE(hspi_);
    HAL_Delay(10);
    readRegister(CMD_ANGLECOM);
}

bool AS5047P::checkParity(uint16_t data) {
    data ^= data >> 8;
    data ^= data >> 4;
    data ^= data >> 2;
    data ^= data >> 1;
    return ((data & 1U) == 0U);
}

uint16_t AS5047P::readRegister(uint16_t cmd) {
    SPI_TypeDef* spi = hspi_->Instance;
    cs_port_->BSRR = static_cast<uint32_t>(cs_pin_) << 16U; // CS Low
    for (volatile int i = 0; i < 10; ++i) { __NOP(); }      // t_L >= 350 ns

    // Xóa sạch dữ liệu cũ và cờ OVR (trên STM32F4 phải đọc DR rồi đọc SR)
    if (spi->SR & (SPI_SR_RXNE | SPI_SR_OVR)) {
        volatile uint32_t dummy = spi->DR;
        dummy = spi->SR;
        (void)dummy;
    }

    uint32_t guard = 0;
    while (!(spi->SR & SPI_SR_TXE)) { if (++guard > 1000u) break; }
    spi->DR = cmd;

    guard = 0;
    uint16_t rx = 0xFFFF;
    while (!(spi->SR & SPI_SR_RXNE)) { if (++guard > 2000u) break; }
    if (spi->SR & SPI_SR_RXNE) rx = static_cast<uint16_t>(spi->DR);

    guard = 0;
    while ((spi->SR & SPI_SR_BSY) && ++guard < 1000u) {}
    cs_port_->BSRR = cs_pin_; // CS High
    return rx;
}

float AS5047P::interpolateLUT(uint16_t counts) {
    if (!is_calibrated_) return 0.0f;

    uint8_t idx = (counts >> 7) & 0x7F;
    uint8_t idx_next = (idx + 1) & 0x7F;
    float frac = static_cast<float>(counts & 0x7F) * (1.0f / 128.0f);

    return lut_[idx] + frac * (lut_[idx_next] - lut_[idx]);
}

bool AS5047P::update() {
    uint16_t rx_data = readRegister(CMD_ANGLECOM);
    if ((rx_data & (1 << 14)) || !checkParity(rx_data)) {
        has_error_ = true;
        return false;
    }

    has_error_ = false;
    raw_data_ = rx_data & 0x3FFF;

    // 1. Góc thô
    raw_mech_rad_ = static_cast<float>(raw_data_) * CNT2RAD;
    const uint32_t elecCounts = (static_cast<uint32_t>(raw_data_) * pole_pairs_) & 0x3FFFu;
    raw_elec_rad_ = static_cast<float>(elecCounts) * CNT2RAD;

    // 2. Góc đã bù LUT 128 điểm
    float corr_rad = raw_mech_rad_ + interpolateLUT(raw_data_) - zero_offset_;
    while (corr_rad >= TWO_PI_F) corr_rad -= TWO_PI_F;
    while (corr_rad < 0.0f)      corr_rad += TWO_PI_F;
    calib_mech_rad_ = corr_rad;

    float turns = corr_rad * static_cast<float>(pole_pairs_) * (1.0f / TWO_PI_F);
    turns -= static_cast<float>(static_cast<int32_t>(turns));
    calib_elec_rad_ = turns * TWO_PI_F;

    return true;
}

bool AS5047P::readDiagAgc(uint16_t& diag)
{
    readRegister(CMD_DIAAGC);
    for (volatile int i = 0; i < 20; ++i) { __NOP(); } // t_H >= 350 ns giữa 2 lệnh liên tiếp
    uint16_t rx = readRegister(CMD_ANGLECOM);
    if ((rx & (1 << 14)) || !checkParity(rx)) {
        return false;
    }
    diag = rx & 0x0FFF;
    return true;
}

void AS5047P::setLUT(const float* lut, float zero_offset) {
    for (int i = 0; i < LUT_SIZE; ++i) {
        lut_[i] = lut[i];
    }
    zero_offset_ = zero_offset;
    is_calibrated_ = true;
}
