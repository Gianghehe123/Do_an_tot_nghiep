// App/Libs/can.cpp
#include "can.h"
#include <algorithm>
#include <cstring>

CANInterface::CANInterface(CAN_HandleTypeDef* hcan) : hcan_(hcan) {}

int CANInterface::floatToUint(float x, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    x = std::max(x_min, std::min(x, x_max));
    return static_cast<int>((x - x_min) * (static_cast<float>((1 << bits) - 1)) / span);
}

float CANInterface::uintToFloat(int x_int, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    return static_cast<float>(x_int) * span / static_cast<float>((1 << bits) - 1) + x_min;
}

bool CANInterface::init() {
    CAN_FilterTypeDef filter;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = 0x0000;
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = 0x0000;
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14;

    if (HAL_CAN_ConfigFilter(hcan_, &filter) != HAL_OK) return false;
    return (HAL_CAN_Start(hcan_) == HAL_OK);
}

bool CANInterface::pollMessages(uint32_t& out_std_id, uint8_t& out_cmd_id, float& out_payload, MITCommand& out_mit) {
    if (HAL_CAN_GetRxFifoFillLevel(hcan_, CAN_RX_FIFO0) > 0) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];

        if (HAL_CAN_GetRxMessage(hcan_, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK) {
            if (rx_header.IDE == CAN_ID_STD) {
                out_std_id = rx_header.StdId;

                if (rx_header.StdId == 0x001 && rx_header.DLC == 8) {
                    int p_int  = (rx_data[0] << 8) | rx_data[1];
                    int v_int  = (rx_data[2] << 4) | (rx_data[3] >> 4);
                    int kp_int = ((rx_data[3] & 0x0F) << 8) | rx_data[4];
                    int kd_int = (rx_data[5] << 4) | (rx_data[6] >> 4);
                    int t_int  = ((rx_data[6] & 0x0F) << 8) | rx_data[7];

                    out_mit.p_des = uintToFloat(p_int, -12.5f, 12.5f, 16);
                    out_mit.v_des = uintToFloat(v_int, -45.0f, 45.0f, 12);
                    out_mit.kp    = uintToFloat(kp_int, 0.0f, 500.0f, 12);
                    out_mit.kd    = uintToFloat(kd_int, 0.0f, 5.0f, 12);
                    out_mit.t_ff  = uintToFloat(t_int, -2.0f, 2.0f, 12);
                    return true;
                } else if (rx_header.StdId == 0x100 && rx_header.DLC >= 1) {
                    out_cmd_id = rx_data[0];
                    if (rx_header.DLC >= 5) {
                        std::memcpy(&out_payload, &rx_data[1], sizeof(float));
                    } else {
                        out_payload = 0.0f;
                    }
                    return true;
                }
            }
        }
    }
    return false;
}

bool CANInterface::receiveCommand(uint8_t& out_cmd_id, float& out_payload) {
    uint32_t std_id = 0;
    MITCommand dummy_mit{};
    if (pollMessages(std_id, out_cmd_id, out_payload, dummy_mit)) {
        return (std_id == 0x100);
    }
    return false;
}

bool CANInterface::sendMITReplyPacket(uint8_t motor_id, float pos_rad, float vel_rad_s, float torque_nm) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[6];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x002;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 6;
    tx_header.TransmitGlobalTime = DISABLE;

    int p_int = floatToUint(pos_rad, -12.5f, 12.5f, 16);
    int v_int = floatToUint(vel_rad_s, -45.0f, 45.0f, 12);
    int t_int = floatToUint(torque_nm, -2.0f, 2.0f, 12);

    tx_data[0] = motor_id;
    tx_data[1] = p_int >> 8;
    tx_data[2] = p_int & 0xFF;
    tx_data[3] = v_int >> 4;
    tx_data[4] = ((v_int & 0x0F) << 4) | (t_int >> 8);
    tx_data[5] = t_int & 0xFF;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendStatus(uint8_t state, uint8_t flags, float rpm, float vq, uint16_t raw_counts) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x102;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = state;
    tx_data[1] = flags; // Bit 0: LUT active, Bit 1: FW active, Bit 2: Torque/Current mode

    int16_t rpm_scaled = static_cast<int16_t>(rpm * 10.0f);
    int16_t vq_scaled  = static_cast<int16_t>(vq * 100.0f);

    std::memcpy(&tx_data[2], &rpm_scaled, sizeof(int16_t));
    std::memcpy(&tx_data[4], &vq_scaled, sizeof(int16_t));
    std::memcpy(&tx_data[6], &raw_counts, sizeof(uint16_t));

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendLUTPoint(uint8_t index, float lut_val) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x104;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = index;
    std::memcpy(&tx_data[1], &lut_val, sizeof(float));
    tx_data[5] = 0;
    tx_data[6] = 0;
    tx_data[7] = 0;

    while (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) == 0) {
        HAL_Delay(1);
    }
    return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
}

bool CANInterface::sendCurrents(float ia, float ib, float id, float iq) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x105;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    int16_t ia_ma = static_cast<int16_t>(ia * 1000.0f);
    int16_t ib_ma = static_cast<int16_t>(ib * 1000.0f);
    int16_t id_ma = static_cast<int16_t>(id * 1000.0f);
    int16_t iq_ma = static_cast<int16_t>(iq * 1000.0f);

    std::memcpy(&tx_data[0], &ia_ma, sizeof(int16_t));
    std::memcpy(&tx_data[2], &ib_ma, sizeof(int16_t));
    std::memcpy(&tx_data[4], &id_ma, sizeof(int16_t));
    std::memcpy(&tx_data[6], &iq_ma, sizeof(int16_t));

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendGMOPacket(float tau_ext, float tau_thresh, uint8_t collision_flag, uint8_t countdown_sec,
                                 uint8_t extra6, uint8_t extra7) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x106;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    int16_t tau_ext_mnm    = static_cast<int16_t>(tau_ext * 1000.0f);
    int16_t tau_thresh_mnm = static_cast<int16_t>(tau_thresh * 1000.0f);

    std::memcpy(&tx_data[0], &tau_ext_mnm, sizeof(int16_t));
    std::memcpy(&tx_data[2], &tau_thresh_mnm, sizeof(int16_t));
    tx_data[4] = collision_flag;
    tx_data[5] = countdown_sec;
    tx_data[6] = extra6;
    tx_data[7] = extra7;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendTimingDiag(uint16_t focAvg_01us, uint16_t focMax_01us, uint16_t execMax_01us,
                                  uint8_t lostSamples, uint8_t pwmPeriod_us) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x107;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    std::memcpy(&tx_data[0], &focAvg_01us, sizeof(uint16_t));
    std::memcpy(&tx_data[2], &focMax_01us, sizeof(uint16_t));
    std::memcpy(&tx_data[4], &execMax_01us, sizeof(uint16_t));
    tx_data[6] = lostSamples;
    tx_data[7] = pwmPeriod_us;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANInterface::sendPositionStatus(float angle_deg, float ref_deg, uint8_t phase, uint8_t flags) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = 0x109;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    // Kẹp trước khi ép kiểu: float ngoài phạm vi ép sang số nguyên là hành vi không xác định
    const float a  = std::max(-2.0e6f, std::min(angle_deg * 1000.0f, 2.0e6f));      // +-2000 độ
    const float r  = std::max(-32767.0f, std::min(ref_deg * 10.0f, 32767.0f));
    const int32_t angle_mdeg = static_cast<int32_t>(a + (a >= 0.0f ? 0.5f : -0.5f));
    const int16_t ref_ddeg   = static_cast<int16_t>(r + (r >= 0.0f ? 0.5f : -0.5f));

    std::memcpy(&tx_data[0], &angle_mdeg, sizeof(int32_t));
    std::memcpy(&tx_data[4], &ref_ddeg, sizeof(int16_t));
    tx_data[6] = phase;
    tx_data[7] = flags;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}
