// App/app.h
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

void setup(void);
void loop(void);

#ifdef __cplusplus
}
#endif
