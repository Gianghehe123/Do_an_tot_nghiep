// FOCLib/MotorController/motor.cpp
#include "motor.h"
#include <algorithm>
#include <cmath>
#pragma GCC optimize ("O2")

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
// Hằng số FLOAT viết thẳng (M_PI là double: so sánh "x > M_PI" trong quickSin chạy bằng double giả lập).
static constexpr float PI_F         = 3.14159265358979323846f;
static constexpr float TWO_PI       = 2.0f * PI_F;
static constexpr float HALF_PI      = 0.5f * PI_F;
static constexpr float INV_TWO_PI   = 1.0f / TWO_PI;
static constexpr float ONE_BY_SQRT3 = 0.57735026919f;
static constexpr float SQRT3_BY_2   = 0.86602540378f;

Motor::Motor(uint8_t polePairs, float motorL_H, uint8_t velLoopFreq_kHz)
    : _polePairs(polePairs),
      _motorL(motorL_H),
      _velLoopFreq_kHz(velLoopFreq_kHz > 0 ? velLoopFreq_kHz : 1) {}

void Motor::setVelocityPll(float bandwidth_rad_s, float ditherCounts)
{
    if (bandwidth_rad_s < 10.0f) bandwidth_rad_s = 10.0f;
    _pllKp = 2.0f * bandwidth_rad_s;              // tắt dần tới hạn (zeta = 1)
    _pllKi = bandwidth_rad_s * bandwidth_rad_s;
    _ditherCounts = (ditherCounts > 0.0f) ? ditherCounts : 0.0f;
    _velEst = VelocityEstimator::PLL;
}

// Lặp phương trình Riccati rời rạc tới hội tụ cho mô hình
//   x = [theta, omega, a_d],  A = [[1,T,T^2/2],[0,1,T],[0,0,1]],  H = [1,0,0],  Q = diag(0, qv*T, qa*T)
// Chạy bằng double một lần lúc khởi động (~300 vòng lặp, vài ms trên Cortex-M4).
static bool solveKalmanGains(double T, double r, double qv, double qa, float out[3])
{
    double P[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    const double A[3][3] = {{1, T, 0.5 * T * T}, {0, 1, T}, {0, 0, 1}};
    double k[3] = {0, 0, 0};
    for (int it = 0; it < 20000; ++it) {
        double AP[3][3], Pm[3][3];
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                AP[i][j] = A[i][0] * P[0][j] + A[i][1] * P[1][j] + A[i][2] * P[2][j];
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                Pm[i][j] = AP[i][0] * A[j][0] + AP[i][1] * A[j][1] + AP[i][2] * A[j][2];
        Pm[1][1] += qv * T;
        Pm[2][2] += qa * T;
        const double S = Pm[0][0] + r;
        const double kn[3] = {Pm[0][0] / S, Pm[1][0] / S, Pm[2][0] / S};
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                P[i][j] = Pm[i][j] - kn[i] * Pm[0][j];
        bool done = (it > 20);
        for (int i = 0; i < 3; ++i) {
            if (std::fabs(kn[i] - k[i]) > 1e-7 * std::fabs(kn[i])) done = false;
            k[i] = kn[i];
        }
        if (done) {
            for (int i = 0; i < 3; ++i) out[i] = static_cast<float>(k[i]);
            return true;
        }
    }
    return false;
}

void Motor::setVelocityKalman(float jOverKt, float encSigma, float qVel, float qDist,
                              float loopFreq_kHz, float currentBw_Hz, float ditherCounts)
{
    constexpr float CPR = AS5047P::RESOLUTION;
    const double T = 1.0 / (static_cast<double>(loopFreq_kHz) * 1000.0);
    const double sigmaRad = static_cast<double>(encSigma) * 2.0 * 3.14159265358979323846 / CPR;
    float K[3];
    if (jOverKt <= 0.0f || !solveKalmanGains(T, sigmaRad * sigmaRad, qVel, qDist, K)) {
        setVelocityPll(300.0f, ditherCounts);           // tham số hỏng -> quay về PLL an toàn
        return;
    }
    _kfK[0] = K[0]; _kfK[1] = K[1]; _kfK[2] = K[2];
    _kfB       = (1.0f / jOverKt) * (CPR / TWO_PI);
    _kfDistMax = _kfB * 5.0f;                            // nhiễu tải tương đương tối đa 5 A
    float a    = static_cast<float>(T) * TWO_PI * currentBw_Hz;
    _kfIqAlpha = (a > 1.0f) ? 1.0f : a;
    _ditherCounts = (ditherCounts > 0.0f) ? ditherCounts : 0.0f;
    _velEst    = VelocityEstimator::KALMAN;
}

float Motor::frictionModelA(float absRpm) const
{
    const float ws = (fricStribeck_RPM > 0.1f) ? fricStribeck_RPM : 0.1f;
    const float x  = absRpm / ws;
    const float x2 = x * x;
    const float e  = (x2 >= 16.0f) ? 0.0f : std::exp(-x2);   // expf: ~100-200 chu kỳ, chấp nhận được ở 5 kHz
    const float is = (fricStatic_A > fricCoulomb_A) ? fricStatic_A : fricCoulomb_A;
    return fricCoulomb_A + (is - fricCoulomb_A) * e;
}

void Motor::init()
{
    pid_Id.reset();
    pid_Iq.reset();
    pid_velocity.reset();
    _velFirstRun = true;       // PLL tự khởi tạo lại ở lần cập nhật kế tiếp
    _velDownsampler = 0;
    controlType = ControlType::DISABLED;
}

// Đưa góc về [0, 2*pi) không dùng fmod (fmodf là lời gọi thư viện, chậm trong ISR)
float Motor::normalizeAngle(float rad)
{
    float t = rad * INV_TWO_PI;
    int32_t k = static_cast<int32_t>(t);
    if (t < 0.0f && static_cast<float>(k) != t) k -= 1;      // floor cho số âm
    float r = (t - static_cast<float>(k)) * TWO_PI;
    if (r >= TWO_PI) r -= TWO_PI;
    if (r < 0.0f)    r += TWO_PI;
    return r;
}

// Xấp xỉ parabol có hiệu chỉnh độ chính xác cao (sai số < 0.001) cho ISR
float Motor::quickSin(float x)
{
    x = normalizeAngle(x);
    if (x > PI_F) x -= TWO_PI; // [-pi, pi]
    constexpr float B = 4.0f / PI_F;
    constexpr float C = -4.0f / (PI_F * PI_F);
    constexpr float P = 0.225f;
    float y = B * x + C * x * std::abs(x);
    return P * (y * std::abs(y) - y) + y;
}

float Motor::quickCos(float x)
{
    return quickSin(x + HALF_PI);
}

// Ước lượng vận tốc bằng PLL (vòng khóa pha bậc 2) thay cho đạo hàm cửa sổ 16 mẫu.
// Đạo hàm khuếch đại nhiễu lượng tử: 1 count / 3.2 ms = 1.14 RPM. PLL là bộ quan sát tích phân:
//   pos_hat' = vel_hat + Kp*e ; vel_hat' = Ki*e ; e = wrap(pos_meas - pos_hat)
// Hàm truyền vận tốc = Ki*s / (s^2 + Kp*s + Ki): vi phân thông thấp bậc 2, không sai số xác lập
// khi vận tốc không đổi. Nhiễu ra ~ sigma_enc * sqrt(dt * wn^3 / 4).
void Motor::updateVelocityEstimator(float dt_sec)
{
    constexpr float CPR      = AS5047P::RESOLUTION;   // 16384
    constexpr float HALF_CPR = 0.5f * CPR;

    const uint16_t raw = _sensor->getRawCounts();

    // Nguồn vị trí cho PLL: góc cơ ĐÃ BÙ LUT khi có. Sai số phi tuyến của encoder (lệch tâm nam châm)
    // biến thành gợn vận tốc tỉ lệ với tốc độ: INL 0.5° + 0.4° cho ~1.2 RPM rms ở 100 RPM nếu dùng raw.
    const bool useCal = isLutActive();
    float pos = useCal ? _sensor->getCalibMechRad() * (CPR / TWO_PI) : static_cast<float>(raw);

    if (_velFirstRun) {
        _prevRawCnt  = raw;
        _totalCounts = raw;
        _gatedPos    = pos;
        _pllPos      = pos;
        _pllVel      = 0.0f;
        _kfDist      = 0.0f;
        _kfIqModel   = 0.0f;
        _pllUsedCal  = useCal;
        _velFirstRun = false;
    }
    if (useCal != _pllUsedCal || _estResync) {   // đổi nguồn góc / sau gián đoạn dài: nối lại vị trí
        _gatedPos   = pos;
        _pllPos     = pos;
        _pllUsedCal = useCal;
        _estResync  = false;
    }

    // 1. Vị trí đa vòng bằng số nguyên (cho MIT) - không qua lọc
    int32_t d_cnt = static_cast<int32_t>(raw) - static_cast<int32_t>(_prevRawCnt);
    if (d_cnt > 8192)       d_cnt -= 16384;
    else if (d_cnt < -8192) d_cnt += 16384;
    _prevRawCnt = raw;
    _totalCounts += d_cnt;
    _multiTurnRad = static_cast<float>(_totalCounts) * (TWO_PI / CPR);

    // 1b. Chế độ vị trí: góc TRỤC RA [độ] tính từ bộ đếm số nguyên (không trôi). Đặt góc 0 thực hiện tại đây vì
    //     _totalCounts là int64: ghi/đọc từ loop() sẽ không nguyên tử. Không đặt 0 khi đang điều khiển vị trí
    //     (tham chiếu sẽ nhảy theo -> cánh tay giật); app.cpp đã chặn, đây là lớp bảo vệ thứ hai.
    if (_posZeroReq) {
        if (controlType != ControlType::POSITION) _posZeroCounts = _totalCounts;
        _posZeroReq = false;
    }
    _posMeasDeg = posDirSign * static_cast<float>(_totalCounts - _posZeroCounts) * (360.0f / (CPR * posGearRatio));

    // 2. Cổng chống rung (hysteresis): đầu ra chỉ dịch khi đầu vào ra khỏi +-H count.
    //    Chỉ dùng cho vận tốc, góc điện FOC vẫn lấy từ encoder trực tiếp.
    if (_ditherCounts > 0.0f) {
        float e = pos - _gatedPos;
        if (e > HALF_CPR)       e -= CPR;
        else if (e < -HALF_CPR) e += CPR;
        if (e > _ditherCounts)       _gatedPos += e - _ditherCounts;
        else if (e < -_ditherCounts) _gatedPos += e + _ditherCounts;
        if (_gatedPos >= CPR)        _gatedPos -= CPR;
        else if (_gatedPos < 0.0f)   _gatedPos += CPR;
        pos = _gatedPos;
    }

    if (_velEst == VelocityEstimator::KALMAN) {
        // 3a. KALMAN. Dự báo bằng mô hình cơ: gia tốc = Kt/J * iq + gia tốc nhiễu tải (ước lượng).
        //     iq dùng là iq LỆNH qua mô hình trễ vòng dòng (iq đo nhiễu ~0.17 A rms sẽ làm vận tốc nhiễu gấp 4).
        //     Nhờ biết trước gia tốc, ước lượng không bị trễ khi tăng/giảm tốc theo lệnh như PLL.
        _kfIqModel += (_iqCmdObs - _kfIqModel) * _kfIqAlpha;
        const float acc = _kfB * _kfIqModel + _kfDist;
        _pllPos += dt_sec * _pllVel + 0.5f * dt_sec * dt_sec * acc;
        _pllVel += dt_sec * acc;
        float e = pos - _pllPos;
        if (e > HALF_CPR)       e -= CPR;
        else if (e < -HALF_CPR) e += CPR;
        _pllPos += _kfK[0] * e;
        _pllVel += _kfK[1] * e;
        _kfDist += _kfK[2] * e;
        if (_kfDist > _kfDistMax)       _kfDist = _kfDistMax;
        else if (_kfDist < -_kfDistMax) _kfDist = -_kfDistMax;
        if (_pllPos >= CPR)        _pllPos -= CPR;
        else if (_pllPos < 0.0f)   _pllPos += CPR;
    } else {
        // 3b. PLL: dự báo -> sai số (wrap) -> hiệu chỉnh
        _pllPos += dt_sec * _pllVel;
        float delta = pos - _pllPos;
        if (delta > HALF_CPR)       delta -= CPR;
        else if (delta < -HALF_CPR) delta += CPR;
        _pllPos += dt_sec * _pllKp * delta;
        _pllVel += dt_sec * _pllKi * delta;
        if (_pllPos >= CPR)        _pllPos -= CPR;
        else if (_pllPos < 0.0f)   _pllPos += CPR;

        // Snap-to-zero (kiểu ODrive): vận tốc nhỏ hơn nửa bước tích phân của 1 count -> đúng bằng 0
        if (std::abs(_pllVel) < 0.5f * dt_sec * _pllKi) _pllVel = 0.0f;
    }

    float velRadS = _pllVel * (TWO_PI / CPR);
    if (_kfVel != nullptr)  velRadS = _kfVel->updateEstimate(velRadS);
    if (_lpfVel != nullptr) velRadS = _lpfVel->update(velRadS);

    _velRadS = velRadS;
    _velRpm  = velRadS * (60.0f / TWO_PI);
    // Bỏ deadband 0.25 RPM cũ: phi tuyến trong đường hồi tiếp, và với nhiễu ~0.3 RPM nó không đủ rộng.
}

void Motor::outputMinMaxPhaseVoltage(float ud, float uq, float s, float c)
{
    // 8. Park ngược (dq -> alpha-beta) & Clarke ngược (alpha-beta -> abc)
    float uAlpha = ud * c - uq * s;
    float uBeta  = ud * s + uq * c;

    float ua = uAlpha;
    float ub = -0.5f * uAlpha + SQRT3_BY_2 * uBeta;
    float uc = -0.5f * uAlpha - SQRT3_BY_2 * uBeta;

    // 9. Dịch tâm Min-Max: cộng (Vbus/2 - (Umax + Umin)/2) cho cả 3 pha
    float uMax = (ua > ub) ? ua : ub;  if (uc > uMax) uMax = uc;
    float uMin = (ua < ub) ? ua : ub;  if (uc < uMin) uMin = uc;
    float vBus = _driver->getVBus();
    float centerOffset = 0.5f * vBus - 0.5f * (uMax + uMin);

    ua += centerOffset;
    ub += centerOffset;
    uc += centerOffset;

    // 10. Xuất điện áp 3 pha xuống Gate Driver
    _driver->setPhaseVoltage(ua, ub, uc);
}

void Motor::updateFOC(float dt_sec)
{
    if (_currentSensor == nullptr || _sensor == nullptr || _driver == nullptr) return;

    // 1. Lấy dòng điện từ CurrentSensorInjected
    _currentSensor->update();
    _ia = _currentSensor->getIa();
    _ib = _currentSensor->getIb();
    _ic = _currentSensor->getIc();

    // 2. Đọc góc từ encoder và cập nhật bộ ước lượng vận tốc với dt THỰC
    _sensor->update();
    updateVelocityEstimator(dt_sec);
    // Vận tốc điện đã lọc cho feedforward back-EMF: cập nhật mọi chế độ (kể cả DISABLED) để khi chuyển sang
    // điều khiển mô-men lúc rotor đang quay, feedforward đã đúng giá trị ngay chu kỳ đầu.
    _omegaFFFilt = _lpfFF.update(_velRadS * static_cast<float>(_polePairs));

    // 3. Lấy góc điện và tính sin/cos MỘT lần
    float eAngle = (_useLut && _sensor->isCalibrated())
                       ? _sensor->getCalibElecRad()
                       : _sensor->getRawElecRad();
    float s = quickSin(eAngle);
    float c = quickCos(eAngle);

    // 4. Clarke: abc -> alpha-beta
    float iAlpha = _ia;
    float iBeta  = ONE_BY_SQRT3 * (_ib - _ic);

    // 5. Park: alpha-beta -> dq
    _idRaw =  c * iAlpha + s * iBeta;
    _iqRaw =  c * iBeta  - s * iAlpha;

    // 6. Lọc thông thấp Id, Iq
    _idFilt = (_lpfId != nullptr) ? _lpfId->update(_idRaw) : _idRaw;
    _iqFilt = (_lpfIq != nullptr) ? _lpfIq->update(_iqRaw) : _iqRaw;

    if (controlType == ControlType::DISABLED) {
         if (autoZeroAllowed && std::abs(_velRpm) < autoZeroMaxRpm) {
             _currentSensor->updateAutoZeroWhenIdle(autoZeroAlpha);
             _kfDist    = 0.0f;
             _kfIqModel = 0.0f;
         }
         pid_Id.reset();
         pid_Iq.reset();
         _ud = 0.0f;
         _uq = 0.0f;
         _iqCmdObs = 0.0f;
         _driver->setDutyCycle(0.5f, 0.5f, 0.5f);
         return;
     }

    if (controlType == ControlType::VOLTAGE) {
        _iqCmdObs = 0.0f;
        outputMinMaxPhaseVoltage(_ud, _uq, s, c);
        return;
    }

        if (_enableFW) {
            float absRpm = std::abs(_velRpm);
            _targetId = (absRpm > 380.0f) ? -std::min(0.40f, (absRpm - 380.0f) * 0.004f) : 0.0f;
        } else {
            _targetId = 0.0f;
        }

        float iqCmd = _targetIq;
            if (controlType == ControlType::CURRENT && std::abs(_targetIq) > 0.02f) {
                if (fricCompTorque) {
                    const float sgn = (_targetIq > 0.0f) ? 1.0f : -1.0f;
                    iqCmd += sgn * fricCoulomb_A;
                }
                if (torqueSpeedLimit_RPM > 1.0f) {
                            if (_targetIq > 0.0f && _velRpm > torqueSpeedLimit_RPM) {
                                iqCmd -= (_velRpm - torqueSpeedLimit_RPM) * torqueSpeedDamping;
                                iqCmd = std::max(iqCmd, 0.0f);
                            } else if (_targetIq < 0.0f && _velRpm < -torqueSpeedLimit_RPM) {
                                iqCmd += (-_velRpm - torqueSpeedLimit_RPM) * torqueSpeedDamping;
                                iqCmd = std::min(iqCmd, 0.0f);
                            }
                        }
                    }

        float limId = __constrain(_targetId, -limitCurrent, limitCurrent);
        float limIq = __constrain(iqCmd, -limitCurrent, limitCurrent);

        // 7. Mô hình điện áp chuẩn (R*I* + Decoupling + Back-EMF) + Bộ PI tinh chỉnh (Trim PI)
        //    Giúp điện áp Uq phẳng tuyệt đối ở tốc độ thấp dù ADC ở Gain 10 (0.161 A/LSB)!
        _iqCmdObs = limIq;
        const float omega_e = _velRadS * static_cast<float>(_polePairs);
        const float vmax    = limitVoltage;
        constexpr float R_PHASE = 0.335f; // Điện trở 1 pha GIM8108-8 (GDS68 đấu Y)

        const float errD  = limId - _idFilt;
        float integD      = pid_Id.integral + pid_Id.ki * errD;
        const float udFF  = R_PHASE * limId - omega_e * _motorL * limIq;
        const float udRaw = udFF + pid_Id.kp * errD + integD;
        const float ud    = __constrain(udRaw, -vmax, vmax);
        if (ud != udRaw && udRaw * errD > 0.0f) integD = pid_Id.integral;
        pid_Id.integral = __constrain(integD, -2.5f, 2.5f); // Kẹp tích phân vừa đủ bù sai lệch mô hình

        const float uqMax = std::sqrt(std::max(vmax * vmax - ud * ud, 0.0f));
        const float errQ  = limIq - _iqFilt;
        float integQ      = pid_Iq.integral + pid_Iq.ki * errQ;
        const bool  ffOn  = (_ffMode == 2) || (_ffMode == 1 && controlType == ControlType::CURRENT);
        const float uqFF  = R_PHASE * limIq + omega_e * _motorL * limId + (ffOn ? _omegaFFFilt * _lambda : 0.0f);
        const float uqRaw = uqFF + pid_Iq.kp * errQ + integQ;
        const float uq    = __constrain(uqRaw, -uqMax, uqMax);
        if (uq != uqRaw && uqRaw * errQ > 0.0f) integQ = pid_Iq.integral;
        pid_Iq.integral = __constrain(integQ, -2.5f, 2.5f);

        _ud = ud;
        _uq = uq;

        // 8, 9, 10. Bù trễ pha ZOH 1.25 chu kỳ + Park ngược + Dịch tâm Min-Max
        const float eAngleOut = eAngle + 1.25f * omega_e * dt_sec;
        outputMinMaxPhaseVoltage(_ud, _uq, quickSin(eAngleOut), quickCos(eAngleOut));
}

void Motor::updateVelocity(float dt_sec)
{
    // Chia tần theo thời gian: chạy khi đã tích lũy ~1 chu kỳ vòng tốc độ (5 lần gọi @5 kHz, 4 lần @4 kHz)
    _velDtAcc += dt_sec;
    const float period = 1.0f / (static_cast<float>(_velLoopFreq_kHz) * 1000.0f);
    if (_velDtAcc < 0.95f * period) return;
    const float dt_vel = _velDtAcc;
    _velDtAcc = 0.0f;

    if (controlType == ControlType::POSITION) {
        updatePositionLoop(dt_vel);
        return;
    }
    if (controlType != ControlType::VELOCITY) return;

    float rampStep = velRampRate_RPM_per_s * dt_vel;

    if (_rampedRpm < _targetRpm) {
        _rampedRpm = std::min(_rampedRpm + rampStep, _targetRpm);
    } else if (_rampedRpm > _targetRpm) {
        _rampedRpm = std::max(_rampedRpm - rampStep, _targetRpm);
    }

    float velErr = _rampedRpm - _velRpm;
    pid_velocity.integral = __constrain(
        pid_velocity.integral + pid_velocity.ki * velErr * dt_vel,
        -pid_velocity.limit, pid_velocity.limit);

    // Feedforward: nhớt (tuyến tính) + Coulomb (theo DẤU của tham chiếu, không theo vận tốc đo
    // để không bị nhiễu đo làm đảo dấu liên tục quanh 0)
    // Feedforward ma sát theo VẬN TỐC THAM CHIẾU (_rampedRpm) thay vì vận tốc đo (_velRpm)
        // để triệt tiêu hoàn toàn hiện tượng tự kích dính-trượt (Stick-Slip) ở 10 - 30 RPM!
    float iqFF = _rampedRpm * velFeedforwardGain;
        if (fricCompVelocity && std::abs(_rampedRpm) > 0.05f) {
            const float band = (velCoulombBand_RPM > 0.1f) ? velCoulombBand_RPM : 0.1f;
            // Chỉ phụ thuộc vào tham chiếu _rampedRpm -> tạo mô-men nền phẳng tuyệt đối, không tự kích stick-slip
            iqFF += __constrain(_rampedRpm / band, -1.0f, 1.0f) * frictionModelA(std::abs(_rampedRpm));
        }
        _targetIq  = __constrain(iqFF + pid_velocity.kp * velErr + pid_velocity.integral,
                                 -limitCurrent, limitCurrent);
}

void Motor::setControlType(ControlType mode)
{
    if (controlType != mode) {
        pid_Id.reset();
        pid_Iq.reset();
        pid_velocity.reset();
        if (mode == ControlType::VELOCITY) {
            _rampedRpm = _velRpm;
        }
        if (mode == ControlType::POSITION) {     // vào chế độ vị trí: giữ nguyên tại chỗ, chờ bộ điều phối ra lệnh
            _posRef      = _posMeasDeg;
            _posVel      = 0.0f;
            _posAcc      = 0.0f;
            _posGoal     = _posRef;
            _trajT       = 0.0f;
            _posTrajDone = true;
            _posHolding  = false;
        }
        controlType = mode;
    }
}

void Motor::setVoltage(float ud, float uq)
{
    if (controlType != ControlType::VOLTAGE) return;
    _ud = __constrain(ud, -limitVoltage, limitVoltage);
    _uq = __constrain(uq, -limitVoltage, limitVoltage);
}

void Motor::setCurrent(float iqTarget, float idTarget)
{
    if (controlType != ControlType::CURRENT) return;
    _targetIq = __constrain(iqTarget, -limitCurrent, limitCurrent);
    _targetId = __constrain(idTarget, -limitCurrent, limitCurrent);
}

void Motor::setRPM(float rpmTarget)
{
    if (controlType != ControlType::VELOCITY) return;
    _targetRpm = rpmTarget;
}

void Motor::applyOpenLoopVoltage(float ud, float uq, float elecAngle_rad)
{
    float s = quickSin(elecAngle_rad);
    float c = quickCos(elecAngle_rad);
    outputMinMaxPhaseVoltage(ud, uq, s, c);
}

/* ======================= CHẾ ĐỘ VỊ TRÍ (cánh tay gạt) ======================= */
// Quỹ đạo hình thang GIẢI TÍCH có vận tốc đầu vi: tính một lần khi đổi đích, mỗi chu kỳ chỉ tra công thức theo
// thời gian -> tới đích chính xác tuyệt đối (bản tích phân từng bước vọt lố ~vmax*dt/2). Xử lý được trường hợp
// đang chạy ngược chiều đích hoặc nhanh hơn vmax (phanh trước rồi mới chạy): cần cho tình huống va chạm.
void Motor::planTrapezoid(float xf, float xi, float vi, float vmax, float amax)
{
    if (vmax < 0.1f)  vmax = 0.1f;
    if (amax < 1.0f)  amax = 1.0f;
    const float dx     = xf - xi;
    const float dxStop = ((vi >= 0.0f) ? 1.0f : -1.0f) * vi * vi / (2.0f * amax);   // quãng phanh tới đứng yên
    const float s      = (dx - dxStop >= 0.0f) ? 1.0f : -1.0f;                       // chiều của đoạn chạy chính
    float ar = s * amax;
    const float dr = -s * amax;
    float vr = s * vmax;
    if (s * vi > s * vr) ar = -s * amax;          // đang nhanh hơn vmax theo chiều chạy: pha 1 là giảm tốc
    float ta = (vr - vi) / ar;
    float td = -vr / dr;
    const float dxMin = 0.5f * ta * (vr + vi) + 0.5f * td * vr;
    float tv = 0.0f;
    if (s * dx < s * dxMin && std::abs(dr - ar) > 1e-6f) {
        // Quãng ngắn: không kịp lên vmax -> tam giác, đỉnh vận tốc vr thấp hơn
        vr = s * std::sqrt(std::max((dr * vi * vi + 2.0f * ar * dr * dx) / (dr - ar), 0.0f));
        ta = std::max(0.0f, (vr - vi) / ar);
        td = std::max(0.0f, -vr / dr);
    } else {
        tv = std::max(0.0f, (dx - dxMin) / vr);
    }
    _traj.xi = xi;  _traj.vi = vi;  _traj.xf = xf;
    _traj.ar = ar;  _traj.dr = dr;  _traj.vr = vr;
    _traj.ta = ta;  _traj.tv = tv;  _traj.td = td;
    _traj.tf = ta + tv + td;
    _traj.ya = xi + vi * ta + 0.5f * ar * ta * ta;
}

void Motor::posMoveTo(float goalDeg, float speedDegS, float accelDegS2, bool fromMeasured)
{
    float x0 = _posRef;
    float v0 = _posVel;
    if (fromMeasured || controlType != ControlType::POSITION) {
        // Bắt đầu từ vị trí ĐO với vận tốc tham chiếu = 0 ("dừng tại chỗ"), KHÔNG lấy vận tốc đo: khi va chạm, vận tốc
        // đo vẫn hướng vào vật cản -> quỹ đạo sẽ tiến thêm v^2/2a rồi mới quay đầu, motor tiếp tục ép (SIL 180 độ/s:
        // Iq +2 A thêm 60 ms sau khi đã phát hiện). Với v = 0, vòng tốc độ phanh ngay rồi mới chạy theo chiều rút.
        x0 = _posMeasDeg;
        v0 = 0.0f;
        pid_velocity.integral = 0.0f;                        // bỏ lực ép đã tích trong khâu I
    }
    planTrapezoid(goalDeg, x0, v0, std::abs(speedDegS), std::abs(accelDegS2));
    _posGoal     = goalDeg;
    _posRef      = x0;
    _posVel      = v0;
    _posAcc      = 0.0f;
    _trajT       = 0.0f;
    _posTrajDone = false;
}

void Motor::updatePositionLoop(float dt)
{
    // 1. Tham chiếu từ quỹ đạo
    if (!_posTrajDone) {
        _trajT += dt;
        const TrapPlan& p = _traj;
        const float t = _trajT;
        if (t < p.ta) {
            _posRef = p.xi + p.vi * t + 0.5f * p.ar * t * t;
            _posVel = p.vi + p.ar * t;
            _posAcc = p.ar;
        } else if (t < p.ta + p.tv) {
            _posRef = p.ya + p.vr * (t - p.ta);
            _posVel = p.vr;
            _posAcc = 0.0f;
        } else if (t < p.tf) {
            const float tr = t - p.tf;                       // âm: thời gian còn lại tính ngược
            _posRef = p.xf + 0.5f * p.dr * tr * tr;
            _posVel = p.dr * tr;                              // = đạo hàm của vị trí ở dòng trên
            _posAcc = p.dr;
        } else {
            _posRef = p.xf;
            _posVel = 0.0f;
            _posAcc = 0.0f;
            _posTrajDone = true;
        }
    } else {
        _posVel = 0.0f;
        _posAcc = 0.0f;
    }

    // 2. P vị trí. Đã tới đích và nằm trong vùng chết: coi sai lệch = 0, không đẩy tiếp vào ma sát tĩnh
    //    (P + khâu I vận tốc + ma sát tĩnh = dao động săn quanh đích).
    //    Có TRỄ: vào giữ khi |sai lệch| < vùng chết, chỉ thoát khi bị đẩy lệch quá 2 lần vùng chết. Không có trễ thì
    //    sau mỗi lần trượt (rotor bứt ma sát tĩnh rồi vọt ~0.45 độ) cánh tay lại rơi ra ngoài vùng chết -> săn mãi.
    float err = _posRef - _posMeasDeg;
    const float aerr = std::abs(err);
    if (!_posTrajDone)       _posHolding = false;
    else if (_posHolding)    { if (aerr > 2.0f * posDeadband_deg) _posHolding = false; }
    else if (aerr < posDeadband_deg) _posHolding = true;
    const bool holding = _posHolding;
    if (holding) err = 0.0f;
    const float k      = posDirSign * posGearRatio / 6.0f;  // độ/s trục ra -> RPM rotor
    const float refRpm = _posVel * k;
    const float cmdRpm = (_posVel + posKp * err) * k;

    // 3. PI vận tốc như chế độ VELOCITY nhưng KHÔNG qua ramp (quỹ đạo đã giới hạn gia tốc; ramp chồng lên
    //    vòng vị trí sẽ thành trễ trong vòng kín -> vọt lố)
    const float velErr = cmdRpm - _velRpm;
    float integ = pid_velocity.integral + pid_velocity.ki * velErr * dt;
    if (holding) integ *= std::max(0.0f, 1.0f - dt / 0.2f);  // đứng giữ: xả khâu I (tau 0.2 s), không đốt dòng
    pid_velocity.integral = __constrain(integ, -pid_velocity.limit, pid_velocity.limit);

    // 4. Feedforward theo THAM CHIẾU (giống VELOCITY): nhớt + ma sát Stribeck + gia tốc J/Kt * alpha
    float iqFF = refRpm * velFeedforwardGain;
    if (fricCompVelocity && std::abs(refRpm) > 0.05f) {
        const float band = (velCoulombBand_RPM > 0.1f) ? velCoulombBand_RPM : 0.1f;
        iqFF += __constrain(refRpm / band, -1.0f, 1.0f) * frictionModelA(std::abs(refRpm));
    }
    iqFF += posJoverKt * (_posAcc * k * (TWO_PI / 60.0f));  // độ/s^2 trục ra -> rad/s^2 rotor

    _targetIq = __constrain(iqFF + pid_velocity.kp * velErr + pid_velocity.integral, -limitCurrent, limitCurrent);
}
