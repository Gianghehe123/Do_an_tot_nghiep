// FOCLib/MotorController/motor.h
#pragma once
#include "../CurrentSensors/currentSensorInjected.h"
#include "../MotorDrivers/drv8301Driver.h"
#include "../SignalFilters/lowpassFilter.h"
#include "../SignalFilters/kalmanFilter.h"
#include "../../Libs/as5047p.h"
#include <cstdint>

enum class ModulationType : uint8_t {
    FOC = 0
};

enum class ControlType : uint8_t {
    DISABLED = 0,
    VOLTAGE  = 1,
    CURRENT  = 2,
    VELOCITY = 3,
    POSITION = 4
};

enum class VelocityEstimator : uint8_t {
    PLL    = 0,   // vòng khóa pha bậc 2 (chỉ dùng encoder)
    KALMAN = 1    // Kalman 3 trạng thái [góc, vận tốc, gia tốc nhiễu tải] + Iq lệnh làm đầu vào
};

struct PIParams {
    float kp{0.0f};
    float ki{0.0f};
    float limit{0.0f};
    float integral{0.0f};

    void reset() { integral = 0.0f; }
};

class Motor {
public:
    Motor(uint8_t polePairs, float motorL_H, uint8_t velLoopFreq_kHz = 1);

    void appendDriver(DRV8301Driver* driver) { _driver = driver; }
    void appendSensor(AS5047P* sensor) { _sensor = sensor; }
    void appendCurrentSensor(CurrentSensorInjected* cs) { _currentSensor = cs; }
    void appendCurrentFilters(LowpassFilter* lpfId, LowpassFilter* lpfIq) {
        _lpfId = lpfId;
        _lpfIq = lpfIq;
    }
    // Bộ lọc thêm SAU PLL (tùy chọn, mặc định không dùng - PLL đã là bộ lọc bậc 2)
    void appendVelocityFilter(LowpassFilter* lpfVel, KalmanFilter* kfVel = nullptr) {
        _lpfVel = lpfVel;
        _kfVel  = kfVel;
    }

    // PLL vận tốc: bandwidth [rad/s] (Kp = 2*wn, Ki = wn^2, tắt dần tới hạn),
    // ditherCounts = cổng chống rung (count), 0 = tắt. Gọi trước khi bật vòng điều khiển.
    void setVelocityPll(float bandwidth_rad_s, float ditherCounts = 0.0f);

    // Kalman vận tốc có đầu vào mô-men. Tính độ lợi trạng thái xác lập (Riccati, số double) MỘT lần lúc khởi động.
    //   jOverKt      : J/Kt [A.s^2/rad] - plant: gia tốc = (iq - nhiễu tải) / (J/Kt)
    //   encSigma     : độ lệch chuẩn nhiễu encoder [count] -> R
    //   qVel, qDist  : nhiễu quá trình trên vận tốc và trên gia tốc nhiễu tải -> Q
    //   loopFreq_kHz : tần số gọi updateFOC; currentBw_Hz: băng thông vòng dòng (mô hình trễ iq lệnh -> iq thật)
    void setVelocityKalman(float jOverKt, float encSigma, float qVel, float qDist,
                           float loopFreq_kHz, float currentBw_Hz, float ditherCounts = 0.0f);
    VelocityEstimator getVelocityEstimator() const { return _velEst; }
    const float* getKalmanGains() const { return _kfK; }
    // Mô-men nhiễu ước lượng (ma sát + ngoại lực) quy ra dòng [A], dương = cản chiều quay dương. Chỉ có ở KALMAN.
    float getDisturbanceIq() const { return (_kfB > 0.0f) ? -_kfDist / _kfB : 0.0f; }

    // Feedforward back-EMF trục q (uq += omega_e_loc * lambda). lambda = 0 -> tắt.
    // Vận tốc cho feedforward đi qua LPF riêng (lpfHz): back-EMF chỉ đổi theo tốc độ cơ (chậm), còn nhiễu
    // vận tốc ước lượng nếu đưa thẳng vào uq sẽ thành nhiễu dòng -> nhiễu mô-men (mô phỏng: +30-70% dao động).
    // mode: 0 = tắt, 1 = chỉ khi điều khiển dòng/mô-men (CURRENT), 2 = mọi chế độ có vòng dòng
    void setBackEmfFeedforward(float lambda_Wb, float lpfHz, float loopFreq_kHz, uint8_t mode = 1)
    {
        _lambda = lambda_Wb;
        _ffMode = mode;
        _lpfFF.setCutOffFreq(lpfHz, loopFreq_kHz * 1000.0f);
        _lpfFF.reset(0.0f);
    }

    void init();

    // Vòng dòng FOC. dt_sec = thời gian THỰC kể từ lần gọi trước (đo bằng DWT), không phải hằng số:
    // nếu ISR quá giờ làm mất mẫu ADC thì mọi đại lượng theo thời gian vẫn đúng.
    void updateFOC(float dt_sec);

    // Vòng tốc độ: tự chia tần theo THỜI GIAN tích lũy (~1 ms), dùng đúng khoảng thời gian thực đã trôi qua.
    void updateVelocity(float dt_sec);

    // Gọi sau một khoảng gián đoạn dài (hiệu chỉnh offset, reset tầng công suất...): bộ ước lượng nối lại
    // vị trí theo encoder thay vì coi bước nhảy vị trí là vận tốc.
    void requestEstimatorResync() { _estResync = true; }

    // Chuyển chế độ và đặt target (có reset tích phân khi đổi chế độ)
    void setControlType(ControlType mode);
    ControlType getControlType() const { return controlType; }

    void setVoltage(float ud, float uq);
    void setCurrent(float iqTarget, float idTarget = 0.0f);
    void setRPM(float rpmTarget);

    // Áp điện áp trực tiếp theo góc điện bất kỳ (dùng khi hiệu chỉnh LUT)
    void applyOpenLoopVoltage(float ud, float uq, float elecAngle_rad);

    void setUseLUT(bool use) { _useLut = use; }
    bool getUseLUT() const { return _useLut; }
    // LUT thực sự đang được dùng (bật + đã hiệu chỉnh trong phiên này)
    bool isLutActive() const { return _useLut && _sensor != nullptr && _sensor->isCalibrated(); }

    void setFieldWeakening(bool enable) { _enableFW = enable; }
    bool getFieldWeakening() const { return _enableFW; }

    // Getters cho Telemetry & GMO
    float getIa() const { return _ia; }
    float getIb() const { return _ib; }
    float getIc() const { return _ic; }
    float getId() const { return _idFilt; }
    float getIq() const { return _iqFilt; }
    float getUd() const { return _ud; }
    float getUq() const { return _uq; }
    float getVelocityRPM() const { return _velRpm; }
    float getVelocityRadS() const { return _velRadS; }
    float getMultiTurnRad() const { return _multiTurnRad; }

    ModulationType modulationType{ModulationType::FOC};
    ControlType    controlType{ControlType::DISABLED};

    PIParams pid_Id;
    PIParams pid_Iq;
    PIParams pid_velocity;

    float limitCurrent{2.2f};
    float limitVoltage{8.0f};
    float velRampRate_RPM_per_s{200.0f};
    float velFeedforwardGain{0.0f};      // [A/RPM] ma sát nhớt
    float velCoulombBand_RPM{5.0f};      // vùng chuyển dấu mượt quanh 0 RPM của tham chiếu

    // Mô hình ma sát Stribeck quy ra dòng: I(w) = Ic + (Is - Ic) * exp(-(|w| / ws)^2)
    //   đứng yên -> Is (gần mức bứt), đang quay nhanh hơn vài RPM -> Ic (Coulomb)
    float fricCoulomb_A{0.0f};
    float fricStatic_A{0.0f};
    float fricStribeck_RPM{3.0f};
    bool  fricCompVelocity{false};       // feedforward ma sát trong vòng tốc độ
    float torqueSpeedLimit_RPM{60.0f};   // Giới hạn tốc độ khi chạy CURRENT mode (0 = không giới hạn)
    float torqueSpeedDamping{0.035f};    // Hệ số kẹp mềm [A/RPM] khi vận tốc vượt torqueSpeedLimit_RPM
    volatile bool fricCompTorque{false}; // bù ma sát ở chế độ mô-men (chỉ lệnh 0x03, không dùng cho MIT)
    float frictionModelA(float absRpm) const;

    // Auto-zero offset dòng: chỉ chạy khi DISABLED + |vận tốc| < autoZeroMaxRpm + được phép
    float         autoZeroAlpha{0.0005f};
    float         autoZeroMaxRpm{0.5f};
    volatile bool autoZeroAllowed{true};

    // ===================== CHẾ ĐỘ VỊ TRÍ (cánh tay gạt) =====================
    // Mọi góc ở TRỤC RA (sau hộp số), đơn vị độ. Vị trí đo lấy từ bộ đếm đa vòng SỐ NGUYÊN của encoder
    // (_totalCounts) nên không trôi; độ phân giải 360 / (16384 x 8) = 0.0027 độ.
    // Cấu trúc: quỹ đạo hình thang -> P vị trí (+ vận tốc tham chiếu) -> PI vận tốc -> vòng dòng.
    float posGearRatio{8.0f};
    float posDirSign{1.0f};              // +1: góc dương = chiều quay dương của rotor; -1: đảo
    float posKp{30.0f};                  // [1/s] (độ/s trên mỗi độ sai lệch)
    float posDeadband_deg{0.3f};         // vùng chết khi đã tới đích: vào giữ < 1x, thoát > 2x (chống săn)
    float posJoverKt{0.0f};              // feedforward gia tốc [A.s^2/rad rotor] (0 = tắt)

    // Đặt góc 0 tại vị trí hiện tại. Chỉ ghi cờ; ISR thực hiện ở vòng FOC kế tiếp (bộ đếm 64 bit chỉ ISR được ghi).
    void  requestPosZero() { _posZeroReq = true; }
    bool  isPosZeroPending() const { return _posZeroReq; }
    float getOutputAngleDeg() const { return _posMeasDeg; }   // góc đo [độ]
    float getPosRefDeg() const { return _posRef; }            // góc tham chiếu của quỹ đạo [độ]
    float getPosGoalDeg() const { return _posGoal; }
    float getPosVelRefDegS() const { return _posVel; }
    bool  isPosTrajDone() const { return _posTrajDone; }
    // Lập quỹ đạo mới tới goalDeg. Chỉ gọi trong ngữ cảnh ISR (bộ điều phối chạy trong ISR).
    //   fromMeasured = false: nối tiếp mượt từ tham chiếu hiện tại (đổi đích khi đang chạy).
    //   fromMeasured = true : bắt đầu lại từ vị trí ĐO, vận tốc tham chiếu = 0 (dừng tại chỗ), xóa khâu I. Dùng khi va chạm:
    //                         tham chiếu cũ đã chạy trước cánh tay, giữ nó thì khâu P vẫn tiếp tục ép vào vật cản.
    void  posMoveTo(float goalDeg, float speedDegS, float accelDegS2, bool fromMeasured = false);

private:
    static float quickSin(float rad);
    static float quickCos(float rad);
    static float normalizeAngle(float rad);
    void updateVelocityEstimator(float dt_sec);
    void outputMinMaxPhaseVoltage(float ud, float uq, float s, float c);

    uint8_t _polePairs{21};
    float   _motorL{0.00018f};
    uint8_t _velLoopFreq_kHz{1};
    uint8_t _velDownsampler{0};
    float   _velDtAcc{0.0f};
    volatile bool _estResync{false};

    DRV8301Driver*         _driver{nullptr};
    AS5047P*               _sensor{nullptr};
    CurrentSensorInjected* _currentSensor{nullptr};
    LowpassFilter*         _lpfId{nullptr};
    LowpassFilter*         _lpfIq{nullptr};
    LowpassFilter*         _lpfVel{nullptr};
    KalmanFilter*          _kfVel{nullptr};

    bool _useLut{true};
    bool _enableFW{false};

    // Biến trạng thái FOC
    float _ia{0.0f}, _ib{0.0f}, _ic{0.0f};
    float _idRaw{0.0f}, _iqRaw{0.0f};
    float _idFilt{0.0f}, _iqFilt{0.0f};
    float _targetId{0.0f}, _targetIq{0.0f};
    float _ud{0.0f}, _uq{0.0f};

    // Đa vòng (số nguyên, chính xác tuyệt đối) cho vị trí MIT
    bool     _velFirstRun{true};
    uint16_t _prevRawCnt{0};
    int64_t  _totalCounts{0};
    float    _multiTurnRad{0.0f};

    // PLL vận tốc (đơn vị count, vị trí giữ trong [0, CPR) để float không mất độ phân giải)
    float _pllKp{600.0f};
    float _pllKi{90000.0f};
    float _pllPos{0.0f};       // [count]
    float _pllVel{0.0f};       // [count/s]
    float _ditherCounts{0.0f}; // [count]
    float _gatedPos{0.0f};     // [count] vị trí sau cổng chống rung
    bool  _pllUsedCal{false};  // nguồn vị trí của bộ ước lượng: góc đã bù LUT hay góc raw

    // Kalman (đơn vị count: góc [count], vận tốc [count/s], gia tốc nhiễu [count/s^2])
    VelocityEstimator _velEst{VelocityEstimator::PLL};
    float _kfK[3]{0.0f, 0.0f, 0.0f};
    float _kfB{0.0f};          // [count/s^2 per A] = (Kt/J) * CPR / (2*pi)
    float _kfDist{0.0f};
    float _kfDistMax{0.0f};
    float _kfIqAlpha{1.0f};    // hệ số mô hình trễ vòng dòng bậc 1
    float _kfIqModel{0.0f};    // iq "thật" theo mô hình
    float _iqCmdObs{0.0f};     // iq lệnh vòng dòng đang dùng (0 khi DISABLED/VOLTAGE)

    float _lambda{0.0f};       // từ thông cho feedforward back-EMF [Wb]
    LowpassFilter _lpfFF;      // LPF vận tốc riêng cho feedforward
    uint8_t _ffMode{0};
    float   _omegaFFFilt{0.0f};

    float _velRadS{0.0f};
    float _velRpm{0.0f};
    float _targetRpm{0.0f};
    float _rampedRpm{0.0f};

    // ----- Chế độ vị trí -----
    struct TrapPlan {                    // quỹ đạo hình thang giải tích (có vận tốc đầu) - tính một lần mỗi lần đổi đích
        float xi{0}, vi{0}, xf{0};       // vị trí đầu, vận tốc đầu, vị trí cuối
        float ar{0}, dr{0}, vr{0};       // gia tốc pha 1, gia tốc pha 3 (âm theo chiều chạy), vận tốc chạy đều
        float ta{0}, tv{0}, td{0}, tf{0};
        float ya{0};                     // vị trí cuối pha tăng tốc
    };
    void planTrapezoid(float xf, float xi, float vi, float vmax, float amax);
    void updatePositionLoop(float dt);

    volatile bool  _posZeroReq{false};
    int64_t        _posZeroCounts{0};
    volatile float _posMeasDeg{0.0f};
    float          _posRef{0.0f};        // [độ]
    float          _posVel{0.0f};        // [độ/s]
    float          _posAcc{0.0f};        // [độ/s^2]
    float          _posGoal{0.0f};
    volatile bool  _posTrajDone{true};
    bool           _posHolding{false};   // đang giữ trong vùng chết (có trễ)
    TrapPlan       _traj{};
    float          _trajT{0.0f};
};
