// FOCLib/SignalFilters/kalmanFilter.h
#pragma once
#include <cmath>

class KalmanFilter {
public:
    KalmanFilter(float mea_e = 1.0f, float est_e = 1.0f, float q = 0.01f);

    float updateEstimate(float mea);
    void  setMeasurementError(float mea_e);
    void  setEstimateError(float est_e);
    void  setProcessNoise(float q);
    float getKalmanGain();
    void  reset(float val = 0.0f) { _last_estimate = val; _current_estimate = val; }

private:
    float _err_measure{1.0f};
    float _err_estimate{1.0f};
    float _q{0.01f};
    float _current_estimate{0.0f};
    float _last_estimate{0.0f};
    float _kalman_gain{0.0f};
};
