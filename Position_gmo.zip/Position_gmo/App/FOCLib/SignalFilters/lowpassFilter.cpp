// FOCLib/SignalFilters/lowpassFilter.cpp
#include "lowpassFilter.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

LowpassFilter::LowpassFilter(f32 cutOffFreq_Hz, f32 samplingFreq_Hz)
{
    setCutOffFreq(cutOffFreq_Hz, samplingFreq_Hz);
}

/*
===================================================================================================
    METHODS
===================================================================================================
*/

void LowpassFilter::setIntensity(f32 intensity)
{
    intensity = __constrain(intensity, 0.0f, 1.0f);
    _alpha = intensity;
    _alphaComplement = 1.0f - _alpha;
}

void LowpassFilter::setCutOffFreq(f32 cutOffFreq_Hz, f32 samplingFreq_Hz)
{
    if (cutOffFreq_Hz <= 0.0f || samplingFreq_Hz <= 0.0f) {
        _alpha = 0.0f;
    } else {
        f32 rc = 1.0f / (2.0f * M_PI * cutOffFreq_Hz);
        f32 dt = 1.0f / samplingFreq_Hz;
        _alpha = rc / (rc + dt);
    }
    _alpha = __constrain(_alpha, 0.0f, 1.0f);
    _alphaComplement = 1.0f - _alpha;
}

f32 LowpassFilter::getIntensity()
{ return _alpha; }

f32 LowpassFilter::update(f32 rawSignal)
{
    _filtered = _alpha * _filtered + _alphaComplement * (rawSignal);
    return _filtered;
}
