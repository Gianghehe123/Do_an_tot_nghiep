// FOCLib/SignalFilters/lowpassFilter.h
#pragma once
#include <cstdint>
#include <cmath>

using f32 = float;
using u08 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;

#ifndef __constrain
#define __constrain(val, min, max) (((val) <= (min)) ? (min) : (((val) >= (max)) ? (max) : (val)))
#endif

class LowpassFilter {
public:
    LowpassFilter() = default;
    LowpassFilter(f32 cutOffFreq_Hz, f32 samplingFreq_Hz);

    void setIntensity(f32 intensity);
    void setCutOffFreq(f32 cutOffFreq_Hz, f32 samplingFreq_Hz);
    f32  getIntensity();
    f32  update(f32 rawSignal);
    void reset(f32 val = 0.0f) { _filtered = val; }
    f32  getOutput() const { return _filtered; }

private:
    f32 _alpha{0.0f};
    f32 _alphaComplement{1.0f};
    f32 _filtered{0.0f};
};
