// FOCLib/MotorDrivers/drv8301Driver.h
#pragma once
#include "stm32f4xx_hal.h"
#include <algorithm>
#include <cstdint>

class DRV8301Driver {
public:
    DRV8301Driver(TIM_HandleTypeDef* htim, GPIO_TypeDef* enPort, uint16_t enPin,
                  float vBus_V, float minDuty = 0.02f, float maxDuty = 0.98f)
        : _htim(htim), _enPort(enPort), _enPin(enPin),
          _vBus(vBus_V), _minDuty(minDuty), _maxDuty(maxDuty) {}

    // Tùy chọn: nối SPI để cấu hình gain bộ khuếch đại dòng (CSA). Gọi TRƯỚC init().
    void attachSpi(SPI_HandleTypeDef* hspi, GPIO_TypeDef* csPort, uint16_t csPin)
    {
        _hspi   = hspi;
        _csPort = csPort;
        _csPin  = csPin;
        HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET);
    }

    // 10 / 20 / 40 / 80 V/V
    void setRequestedGain(uint8_t gain_VperV) { _requestedGain = sanitizeGain(gain_VperV); }

    // Gain ĐANG CÓ HIỆU LỰC theo lần đọc lại gần nhất. Không có SPI / không đọc được -> 10 (mặc định).
    uint8_t getActiveGain() const { return _activeGain; }
    uint8_t getRequestedGain() const { return _requestedGain; }
    bool    hasSpi() const { return _hspi != nullptr; }

    void init()
        {
            uint32_t arr = __HAL_TIM_GET_AUTORELOAD(_htim);
            // Đặt CCR4 trước đỉnh ARR 45 ticks (~268 ns @ 168 MHz) để xung qua đỉnh rộng ~535 ns (~11 chu kỳ ADCCLK),
            // chống mất trigger ADC tuyệt đối mà vẫn lấy mẫu đúng tâm dẫn của Low-side Shunt.
            uint32_t ccr4 = (arr > 60u) ? (arr - 45u) : ((arr > 2u) ? (arr - 1u) : arr);
            __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_4, ccr4);

            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_1);
            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_2);
            HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Start(_htim, TIM_CHANNEL_3);

            setDutyCycle(0.5f, 0.5f, 0.5f);
            resetGateBlocking();
        }

    // Chỉ gọi ở setup() hoặc loop() (có HAL_Delay). Kéo EN_GATE > 20 us = full reset:
    // MỌI thanh ghi SPI về mặc định (gain 10 V/V), nên ghi lại cấu hình ngay sau đó.
    void resetGateBlocking()
    {
        setDutyCycle(0.5f, 0.5f, 0.5f);
        HAL_GPIO_WritePin(_enPort, _enPin, GPIO_PIN_RESET);
        _activeGain = 10;
        HAL_Delay(50);
        HAL_GPIO_WritePin(_enPort, _enPin, GPIO_PIN_SET);
        HAL_Delay(800);   // datasheet: SPI sẵn sàng sau tối đa 10 ms; CSA cần thời gian ổn định
        applyConfig();
    }

    // Ghi Control Register 1/2 rồi đọc lại. Chỉ coi gain yêu cầu là có hiệu lực khi đọc lại KHỚP
    // CHÍNH XÁC giá trị vừa ghi (2 lần). Mọi trường hợp khác giữ 10 V/V: nếu chip thực ra đang ở gain
    // cao hơn thì dòng đo được LỚN hơn thực -> vòng dòng cấp THIẾU (an toàn), không bao giờ cấp thừa.
    bool applyConfig()
    {
        _configOk   = false;
        _activeGain = 10;
        if (_hspi == nullptr) return false;

        const uint16_t cr1 = CR1_DEFAULT;
        const uint16_t cr2 = static_cast<uint16_t>(gainBits(_requestedGain) << 2);

        for (int attempt = 0; attempt < 3; ++attempt) {
            uint16_t dummy;
            readReg(REG_STATUS1, dummy);   // frame đầu sau khi bật EN_GATE đôi khi bị bỏ qua
            writeReg(REG_CTRL1, cr1);
            writeReg(REG_CTRL2, cr2);

            uint16_t a1 = 0xFFFF, a2 = 0xFFFF, b2 = 0xFFFF;
            const bool ok = readReg(REG_CTRL1, a1) && readReg(REG_CTRL2, a2) && readReg(REG_CTRL2, b2);
            if (ok && a1 == cr1 && a2 == cr2 && b2 == cr2) {
                _activeGain = _requestedGain;
                _configOk   = true;
                return true;
            }
            HAL_Delay(2);
        }
        return false;
    }

    // Kiểm tra định kỳ (không đổi trạng thái): +1 = khớp, 0 = lỗi đọc SPI, -1 = đọc được nhưng SAI
    // (thanh ghi đã bị reset do sụt áp PVDD/nhiễu -> gain thực khác gain đang giả định).
    int8_t verifyConfig()
    {
        if (_hspi == nullptr) return 1;
        const uint16_t expect = static_cast<uint16_t>(gainBits(_activeGain) << 2);
        uint16_t rb = 0xFFFF;
        if (!readReg(REG_CTRL2, rb)) return 0;
        return (rb == expect) ? 1 : -1;
    }

    // Hạ về giả định an toàn (10 V/V) sau khi phát hiện sai cấu hình.
    void markUnverified() { _activeGain = 10; _configOk = false; }

    bool isConfigOk() const { return _configOk; }

    bool readStatus(uint16_t& status1, uint16_t& status2)
    {
        if (_hspi == nullptr) return false;
        return readReg(REG_STATUS1, status1) && readReg(REG_STATUS2, status2);
    }

    // Nhận điện áp pha [0 .. Vbus] sau bước dịch tâm Min-Max
    void setPhaseVoltage(float ua, float ub, float uc)
    {
        float invVbus = 1.0f / _vBus;
        setDutyCycle(ua * invVbus, ub * invVbus, uc * invVbus);
    }

    void setDutyCycle(float du, float dv, float dw)
    {
        du = std::max(_minDuty, std::min(du, _maxDuty));
        dv = std::max(_minDuty, std::min(dv, _maxDuty));
        dw = std::max(_minDuty, std::min(dw, _maxDuty));

        uint32_t arr = __HAL_TIM_GET_AUTORELOAD(_htim);
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_1, static_cast<uint32_t>(du * arr));
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_2, static_cast<uint32_t>(dv * arr));
        __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_3, static_cast<uint32_t>(dw * arr));
    }

    // Tắt/bật toàn bộ 6 MOSFET (bit MOE của TIM1). Khi tắt, cầu ở trạng thái Hi-Z: không dòng nào
    // chạy qua shunt kể cả khi rotor đang quay (dưới ngưỡng back-EMF > Vbus) -> đo offset sạch.
    // ADC vẫn được kích bởi CC4 vì bộ so sánh bên trong timer vẫn chạy.
    // Yêu cầu: idle state các kênh = Reset (mặc định CubeMX) để INH/INL đều ở mức thấp.
    void setOutputsEnabled(bool en)
    {
        if (en) _htim->Instance->BDTR |= TIM_BDTR_MOE;
        else    _htim->Instance->BDTR &= ~TIM_BDTR_MOE;
    }

    float getVBus() const { return _vBus; }

private:
    static constexpr uint8_t  REG_STATUS1 = 0x00;
    static constexpr uint8_t  REG_STATUS2 = 0x01;
    static constexpr uint8_t  REG_CTRL1   = 0x02;
    static constexpr uint8_t  REG_CTRL2   = 0x03;
    // CR1 = mặc định: gate 1.7 A, 6-PWM, OCP current-limit, OC_ADJ 0.060 V (giữ nguyên hành vi cũ)
    static constexpr uint16_t CR1_DEFAULT = 0x000;

    static uint8_t sanitizeGain(uint8_t g)
    {
        if (g >= 80) return 80;
        if (g >= 40) return 40;
        if (g >= 20) return 20;
        return 10;
    }
    static uint16_t gainBits(uint8_t g)
    {
        switch (sanitizeGain(g)) {
            case 80: return 3;
            case 40: return 2;
            case 20: return 1;
            default: return 0;
        }
    }
    static void shortDelay() { for (volatile int i = 0; i < 60; ++i) {} }   // ~1-2 us

    uint16_t xfer(uint16_t tx)
    {
        uint16_t rx = 0xFFFF;
        HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_RESET);
        shortDelay();
        if (HAL_SPI_TransmitReceive(_hspi, reinterpret_cast<uint8_t*>(&tx),
                                    reinterpret_cast<uint8_t*>(&rx), 1, 2) != HAL_OK) {
            rx = 0xFFFF;
        }
        HAL_GPIO_WritePin(_csPort, _csPin, GPIO_PIN_SET);
        shortDelay();
        return rx;
    }

    // Frame: bit15 = R/W (1 = đọc), bit14..11 = địa chỉ, bit10..0 = dữ liệu
    void writeReg(uint8_t addr, uint16_t data)
    {
        xfer(static_cast<uint16_t>(((addr & 0x0F) << 11) | (data & 0x07FF)));
    }

    // Phản hồi của lệnh đọc nằm ở frame KẾ TIẾP. Bit15 của frame trả về = frame fault.
    // Không dựa vào trường địa chỉ; việc xác thực thật sự là so khớp với giá trị đã ghi.
    bool readReg(uint8_t addr, uint16_t& data)
    {
        const uint16_t cmd = static_cast<uint16_t>(0x8000 | ((addr & 0x0F) << 11));
        xfer(cmd);
        const uint16_t rx = xfer(cmd);
        if (rx == 0xFFFF || (rx & 0x8000) != 0) return false;   // MISO treo cao / frame fault
        data = rx & 0x07FF;
        return true;
    }

    TIM_HandleTypeDef* _htim;
    GPIO_TypeDef*      _enPort;
    uint16_t           _enPin;
    float              _vBus;
    float              _minDuty;
    float              _maxDuty;

    SPI_HandleTypeDef* _hspi{nullptr};
    GPIO_TypeDef*      _csPort{nullptr};
    uint16_t           _csPin{0};
    uint8_t            _requestedGain{10};
    volatile uint8_t   _activeGain{10};
    volatile bool      _configOk{false};
};
