// App/FOCLib/CurrentSensors/currentSensorInjected.h
#pragma once
#include "stm32f4xx_hal.h"
#include <cstdint>

enum class PhaseExclusion : uint8_t {
    NONE = 0,
    EXCLUDE_PHASE_A,
    EXCLUDE_PHASE_B,
    EXCLUDE_PHASE_C
};

class CurrentSensorInjected {
public:
    CurrentSensorInjected(ADC_HandleTypeDef* hadc_master_b,
                          ADC_HandleTypeDef* hadc_slave_c,
                          float currentScale_A_per_LSB,
                          uint8_t oversampleRatio = 4,
                          PhaseExclusion exclusion = PhaseExclusion::EXCLUDE_PHASE_A);

    void init();

    // Hiệu chỉnh offset chạy trong ISR (mỗi mẫu ADC 20 kHz). Chỉ đúng khi KHÔNG có dòng qua shunt.
    void calibrate(uint16_t numSamples = 1024);
    bool isCalibrationComplete() const { return _isCalibComplete; }
    // Bản chặn (blocking) có timeout, dùng ở setup()/loop(). Trả về false nếu quá thời gian.
    bool calibrateBlocking(uint16_t numSamples, uint32_t timeout_ms);

    // Đổi A/LSB khi gain bộ khuếch đại DRV8301 thay đổi (offset tính theo LSB nên không đổi).
    void  setScale(float currentScale_A_per_LSB) { _scale = currentScale_A_per_LSB; }
    float getScale() const { return _scale; }

    void update() {}

    // Trả về true khi đã gom đủ số mẫu oversampling và tính xong Ia, Ib, Ic
    bool onConversionComplete_ISR();

    // Gọi trong ISR khi chắc chắn không có dòng (Motor tự kiểm tra DISABLED + rotor đứng yên).
    // Mẫu lệch khỏi offset quá gateLsb bị LOẠI (không học): log 27/10 lúc 36.2 s bộ khuếch đại dòng cho ra rác
    // ~±30 A trong 0.3 s khi motor đứng yên, auto-zero học theo rồi mất ~2 s mới tự sửa lại.
    void updateAutoZeroWhenIdle(float alpha = 0.0005f);
    void setAutoZeroGate(float gateLsb) { _autoZeroGateLsb = gateLsb; }
    // Lệch liên tục quá gate trong reacquireCalls lần gọi (~0.5 s @5 kHz) = mức 0 đã DỊCH THẬT (không phải gai
    // thoáng qua) -> lấy lại offset theo mẫu hiện tại. Log 29/10: offset lúc khởi động sai -117/+275 LSB và bộ chặn
    // của v5 khóa chặt giá trị sai đó suốt 14 s (Iq đo = +30 A khi motor đứng yên).
    void setAutoZeroReacquire(uint32_t reacquireCalls) { _reacquireCalls = reacquireCalls; }
    uint32_t getReacquireCount() const { return _reacquireCount; }
    // Offset có nằm gần giữa thang ADC không (đầu ra bộ khuếch đại dòng khi 0 A = VREF/2 ~ 2048)
    bool offsetsPlausible(float tolLsb) const {
        const float dB = _offsetB - 2048.0f, dC = _offsetC - 2048.0f;
        return dB < tolLsb && dB > -tolLsb && dC < tolLsb && dC > -tolLsb;
    }
    void invalidateOffset() { _hasValidOffset = false; }
    uint32_t getAutoZeroRejects() const { return _autoZeroRejects; }
    bool hasValidOffset() const { return _hasValidOffset; }

    ADC_TypeDef* getMasterADCInstance() const { return _hadcMaster->Instance; }

    float getIa() const { return _ia; }
    float getIb() const { return _ib; }
    float getIc() const { return _ic; }
    float getOffsetB() const { return _offsetB; }
    float getOffsetC() const { return _offsetC; }

private:
    ADC_HandleTypeDef* _hadcB{nullptr};
    ADC_HandleTypeDef* _hadcC{nullptr};
    ADC_HandleTypeDef* _hadcMaster{nullptr};

    volatile float _scale{0.16117f};
    uint8_t        _oversampleRatio{4};
    uint8_t        _prescaler{0};
    PhaseExclusion _exclusion{PhaseExclusion::EXCLUDE_PHASE_A};

    uint32_t _sumB{0};
    uint32_t _sumC{0};
    float    _sampleB{2048.0f};
    float    _sampleC{2048.0f};

    float _offsetB{2048.0f};
    float _offsetC{2048.0f};

    volatile float _ia{0.0f};
    volatile float _ib{0.0f};
    volatile float _ic{0.0f};

    float             _autoZeroGateLsb{40.0f};
    uint32_t          _reacquireCalls{2500};
    uint32_t          _rejectStreak{0};
    volatile uint32_t _reacquireCount{0};
    volatile uint32_t _autoZeroRejects{0};
    volatile bool     _hasValidOffset{false};
    volatile bool     _isCalibrating{false};
    volatile bool     _isCalibComplete{false};
    uint16_t          _calibTargetSamples{1024};
    volatile uint16_t _calibCount{0};
    uint32_t          _calibAccB{0};
    uint32_t          _calibAccC{0};
};
