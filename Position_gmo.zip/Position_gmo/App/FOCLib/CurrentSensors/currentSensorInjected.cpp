// App/FOCLib/CurrentSensors/currentSensorInjected.cpp
#pragma GCC optimize ("O2")
#include "currentSensorInjected.h"

CurrentSensorInjected::CurrentSensorInjected(ADC_HandleTypeDef* hadc_master_b,
                                             ADC_HandleTypeDef* hadc_slave_c,
                                             float currentScale_A_per_LSB,
                                             uint8_t oversampleRatio,
                                             PhaseExclusion exclusion)
    : _hadcB(hadc_master_b),
      _hadcC(hadc_slave_c),
      _hadcMaster(hadc_master_b),
      _scale(currentScale_A_per_LSB),
      _oversampleRatio(oversampleRatio > 0 ? oversampleRatio : 1),
      _exclusion(exclusion) {}

void CurrentSensorInjected::init()
{
    // Xóa sạch các cờ tồn đọng trước khi bật Dual Injected
    __HAL_ADC_CLEAR_FLAG(_hadcC, ADC_FLAG_JSTRT | ADC_FLAG_JEOC | ADC_FLAG_OVR);
    __HAL_ADC_CLEAR_FLAG(_hadcB, ADC_FLAG_JSTRT | ADC_FLAG_JEOC | ADC_FLAG_OVR);
    HAL_ADCEx_InjectedStart(_hadcC);
    HAL_ADCEx_InjectedStart_IT(_hadcB);
}

void CurrentSensorInjected::calibrate(uint16_t numSamples)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    _isCalibrating      = false;
    _calibTargetSamples = (numSamples > 0) ? numSamples : 1024;
    _calibAccB          = 0;
    _calibAccC          = 0;
    _calibCount         = 0;
    _isCalibComplete    = false;
    __DMB();
    _isCalibrating      = true;
    __set_PRIMASK(primask);
}

bool CurrentSensorInjected::calibrateBlocking(uint16_t numSamples, uint32_t timeout_ms)
{
    calibrate(numSamples);
    const uint32_t t0 = HAL_GetTick();
    while (!_isCalibComplete) {
        if (HAL_GetTick() - t0 > timeout_ms) {
            _isCalibrating = false;
            return false;
        }
    }
    return true;
}

bool CurrentSensorInjected::onConversionComplete_ISR()
{
    uint16_t rawB = static_cast<uint16_t>(_hadcB->Instance->JDR1);
    uint16_t rawC = static_cast<uint16_t>(_hadcC->Instance->JDR1);

    // Xóa cờ JEOC/JSTRT ngay sau khi đọc JDR1 để không bao giờ nuốt mất trigger của chu kỳ kế tiếp
    _hadcB->Instance->SR = ~(ADC_FLAG_JSTRT | ADC_FLAG_JEOC);
    _hadcC->Instance->SR = ~(ADC_FLAG_JSTRT | ADC_FLAG_JEOC);

    // 1. Hiệu chỉnh offset khi không có dòng qua shunt
    if (_isCalibrating) {
        _calibAccB += rawB;
        _calibAccC += rawC;
        _calibCount = _calibCount + 1;

        if (_calibCount >= _calibTargetSamples) {
            float invN = 1.0f / static_cast<float>(_calibTargetSamples);
            _offsetB = static_cast<float>(_calibAccB) * invN;
            _offsetC = static_cast<float>(_calibAccC) * invN;
            _sumB = 0;
            _sumC = 0;
            _prescaler = 0;
            _isCalibrating   = false;
            _isCalibComplete = true;
            _hasValidOffset  = true;
        }
        return false;
    }

    // 2. Cộng dồn 4 mẫu (Oversampling)
    _sumB += rawB;
    _sumC += rawC;
    _prescaler++;

    if (_prescaler < _oversampleRatio) {
        return false;
    }

    float invOvs = 1.0f / static_cast<float>(_oversampleRatio);
    _sampleB   = static_cast<float>(_sumB) * invOvs;
    _sampleC   = static_cast<float>(_sumC) * invOvs;
    _prescaler = 0;
    _sumB      = 0;
    _sumC      = 0;

    // 3. Quy đổi sang Ampe
    const float scale = _scale;
    _ib = (_sampleB - _offsetB) * scale;
    _ic = (_sampleC - _offsetC) * scale;
    _ia = -(_ib + _ic);

    return true;
}

void CurrentSensorInjected::updateAutoZeroWhenIdle(float alpha)
{
    if (_isCalibrating) return;
    const float eB = _sampleB - _offsetB;
    const float eC = _sampleC - _offsetC;

    if (_hasValidOffset && (eB > _autoZeroGateLsb || eB < -_autoZeroGateLsb ||
                            eC > _autoZeroGateLsb || eC < -_autoZeroGateLsb)) {
        if (++_rejectStreak >= _reacquireCalls) {
            _offsetB = _sampleB;
            _offsetC = _sampleC;
            _rejectStreak = 0;
            _reacquireCount = _reacquireCount + 1;
        } else {
            _autoZeroRejects = _autoZeroRejects + 1;
        }
        return;
    }
    _rejectStreak = 0;
    _offsetB += alpha * eB;
    _offsetC += alpha * eC;
}
