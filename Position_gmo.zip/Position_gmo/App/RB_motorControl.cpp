// App/RB_motorControl.cpp
#include "device.h"
#include <cmath>
#pragma GCC optimize ("O2")

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* ============ EXTERNAL HAL HANDLES ============ */
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
#if (__DRV_SPI_CONFIG_ENABLE)
extern SPI_HandleTypeDef __DRV_SPI_HANDLE;
#endif

/* ============ COMPONENTS ============ */
AS5047P encoder(&hspi1, __ENC_SPI_PORT, __ENC_SPI_CS_PIN, __MOT_POLE_PAIRS);

DRV8301Driver driver(&htim1, __DRV_EN_GATE_PORT, __DRV_EN_GATE_PIN,
                     __V_BUS_VOLTS, __PWM_MIN_DUTY_RATIO, __PWM_MAX_DUTY_RATIO);

CurrentSensorInjected currentSensor(&hadc1, &hadc2,
                                    __ADC_CURRENT_SCALE_A_LSB,
                                    __ADC_OVERSAMPLE_COUNT,
                                    PhaseExclusion::EXCLUDE_PHASE_A);

LowpassFilter LPF_Id(__LPF_CURRENT_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Iq(__LPF_CURRENT_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Id_Telem(__LPF_TELEM_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);
LowpassFilter LPF_Iq_Telem(__LPF_TELEM_CUTOFF_HZ, __CTRL_LOOP_FREQ_KHZ * 1000.0f);

Motor motor(__MOT_POLE_PAIRS, __MOT_INDUCTANCE_H, __VEL_LOOP_FREQ_KHZ);

static float s_gmoIntegral    = 0.0f;
static float s_p0             = 0.0f;
static float s_gmoDtAcc       = 0.0f;   // thời gian thực tích lũy giữa 2 lần chạy GMO

/* ============ ĐO THỜI GIAN THỰC (bộ đếm chu kỳ DWT) ============ */
// Mọi đại lượng theo thời gian (vận tốc, vòng tốc độ, GMO) dùng dt ĐO ĐƯỢC giữa 2 lần chạy FOC, không dùng
// hằng 1/5000. Log 23/10 và 26/10: tốc độ tính từ encoder / RPM firmware báo = 0.800 ở mọi tốc độ -> FOC thực
// chạy 4 kHz (mất 1 mẫu ADC mỗi vòng do ISR quá giờ) trong khi firmware tính với dt của 5 kHz.
static float    s_cycToSec     = 1.0f / 168000000.0f;
static float    s_dtNominal    = 1.0f / (static_cast<float>(__CTRL_LOOP_FREQ_KHZ) * 1000.0f);
static uint32_t s_pwmPeriodCyc = 8400;   // tính lại từ thanh ghi TIM1 lúc khởi động
static uint32_t s_lastFocCyc   = 0;
static bool     s_focPrimed    = false;
// Thống kê cửa sổ (ISR ghi, loop() đọc + xóa)
static volatile uint32_t s_tFocN = 0, s_tFocSumCyc = 0, s_tFocMaxCyc = 0, s_tExecMaxCyc = 0, s_tLost = 0, s_tGaps = 0;

#if (__DEBUG_TIMING_GPIO)
#define DBG_ISR_HIGH()   (__DEBUG_TIMING_PORT->BSRR = (uint32_t)__DEBUG_ISR_PIN)
#define DBG_ISR_LOW()    (__DEBUG_TIMING_PORT->BSRR = (uint32_t)__DEBUG_ISR_PIN << 16)
#define DBG_FOC_TOGGLE() (__DEBUG_TIMING_PORT->ODR ^= (uint32_t)__DEBUG_FOC_PIN)
#else
#define DBG_ISR_HIGH()   ((void)0)
#define DBG_ISR_LOW()    ((void)0)
#define DBG_FOC_TOGGLE() ((void)0)
#endif

// false trong lúc reset tầng công suất: EN_GATE thấp -> bộ khuếch đại dòng tắt -> ADC đọc RÁC (~660 A).
// Bản trước vẫn cộng các mẫu rác này vào trung bình telemetry -> gai +-30 A trên GUI sau mỗi lần reset.
static volatile bool s_currentValid = true;
static uint32_t      s_zeroBadCalls = 0;     // số vòng FOC liên tiếp thấy dòng lớn lúc DISABLED + đứng yên

// Bộ cộng dồn telemetry: cộng trong ISR 5 kHz, loop() đọc + xóa trong vùng tắt ngắt rất ngắn.
static volatile float    s_telIdSum  = 0.0f;
static volatile float    s_telIqSum  = 0.0f;
static volatile uint32_t s_telIN     = 0;
static volatile float    s_telRpmSum = 0.0f;
static volatile uint32_t s_telVN     = 0;

static constexpr int SAMPLES_PER_POLE = 60;
static constexpr int TOTAL_SAMPLES    = __MOT_POLE_PAIRS * SAMPLES_PER_POLE;
static float s_fwdErr[TOTAL_SAMPLES];
static float s_bwdErr[TOTAL_SAMPLES];
static float s_avgErr[TOTAL_SAMPLES];
static float s_lut[AS5047P::LUT_SIZE];

/* ============ HELPERS ============ */
static void applyCurrentScaleFromDriver()
{
    // Scale LUÔN theo gain đã đọc lại xác nhận (không xác nhận được -> 10 V/V)
    currentSensor.setScale(__ADC_CURRENT_SCALE_AT_GAIN(driver.getActiveGain()));
    dev.drvConfigOk = driver.isConfigOk();
}

// Hiệu chỉnh offset dòng: PWM vẫn chạy 50% duty (MOE giữ nguyên) và CHỈ khi rotor đứng yên.
// Bản trước tắt MOE (cầu Hi-Z) để đo được cả khi rotor đang trôi, nhưng trên board thật cách đó KHÔNG hoạt động:
// mọi lần reset trong log 26/10 và 27/10 dài 1.40 s thay vì 0.90 s, phần thêm đúng bằng timeout 500 ms
// -> hiệu chỉnh không bao giờ xong (rất có thể trigger ADC từ TIM1_CC4 ngừng khi MOE = 0).
// 50% duty cả 3 pha = chập cuộn dây: rotor đứng yên thì không có dòng; đang quay thì có dòng hãm -> phải chờ dừng.
static bool calibrateCurrentOffsets()
{
    motor.autoZeroAllowed = false;
    driver.setDutyCycle(0.5f, 0.5f, 0.5f);
    const uint32_t t0 = HAL_GetTick();
    while (std::abs(motor.getVelocityRPM()) > 2.0f && (HAL_GetTick() - t0) < 300u) {}   // 50% duty tự hãm rotor
    HAL_Delay(5);
    bool ok = false;
    // Offset phải gần giữa thang (VREF/2). Sai lệch cho phép nới theo gain vì offset đầu vào bộ khuếch đại nhân gain.
    const float tol = __ADC_OFFSET_PLAUSIBLE_LSB + 4.0f * (static_cast<float>(driver.getActiveGain()) - 10.0f);
    for (int attempt = 0; attempt < 2 && !ok; ++attempt) {
        if (std::abs(motor.getVelocityRPM()) > 2.0f) break;
        if (attempt > 0) HAL_Delay(50);
        ok = currentSensor.calibrateBlocking(__ADC_CALIB_SAMPLES, 300) && currentSensor.offsetsPlausible(tol);
    }
    if (!ok) currentSensor.invalidateOffset();   // tắt bộ chặn để auto-zero được kéo offset về đúng
    dev.offsetCalOk = ok;
    motor.autoZeroAllowed = true;
    return ok;
}

static float wrapTwoPi(float a)
{
    a = std::fmod(a, 2.0f * static_cast<float>(M_PI));
    if (a < 0.0f) a += 2.0f * static_cast<float>(M_PI);
    return a;
}

// Nội suy vòng tròn trên mảng sai số đã làm mượt (chỉ số theo góc tham chiếu mechRef)
static float sampleSmoothedErr(float refAngle)
{
    const float a   = wrapTwoPi(refAngle);
    const float pos = a * (static_cast<float>(TOTAL_SAMPLES) / (2.0f * static_cast<float>(M_PI)));
    int   i0 = static_cast<int>(pos);
    float fr = pos - static_cast<float>(i0);
    if (i0 >= TOTAL_SAMPLES) { i0 = 0; fr = 0.0f; }
    const int i1 = (i0 + 1) % TOTAL_SAMPLES;
    return s_fwdErr[i0] + fr * (s_fwdErr[i1] - s_fwdErr[i0]);
}

// Thêm vào App/RB_motorControl.cpp (phía trên RB_initMotor):

typedef union {
    float    asFloat;
    uint32_t asWord;
} FourBytes;

struct FlashCalibBlock {
    uint32_t magic;
    float    zeroOffset;
    float    lut[AS5047P::LUT_SIZE];
    uint32_t checksum;
};

static uint32_t calcCalibChecksum(float zeroOffset, const float* lut)
{
    FourBytes fb;
    fb.asFloat = zeroOffset;
    uint32_t hash = 2166136261UL ^ fb.asWord;
    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) {
        fb.asFloat = lut[i];
        hash = (hash ^ fb.asWord) * 16777619UL;
    }
    return hash;
}

bool RB_loadParamFromFlash()
{
    const FlashCalibBlock* blk = reinterpret_cast<const FlashCalibBlock*>(__PARAM_FLASH_ADDR);
    if (blk->magic != __PARAM_FLASH_MAGIC) return false;
    if (!std::isfinite(blk->zeroOffset)) return false;

    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) {
        if (!std::isfinite(blk->lut[i]) || std::abs(blk->lut[i]) > 0.5f) return false;
    }
    if (blk->checksum != calcCalibChecksum(blk->zeroOffset, blk->lut)) return false;

    for (int i = 0; i < AS5047P::LUT_SIZE; ++i) s_lut[i] = blk->lut[i];
    encoder.setLUT(s_lut, blk->zeroOffset);
    motor.setUseLUT(true);
    return true;
}

bool RB_saveParamToFlash(float zeroOffset, const float* lut)
{
    // Mục 11 .MD: Dừng ngắt điều khiển và đưa PWM về 50% trước khi xóa/ghi Flash
    const bool wasEnabled = dev.controlLoopEnabled;
    RB_stopControlClock();

    HAL_FLASH_Unlock();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    FLASH_EraseInitTypeDef eraseInit{};
    uint32_t sectorError = 0;
    eraseInit.TypeErase    = FLASH_TYPEERASE_SECTORS;
    eraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;
    eraseInit.Sector       = __PARAM_FLASH_SECTOR;
    eraseInit.NbSectors    = 1;

    if (HAL_FLASHEx_Erase(&eraseInit, &sectorError) != HAL_OK) {
        HAL_FLASH_Lock();
        if (wasEnabled) RB_startControlClock();
        return false;
    }

    uint32_t addr = __PARAM_FLASH_ADDR;
    bool ok = (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, __PARAM_FLASH_MAGIC) == HAL_OK);
    addr += 4;

    FourBytes fb;
    fb.asFloat = zeroOffset;
    ok = ok && (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, fb.asWord) == HAL_OK);
    addr += 4;

    for (int i = 0; i < AS5047P::LUT_SIZE && ok; ++i) {
        fb.asFloat = lut[i];
        ok = (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, fb.asWord) == HAL_OK);
        addr += 4;
    }

    const uint32_t crc = calcCalibChecksum(zeroOffset, lut);
    ok = ok && (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, crc) == HAL_OK);

    HAL_FLASH_Lock();
    if (wasEnabled) RB_startControlClock();
    return ok;
}

void RB_recoverFromCollision()
{
    // Phục hồi sau va chạm GMO: KHÔNG kéo EN_GATE xuống thấp để giữ nguyên điểm 0 đã ổn định nhiệt của DRV8301!
    motor.setControlType(ControlType::DISABLED);
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    LPF_Id.reset(0.0f);
    LPF_Iq.reset(0.0f);
    LPF_Id_Telem.reset(0.0f);
    LPF_Iq_Telem.reset(0.0f);
    dev.idTelemetry = 0.0f;
    dev.iqTelemetry = 0.0f;
    s_telIdSum = 0.0f; s_telIqSum = 0.0f; s_telIN = 0;
    s_telRpmSum = 0.0f; s_telVN = 0;
    s_gmoIntegral = 0.0f;
    dev.tauExtEst_Nm = 0.0f;
    __set_PRIMASK(primask);
    motor.requestEstimatorResync();
}
/* ============ FUNCTIONS ============ */
void RB_initMotor()
{
    dev.motor         = &motor;
    dev.encoder       = &encoder;
    dev.currentSensor = &currentSensor;
    dev.driver        = &driver;
    motor.torqueSpeedLimit_RPM = __TORQUE_MAX_SPEED_LIMIT_RPM;
    motor.torqueSpeedDamping   = __TORQUE_SPEED_DAMPING_A_RPM;

#if (__DRV_SPI_CONFIG_ENABLE)
    driver.attachSpi(&__DRV_SPI_HANDLE, __DRV_SPI_CS_PORT, __DRV_SPI_CS_PIN);
    driver.setRequestedGain(__DRV_CSA_GAIN);
#endif

    // 0. Bộ đếm chu kỳ CPU (DWT) để đo thời gian thực của vòng lặp
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;
    s_cycToSec = 1.0f / static_cast<float>(SystemCoreClock);

    // 1. Gate driver: PWM CH1..3 + CH1N..3N, duty 50%, reset EN_GATE, ghi cấu hình SPI (nếu có)
     driver.init();

     // 2. Encoder + đọc chẩn đoán nam châm (vòng điều khiển chưa chạy -> SPI1 đang rảnh)
     encoder.init();
     uint16_t diag = 0;
     if (encoder.readDiagAgc(diag)) dev.encDiag = diag;

     // 3. Khởi tạo ADC2 (Slave) + ADC1 (Master _IT) TRƯỚC khi bật xung trigger TIM1_CH4 (Chuẩn RM0090 & Mục 8.6)
     currentSensor.init();

     // 4. Bật TIM1_CH4 phát xung trigger cho ADC Injected
     HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

     // Tính chính xác chu kỳ PWM và tần số FOC thực tế từ thanh ghi TIM1
     float actualFocFreq_kHz = static_cast<float>(__CTRL_LOOP_FREQ_KHZ);
     {
         const uint32_t pclk2 = HAL_RCC_GetPCLK2Freq();
         const uint32_t ftim  = ((RCC->CFGR & RCC_CFGR_PPRE2) == 0u) ? pclk2 : 2u * pclk2;
         const uint32_t arr   = htim1.Instance->ARR;
         const uint32_t psc   = htim1.Instance->PSC;
         const bool center    = (htim1.Instance->CR1 & TIM_CR1_CMS) != 0u;
         const float ticks    = static_cast<float>((center ? 2u * arr : arr + 1u) * (psc + 1u));
         s_pwmPeriodCyc = static_cast<uint32_t>(ticks * static_cast<float>(SystemCoreClock) / static_cast<float>(ftim) + 0.5f);
         const uint32_t focPeriodCyc = s_pwmPeriodCyc * static_cast<uint32_t>(__ADC_OVERSAMPLE_COUNT);
         if (focPeriodCyc > 0u) {
             s_dtNominal       = static_cast<float>(focPeriodCyc) * s_cycToSec;
             actualFocFreq_kHz = 1.0f / (s_dtNominal * 1000.0f);
         }
     }

     // Đồng bộ tần số lấy mẫu thực tế cho toàn bộ các bộ lọc
     LPF_Id.setCutOffFreq(__LPF_CURRENT_CUTOFF_HZ, actualFocFreq_kHz * 1000.0f);
     LPF_Iq.setCutOffFreq(__LPF_CURRENT_CUTOFF_HZ, actualFocFreq_kHz * 1000.0f);
     LPF_Id_Telem.setCutOffFreq(__LPF_TELEM_CUTOFF_HZ, actualFocFreq_kHz * 1000.0f);
     LPF_Iq_Telem.setCutOffFreq(__LPF_TELEM_CUTOFF_HZ, actualFocFreq_kHz * 1000.0f);

     // 5. Scale theo gain thực tế + offset (PWM 50%, rotor đứng yên lúc khởi động)
     applyCurrentScaleFromDriver();
     calibrateCurrentOffsets();

     // 6. Nối các object phần cứng và bộ lọc vào lõi Motor
     motor.appendDriver(&driver);
     motor.appendSensor(&encoder);
     motor.appendCurrentSensor(&currentSensor);
     motor.appendCurrentFilters(&LPF_Id, &LPF_Iq);
     motor.appendVelocityFilter(nullptr, nullptr);
#if (__VEL_ESTIMATOR == 1)
motor.setVelocityKalman(__MOT_J_OVER_KT, __KF_ENC_SIGMA_COUNTS, __KF_Q_VEL, __KF_Q_DIST,
actualFocFreq_kHz, __FOC_CURRENT_BW_HZ,
__VEL_ENC_DITHER_COUNTS);
#else
motor.setVelocityPll(__VEL_PLL_BANDWIDTH_RAD_S, __VEL_ENC_DITHER_COUNTS);
#endif
motor.setBackEmfFeedforward(__MOT_FLUX_LINKAGE_WB, __FOC_BEMF_FF_LPF_HZ,
actualFocFreq_kHz, __FOC_BEMF_FF_MODE);
motor.init();

    // 7 & 8. Khởi động an toàn (DISABLED)
    motor.modulationType = ModulationType::FOC;
    motor.setControlType(ControlType::DISABLED);

    // 9. Nạp hệ số từ systemConfig.h
    motor.limitCurrent          = __CURRENT_LIMIT_AMPS;
    motor.limitVoltage          = __VOLTAGE_LIMIT_VOLTS;
    motor.velRampRate_RPM_per_s = __MOT_VEL_RAMP_RPM_PER_S;
    motor.velFeedforwardGain    = __MOT_VEL_FF_GAIN_A_PER_RPM;
    motor.velCoulombBand_RPM    = __MOT_VEL_COULOMB_BAND_RPM;
    motor.fricCoulomb_A         = __MOT_FRIC_COULOMB_A;
    motor.fricStatic_A          = __MOT_FRIC_STATIC_FF_A;
    motor.fricStribeck_RPM      = __MOT_FRIC_STRIBECK_RPM;
    motor.fricCompVelocity      = (__VEL_FRICTION_FF_ENABLE != 0);
    motor.fricCompTorque        = false;           // app.cpp bật khi nhận lệnh 0x03 (nếu cấu hình cho phép)
    currentSensor.setAutoZeroGate(__ADC_AUTOZERO_GATE_LSB);
    currentSensor.setAutoZeroReacquire(static_cast<uint32_t>(__ADC_AUTOZERO_REACQUIRE_S * __CTRL_LOOP_FREQ_KHZ * 1000.0f));
    motor.autoZeroAlpha         = __ADC_AUTOZERO_ALPHA;
    motor.autoZeroMaxRpm        = __ADC_AUTOZERO_MAX_RPM;

    motor.pid_Id.kp    = __MOT_CURRENT_PID_KP;
    motor.pid_Id.ki    = __MOT_CURRENT_PID_KI;
    motor.pid_Id.limit = __VOLTAGE_LIMIT_VOLTS;

    motor.pid_Iq.kp    = __MOT_CURRENT_PID_KP;
    motor.pid_Iq.ki    = __MOT_CURRENT_PID_KI;
    motor.pid_Iq.limit = __VOLTAGE_LIMIT_VOLTS;

    motor.pid_velocity.kp    = __MOT_VEL_PID_KP;
    motor.pid_velocity.ki    = __MOT_VEL_PID_KI;
    motor.pid_velocity.limit = __MOT_VEL_INTEGRAL_LIM_AMPS;

    // Chế độ vị trí (cánh tay gạt): dùng chung PI vận tốc ở trên
    motor.posGearRatio    = __MOT_GEAR_RATIO;
    motor.posDirSign      = __POS_DIR_SIGN;
    motor.posKp           = __POS_KP_1_S;
    motor.posDeadband_deg = __POS_DEADBAND_DEG;
    motor.posJoverKt      = __MOT_J_OVER_KT;

    dev.state = SystemState::IDLE;
}

void RB_startControlClock()
{
    dev.controlLoopEnabled = true;
}

void RB_stopControlClock()
{
    dev.controlLoopEnabled = false;
    driver.setDutyCycle(0.5f, 0.5f, 0.5f);
}

void RB_resetPowerStage()
{
    // Ép DISABLED trước: trong lúc EN_GATE thấp / cầu Hi-Z, PI dòng mà còn chạy sẽ bị bão hòa
    // tích phân và giật mạnh khi cầu bật lại.
    motor.setControlType(ControlType::DISABLED);
    s_currentValid        = false;      // dòng đo được từ giờ tới khi hiệu chỉnh xong là rác
    motor.autoZeroAllowed = false;      // EN_GATE thấp -> CSA tắt -> ADC đọc rác, không được học
    driver.resetGateBlocking();         // ~850 ms, ghi lại cấu hình SPI
    applyCurrentScaleFromDriver();
    calibrateCurrentOffsets();          // bật lại autoZeroAllowed bên trong

    // Xóa mọi trạng thái đã "nuốt" mẫu rác: bộ lọc dòng, bộ lọc telemetry, bộ cộng dồn.
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    LPF_Id.reset(0.0f);
    LPF_Iq.reset(0.0f);
    LPF_Id_Telem.reset(0.0f);
    LPF_Iq_Telem.reset(0.0f);
    dev.idTelemetry = 0.0f;
    dev.iqTelemetry = 0.0f;
    s_telIdSum = 0.0f; s_telIqSum = 0.0f; s_telIN = 0;
    s_telRpmSum = 0.0f; s_telVN = 0;
    s_zeroBadCalls        = 0;
    dev.currentZeroFault  = false;      // vừa hiệu chỉnh lại: bỏ kết luận cũ (tránh loop() đọc cờ cũ rồi khóa ERROR lại)
    s_currentValid = true;
    __set_PRIMASK(primask);
    motor.requestEstimatorResync();
}

bool RB_checkPowerStage()
{
#if (__DRV_SPI_CONFIG_ENABLE)
    static uint8_t s_commFail = 0;
    const int8_t r = driver.verifyConfig();
    if (r > 0) { s_commFail = 0; return true; }
    if (r == 0 && ++s_commFail < 2) return true;   // bỏ qua 1 lần lỗi đọc đơn lẻ
    // Sai cấu hình (hoặc lỗi đọc liên tiếp): dừng ngay, hạ scale về giả định an toàn.
    s_commFail = 0;
    motor.setControlType(ControlType::DISABLED);
    driver.markUnverified();
    applyCurrentScaleFromDriver();
    return false;
#else
    return true;
#endif
}

void RB_popCurrentTelemetry(float& id_A, float& iq_A)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    const float    sId = s_telIdSum;
    const float    sIq = s_telIqSum;
    const uint32_t n   = s_telIN;
    s_telIdSum = 0.0f;
    s_telIqSum = 0.0f;
    s_telIN    = 0;
    __set_PRIMASK(primask);

    if (n > 0) {
        const float inv = 1.0f / static_cast<float>(n);
        id_A = sId * inv;
        iq_A = sIq * inv;
    } else {
        id_A = motor.getId();
        iq_A = motor.getIq();
    }
}

float RB_popVelocityTelemetryRpm()
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    const float    s = s_telRpmSum;
    const uint32_t n = s_telVN;
    s_telRpmSum = 0.0f;
    s_telVN     = 0;
    __set_PRIMASK(primask);

    return (n > 0) ? (s / static_cast<float>(n)) : motor.getVelocityRPM();
}

void RB_popTimingStats(TimingStats& out)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    const uint32_t n = s_tFocN, sum = s_tFocSumCyc, mx = s_tFocMaxCyc, ex = s_tExecMaxCyc, lost = s_tLost, gaps = s_tGaps;
    s_tFocN = 0; s_tFocSumCyc = 0; s_tFocMaxCyc = 0; s_tExecMaxCyc = 0; s_tLost = 0; s_tGaps = 0;
    __set_PRIMASK(primask);

    const float cyc2us = s_cycToSec * 1.0e6f;
    out.focPeriodAvg_us = (n > 0) ? static_cast<float>(sum) / static_cast<float>(n) * cyc2us : 0.0f;
    out.focPeriodMax_us = static_cast<float>(mx) * cyc2us;
    out.focExecMax_us   = static_cast<float>(ex) * cyc2us;
    out.pwmPeriod_us    = static_cast<float>(s_pwmPeriodCyc) * cyc2us;
    out.focCycles       = n;
    out.lostSamples     = lost;
    out.gaps            = gaps;
}

void RB_updateMotor(float dt_sec)
{
    if (!dev.controlLoopEnabled || dev.state == SystemState::CALIBRATING) return;

    motor.updateFOC(dt_sec);                    // vẫn chạy khi reset: giữ duty 50% và bộ ước lượng vận tốc
    motor.updateVelocity(dt_sec);

    if (!s_currentValid) return;                // không cho mẫu dòng rác vào telemetry / GMO

    const float id = motor.getId();
    const float iq = motor.getIq();
    dev.idTelemetry = LPF_Id_Telem.update(id);
    dev.iqTelemetry = LPF_Iq_Telem.update(iq);

    // Khóa an toàn: DISABLED + rotor đứng yên thì dòng thật = 0 (3 pha cùng 50%). Đo được dòng lớn = offset sai
    // -> nếu lúc đó cho chạy, vòng dòng sẽ ép dòng THẬT lệch đúng bằng sai số (log 29/10: ~30 A).
    if (motor.getControlType() == ControlType::DISABLED && std::abs(motor.getVelocityRPM()) < 1.0f) {
        const float imag = std::abs(dev.idTelemetry) + std::abs(dev.iqTelemetry);
        if (imag > __IDLE_CURRENT_FAULT_A) {
            if (++s_zeroBadCalls >= static_cast<uint32_t>(0.2f * __CTRL_LOOP_FREQ_KHZ * 1000.0f)) dev.currentZeroFault = true;
        } else {
            s_zeroBadCalls = 0;
            dev.currentZeroFault = false;
        }
    }

    // Trung bình khối cho telemetry: giá trị gửi lên = trung bình mọi mẫu 5 kHz giữa 2 lần gửi.
    // Lấy mẫu tức thời mỗi 45 ms (22 Hz) một tín hiệu nhiễu băng rộng = aliasing -> đồ thị nhấp nhô.
    s_telIdSum  = s_telIdSum + id;
    s_telIqSum  = s_telIqSum + iq;
    s_telIN     = s_telIN + 1;
    s_telRpmSum = s_telRpmSum + motor.getVelocityRPM();
    s_telVN     = s_telVN + 1;
}

/* ================ CHẾ ĐỘ VỊ TRÍ: trạng thái nội bộ (chỉ ISR truy cập) ================ */
static float    s_posBlank_s     = 0.0f;   // còn bao lâu thì GMO được phép báo lại sau khi bắt đầu rút
static float    s_posTimer_s     = 0.0f;   // bộ đếm thời gian của pha dừng / chờ
static float    s_strokeStartDeg = 0.0f;   // điểm bắt đầu của hành trình đang chạy (rút về đây khi va chạm)
static PosPhase s_resumePhase    = PosPhase::HOLD;
static float    s_hitSign        = 1.0f;   // dấu của tau_ext lúc va chạm (để nhận ra vật cản MỚI khi đang rút)

static inline void posSetPhase(PosPhase ph) { dev.posPhase = static_cast<uint8_t>(ph); }
static inline PosPhase posGetPhase() { return static_cast<PosPhase>(dev.posPhase); }

static inline bool posIsMoving(PosPhase ph)
{
    return ph == PosPhase::OUT || ph == PosPhase::BACK || ph == PosPhase::HOMING;
}

// Va chạm khi đang ở chế độ vị trí. Trả về true nếu đã xử lý bằng cách DỪNG + RÚT về điểm bắt đầu hành trình;
// false nếu phải thả lỏng (DISABLED) như các chế độ khác: đang đứng yên mà bị đẩy, hoặc đang rút mà vẫn bị chặn.
//   OUT  (0 -> đích, chưa tới đích) : rút về 0                 <- yêu cầu chống kẹp
//   BACK (đích -> 0)                : lùi về góc đích           (rút về 0 lúc này = tiếp tục ép vào vật cản)
//   HOMING                          : lùi về chỗ bắt đầu về 0
static bool posStartRetract()
{
    const PosPhase ph = posGetPhase();
    if (!posIsMoving(ph)) return false;
    const float goal = (ph == PosPhase::OUT) ? 0.0f : s_strokeStartDeg;
    s_resumePhase = ph;
    // fromMeasured = true: quỹ đạo bắt đầu lại từ chỗ cánh tay THỰC SỰ đang ở (tham chiếu cũ đã chạy trước,
    // giữ nó thì khâu P tiếp tục ép vào vật cản) + xóa khâu I vận tốc. Phanh bằng gia tốc lớn rồi đảo chiều.
    motor.posMoveTo(goal, dev.posSpeed_degS, __POS_RETRACT_ACCEL_DEG_S2, true);
    posSetPhase(PosPhase::RETRACT);
    dev.posHits = static_cast<uint16_t>(dev.posHits + 1);
    return true;
}

// Lưới an toàn: tham chiếu bỏ xa cánh tay quá __POS_MAX_FOLLOW_ERR_DEG = cánh tay bị chặn mà GMO không báo
static inline bool posFollowErrorExceeded()
{
    return std::abs(motor.getPosRefDeg() - motor.getOutputAngleDeg()) > __POS_MAX_FOLLOW_ERR_DEG;
}

void RB_observeCollision(float dt_in)
{
    if (!dev.controlLoopEnabled || dev.state == SystemState::CALIBRATING) return;

    // Chia tần theo THỜI GIAN THỰC: GMO chạy mỗi ~1 ms và tích phân đúng khoảng thời gian đã trôi qua.
    // (Bản cũ: chạy mỗi 5 lần gọi với dt = 1 ms cố định; khi FOC thực 4 kHz thì GMO thực 0.8 kHz, tích phân
    //  chỉ bằng 0.8 thời gian thật trong khi J*omega bị phóng 1.25x -> J_hieu_dung = 1.5625 J, Ko = 0.8 Ko.)
    s_gmoDtAcc += dt_in;
    if (s_gmoDtAcc < 0.95f / (static_cast<float>(__GMO_LOOP_FREQ_KHZ) * 1000.0f)) return;
    const float dt_sec = s_gmoDtAcc;
    s_gmoDtAcc = 0.0f;

    float omega_m  = motor.getVelocityRadS();
    float pCurrent = __GMO_INERTIA_J * omega_m;
    // Iq sau LPF 800 Hz thay cho Iq LPF 10 Hz: trễ 16 ms của LPF 10 Hz lệch pha với động lượng J*omega
    // (vận tốc từ Kalman gần như không trễ) -> tín hiệu giả mỗi khi Iq đổi nhanh. Nhiễu còn lại bị chính
    // observer (Ko = 20 rad/s) lọc: ~0.001 N.m rms, rất xa ngưỡng 0.045.
    float tau_e    = __GMO_KT_NM_PER_AMP * motor.getIq();

    if (!s_currentValid) {                      // đang reset tầng công suất: dòng là rác
        s_gmoIntegral    = 0.0f;
        s_p0             = pCurrent;
        dev.tauExtEst_Nm = 0.0f;
        return;
    }

    // --- TRONG RB_observeCollision(float dt_in) (Thay đoạn tính tauFriction): ---

        const float absRpm = std::abs(motor.getVelocityRPM());
        // Ma sát cực đại mà hộp số có thể tự giữ tại tốc độ hiện tại (chuyển tiếp mượt từ Static 0.35A về Coulomb 0.08A)
        const float maxFric_Nm = __GMO_KT_NM_PER_AMP * motor.frictionModelA(absRpm)
                               + __GMO_VISCOUS_B * std::abs(omega_m)
                               + 0.04f * std::abs(tau_e);

        float tauFriction = 0.0f;
        if (absRpm > 3.0f) {
            // Đang quay rõ ràng: ma sát ngược chiều vận tốc
            tauFriction = (omega_m > 0.0f) ? maxFric_Nm : -maxFric_Nm;
        } else {
            // Vùng tốc độ rất thấp / chuyển tiếp dính-trượt (< 3 RPM):
            // Ma sát hộp số tự cân bằng với mô-men điện cho tới ngưỡng bứt tĩnh __GMO_STATIC_NM
            const float staticCap = std::max(maxFric_Nm, __GMO_STATIC_NM);
            if (tau_e > staticCap)       tauFriction = staticCap;
            else if (tau_e < -staticCap) tauFriction = -staticCap;
            else                         tauFriction = tau_e;
        }

    if (dev.state == SystemState::RUNNING) {
        s_gmoIntegral += dt_sec * (tau_e - tauFriction - dev.tauExtEst_Nm);
        dev.tauExtEst_Nm = __GMO_GAIN_KO_RAD_S * (s_gmoIntegral - (pCurrent - s_p0));

        if (s_posBlank_s > 0.0f) s_posBlank_s -= dt_sec;
        const bool     posMode = (motor.getControlType() == ControlType::POSITION);
        const uint32_t headMs  = posMode ? static_cast<uint32_t>(__POS_GMO_HEADSTART_MS) : static_cast<uint32_t>(__GMO_HEADSTART_MS);
        const float    tau     = dev.tauExtEst_Nm;
        bool hit = false;
        if (HAL_GetTick() - dev.runStartTick_ms > headMs && s_posBlank_s <= 0.0f) {
            if (posMode && posGetPhase() == PosPhase::RETRACT) {
                // Đang rút: chỉ vật cản MỚI chắn đường rút (đẩy ngược chiều rút -> tau đổi dấu) mới tính
                hit = (tau * s_hitSign < -dev.gmoThreshold_Nm);
            } else {
                hit = (std::abs(tau) > dev.gmoThreshold_Nm);
            }
        }
        // Lưới an toàn sai lệch bám: không phụ thuộc bộ quan sát nên không cần chờ khởi động
        if (posMode && posFollowErrorExceeded()) hit = true;
        {
            if (hit) {
                if (posMode && posStartRetract()) {
                    s_hitSign = (tau >= 0.0f) ? 1.0f : -1.0f;
                    // Đang chạy: đã dừng + rút lui. Khởi động lại GMO từ 0 và bỏ qua một khoảng ngắn vì tau_ext
                    // còn đuôi của cú va chạm; sau đó GMO canh tiếp: nếu đường rút cũng bị chặn -> thả lỏng.
                    s_gmoIntegral    = 0.0f;
                    s_p0             = pCurrent;
                    dev.tauExtEst_Nm = 0.0f;
                    s_posBlank_s     = static_cast<float>(__POS_GMO_BLANK_MS) * 1e-3f;
                } else {
                    dev.state = SystemState::COLLISION_STOP;
                    dev.collisionStartTick_ms = HAL_GetTick();
                    motor.setControlType(ControlType::DISABLED);
                }
            }
        }
    } else {
        s_gmoIntegral    = 0.0f;
        s_p0             = pCurrent;
        dev.tauExtEst_Nm = 0.0f;
    }
}

// Bộ điều phối chế độ vị trí: chạy trong ISR mỗi vòng FOC, sau GMO. Mọi lệnh posMoveTo đều phát ra từ đây
// (hoặc từ posStartRetract, cũng trong ISR) nên không có tranh chấp với loop().
void RB_updatePositionSequencer(float dt_sec)
{
    if (motor.getControlType() != ControlType::POSITION) {
        if (dev.state != SystemState::COLLISION_STOP) posSetPhase(PosPhase::OFF);   // giữ pha cũ để GUI thấy lúc thả lỏng
        dev.posCountdown_sec = 0;
        return;
    }
    if (dev.state != SystemState::RUNNING) return;

    const float speed  = dev.posSpeed_degS;
    const float target = dev.posTarget_deg;

    // 1. Yêu cầu từ loop() (lệnh 0x0D, Arm, hồi phục sau va chạm)
    const uint8_t req = dev.posRequest;
    if (req != POS_REQ_NONE) {
        dev.posRequest = POS_REQ_NONE;
        dev.posCycling = (req == POS_REQ_CYCLE);
        s_posTimer_s   = 0.0f;
        if (std::abs(motor.getOutputAngleDeg()) > 0.2f) {
            // Góc bắt đầu luôn là 0: chưa ở 0 thì về 0 trước
            s_strokeStartDeg = motor.getOutputAngleDeg();
            motor.posMoveTo(0.0f, speed, __POS_ACCEL_DEG_S2, true);
            posSetPhase(PosPhase::HOMING);
        } else if (dev.posCycling) {
            s_strokeStartDeg = 0.0f;
            motor.posMoveTo(target, speed, __POS_ACCEL_DEG_S2, true);
            posSetPhase(PosPhase::OUT);
        } else {
            motor.posMoveTo(0.0f, speed, __POS_ACCEL_DEG_S2, true);
            posSetPhase(PosPhase::HOMING);
        }
    }

    // 2. Chuyển pha
    const float dwell = static_cast<float>(__POS_DWELL_MS) * 1e-3f;
    switch (posGetPhase()) {
        case PosPhase::HOMING:
            if (motor.isPosTrajDone()) {
                s_posTimer_s = 0.0f;
                posSetPhase(dev.posCycling ? PosPhase::DWELL_ZERO : PosPhase::HOLD);
            }
            break;
        case PosPhase::OUT:
            if (motor.isPosTrajDone()) {
                s_posTimer_s = 0.0f;
                posSetPhase(PosPhase::DWELL_TARGET);
            }
            break;
        case PosPhase::DWELL_TARGET:
            s_posTimer_s += dt_sec;
            if (s_posTimer_s >= dwell) {
                s_strokeStartDeg = motor.getPosGoalDeg();
                motor.posMoveTo(0.0f, speed, __POS_ACCEL_DEG_S2);
                posSetPhase(PosPhase::BACK);
            }
            break;
        case PosPhase::BACK:
            if (motor.isPosTrajDone()) {
                s_posTimer_s = 0.0f;
                posSetPhase(dev.posCycling ? PosPhase::DWELL_ZERO : PosPhase::HOLD);
            }
            break;
        case PosPhase::DWELL_ZERO:
            s_posTimer_s += dt_sec;
            if (s_posTimer_s >= dwell) {
                if (dev.posCycling) {
                    s_strokeStartDeg = 0.0f;
                    motor.posMoveTo(target, speed, __POS_ACCEL_DEG_S2);   // góc đích mới (nếu vừa đổi) áp dụng ở đây
                    posSetPhase(PosPhase::OUT);
                } else {
                    posSetPhase(PosPhase::HOLD);
                }
            }
            break;
        case PosPhase::RETRACT:
            if (motor.isPosTrajDone()) {
                s_posTimer_s = 0.0f;
                posSetPhase(PosPhase::WAIT_AFTER_HIT);
            }
            break;
        case PosPhase::WAIT_AFTER_HIT: {
            s_posTimer_s += dt_sec;
            const float wait = static_cast<float>(__POS_COLLISION_WAIT_MS) * 1e-3f;
            const float left = wait - s_posTimer_s;
            dev.posCountdown_sec = (left > 0.0f) ? static_cast<uint8_t>(left + 0.999f) : 0;
            if (s_posTimer_s >= wait) {
                dev.posCountdown_sec = 0;
                if ((__POS_AUTO_RESUME != 0) && dev.posCycling) {
                    if (s_resumePhase == PosPhase::OUT) {            // đang ở 0: đi lại tới đích
                        s_strokeStartDeg = 0.0f;
                        motor.posMoveTo(target, speed, __POS_ACCEL_DEG_S2);
                        posSetPhase(PosPhase::OUT);
                    } else {                                         // đang ở đích / chỗ cũ: tiếp tục về 0
                        s_strokeStartDeg = motor.getPosGoalDeg();
                        motor.posMoveTo(0.0f, speed, __POS_ACCEL_DEG_S2);
                        posSetPhase(s_resumePhase == PosPhase::BACK ? PosPhase::BACK : PosPhase::HOMING);
                    }
                } else {
                    posSetPhase(PosPhase::HOLD);
                }
            }
            break;
        }
        case PosPhase::OFF:            // vừa vào chế độ vị trí mà chưa có yêu cầu: đứng giữ
            posSetPhase(PosPhase::HOLD);
            break;
        case PosPhase::HOLD:
        default:
            break;
    }
}

void RB_runEncoderCalibrationBlocking()
{
    RB_stopControlClock();
    dev.state = SystemState::CALIBRATING;

    RB_resetPowerStage();
    RB_stopControlClock();
    dev.state = SystemState::CALIBRATING;
    HAL_Delay(100);

    const float vCalib = 1.4f;
    motor.applyOpenLoopVoltage(vCalib, 0.0f, 0.0f);
    HAL_Delay(700);

    encoder.update();
    uint16_t prevRaw = encoder.getRawCounts();
    int32_t  cumRaw  = prevRaw;

    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float mechRef = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        motor.applyOpenLoopVoltage(vCalib, 0.0f, mechRef * __MOT_POLE_PAIRS);
        HAL_Delay(4);

        encoder.update();
        uint16_t curRaw = encoder.getRawCounts();
        int32_t  dRaw   = static_cast<int32_t>(curRaw) - static_cast<int32_t>(prevRaw);
        if (dRaw > 8192)  dRaw -= 16384;
        if (dRaw < -8192) dRaw += 16384;
        prevRaw = curRaw;
        cumRaw += dRaw;

        float unwrappedMeas = (static_cast<float>(cumRaw) / AS5047P::RESOLUTION) * (2.0f * M_PI);
        s_fwdErr[i] = unwrappedMeas - mechRef;
    }

    for (int i = TOTAL_SAMPLES - 1; i >= 0; --i) {
        float mechRef = (2.0f * M_PI * i) / TOTAL_SAMPLES;
        motor.applyOpenLoopVoltage(vCalib, 0.0f, mechRef * __MOT_POLE_PAIRS);
        HAL_Delay(4);

        encoder.update();
        uint16_t curRaw = encoder.getRawCounts();
        int32_t  dRaw   = static_cast<int32_t>(curRaw) - static_cast<int32_t>(prevRaw);
        if (dRaw > 8192)  dRaw -= 16384;
        if (dRaw < -8192) dRaw += 16384;
        prevRaw = curRaw;
        cumRaw += dRaw;

        float unwrappedMeas = (static_cast<float>(cumRaw) / AS5047P::RESOLUTION) * (2.0f * M_PI);
        s_bwdErr[i] = unwrappedMeas - mechRef;
    }

    driver.setDutyCycle(0.5f, 0.5f, 0.5f);

    // 1. Trung bình xuôi/ngược (triệt tiêu trễ do ma sát) rồi tách offset.
    //    Trừ trung bình CHƯA wrap để mảng còn lại đúng là sai số phi tuyến (INL) quanh 0.
    double sumErr = 0.0;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        s_avgErr[i] = 0.5f * (s_fwdErr[i] + s_bwdErr[i]);
        sumErr += s_avgErr[i];
    }
    const float meanErr = static_cast<float>(sumErr / TOTAL_SAMPLES);
    float minErr = 1e9f, maxErr = -1e9f;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        s_avgErr[i] -= meanErr;
        if (s_avgErr[i] < minErr) minErr = s_avgErr[i];
        if (s_avgErr[i] > maxErr) maxErr = s_avgErr[i];
    }
    const float zeroOffset = wrapTwoPi(meanErr);

    // Kiểm tra hợp lệ: INL thật của AS5047P chỉ cỡ vài độ. Dao động > 0.3 rad (~17 độ cơ) nghĩa là
    // rotor trượt bước, encoder ngược chiều quay điện, hoặc sai số cặp cực -> không nạp LUT.
    const bool valid = (maxErr - minErr) < 0.3f;

    // 2. Làm mượt trượt đúng 1 chu kỳ điện để triệt các thành phần theo góc điện (cogging, ...)
    const int window = SAMPLES_PER_POLE;
    for (int i = 0; i < TOTAL_SAMPLES; ++i) {
        float sumWin = 0.0f;
        for (int w = -window / 2; w < window / 2; ++w) {
            int idx = (i + w + TOTAL_SAMPLES) % TOTAL_SAMPLES;
            sumWin += s_avgErr[idx];
        }
        s_fwdErr[i] = sumWin / static_cast<float>(window);   // INL đã làm mượt, theo trục mechRef
    }

    // 3. [SỬA LỖI] interpolateLUT() tra bảng theo GÓC RAW, nhưng bản cũ điền bảng theo trục mechRef
    //    (lut[i] = -err[i * TOTAL / 128]). Hai trục lệch nhau đúng zeroOffset, nên phép bù rơi sai chỗ
    //    và với đa số vị trí lắp nam châm còn làm sai số góc điện LỚN HƠN cả khi không dùng LUT.
    //    Đổi trục: raw = mechRef + meanErr + INL(mechRef)  =>  mechRef = raw - meanErr - INL.
    // Phần cuối của RB_runEncoderCalibrationBlocking():
        if (valid) {
            for (int j = 0; j < AS5047P::LUT_SIZE; ++j) {
                const float rawAngle = (2.0f * static_cast<float>(M_PI) * j) / AS5047P::LUT_SIZE;
                float ref = rawAngle - meanErr;
                float inl = sampleSmoothedErr(ref);
                ref = rawAngle - meanErr - inl;
                inl = sampleSmoothedErr(ref);
                s_lut[j] = -inl;
                if (dev.can != nullptr) {
                    dev.can->sendLUTPoint(static_cast<uint8_t>(j), s_lut[j]);
                }
                HAL_Delay(3);
            }
            encoder.setLUT(s_lut, zeroOffset);
            motor.setUseLUT(true);
            // Lưu bảng LUT + zeroOffset vào Sector 11 của Flash để lần bật nguồn sau tự nạp
            RB_saveParamToFlash(zeroOffset, s_lut);
        }

        uint16_t diag = 0;
        if (encoder.readDiagAgc(diag)) dev.encDiag = diag;

        motor.setControlType(ControlType::DISABLED);
        RB_startControlClock();
        // Chờ 300ms ở 50% duty cho cuộn dây xả hết dòng 1.4V rồi đo lại Offset ADC sạch (triệt tiêu gai -0.37A lúc t=52.3s)
        HAL_Delay(300);
        calibrateCurrentOffsets();
        dev.state = valid ? SystemState::IDLE : SystemState::ERROR;
}

/* ============ CALLBACKS ============ */
extern "C" void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance != currentSensor.getMasterADCInstance()) return;
    const uint32_t t0 = DWT->CYCCNT;
    DBG_ISR_HIGH();

    // Chỉ khi gom đủ mẫu oversampling mới chạy vòng FOC và GMO
    if (currentSensor.onConversionComplete_ISR()) {
        float dt = s_dtNominal;
        if (s_focPrimed) {
            const uint32_t dc = t0 - s_lastFocCyc;               // phép trừ không dấu: đúng cả khi CYCCNT tràn
            const uint32_t nominalCyc = static_cast<uint32_t>(s_dtNominal / s_cycToSec);
            if (dc > __TIMING_GAP_FACTOR * nominalCyc) {
                // Gián đoạn dài (hiệu chỉnh offset, reset...): không phải mất mẫu, nối lại bộ ước lượng
                s_tGaps = s_tGaps + 1;
                motor.requestEstimatorResync();
            } else if (dc < nominalCyc / 4u) {
                // Khoảng cách phi lý (DWT không đếm?): dùng dt danh định thay vì dt ~ 0 làm hỏng bộ ước lượng.
                // Khi đó gói 0x107 báo chu kỳ FOC = 0 -> biết ngay DWT có vấn đề.
                s_tGaps = s_tGaps + 1;
            } else {
                dt = static_cast<float>(dc) * s_cycToSec;
                // Số chu kỳ PWM thật đã trôi qua; mỗi chu kỳ có 1 lần trigger ADC. > OVERSAMPLE = mất mẫu.
                const uint32_t periods = (dc + s_pwmPeriodCyc / 2u) / s_pwmPeriodCyc;
                if (periods > static_cast<uint32_t>(__ADC_OVERSAMPLE_COUNT)) {
                    s_tLost = s_tLost + (periods - static_cast<uint32_t>(__ADC_OVERSAMPLE_COUNT));
                }
                s_tFocN = s_tFocN + 1;
                s_tFocSumCyc = s_tFocSumCyc + dc;
                if (dc > s_tFocMaxCyc) s_tFocMaxCyc = dc;
            }
        }
        s_lastFocCyc = t0;
        s_focPrimed  = true;
        dev.focCount = dev.focCount + 1;
        DBG_FOC_TOGGLE();

        RB_updateMotor(dt);
        RB_observeCollision(dt);
        RB_updatePositionSequencer(dt);

        const uint32_t exec = DWT->CYCCNT - t0;
        if (exec > s_tExecMaxCyc) s_tExecMaxCyc = exec;
    }
    DBG_ISR_LOW();
}
