// App/systemConfig.h
#pragma once
#include "main.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* ===================== HARDWARE PINS ===================== */
#define __ENC_SPI_PORT                  (GPIOA)
#define __ENC_SPI_CS_PIN                (GPIO_PIN_15)
#define __DRV_EN_GATE_PORT              (GPIOB)
#define __DRV_EN_GATE_PIN               (GPIO_PIN_12)

/* ===================== CONTROL LOOP ====================== */
#define __ADC_TRIGGER_FREQ_KHZ          (20)
#define __ADC_OVERSAMPLE_COUNT          (4)
#define __CTRL_LOOP_FREQ_KHZ            (5)        // Vòng dòng chạy ở 5 kHz (dt = 200 us)
#define __VEL_LOOP_FREQ_KHZ             (1)        // Vòng vận tốc chạy ở 1 kHz (dt = 1 ms)
#define __GMO_LOOP_FREQ_KHZ             (1)        // Vòng GMO chạy ở 1 kHz
#define __TELEMETRY_PERIOD_MS           (15)

/* ===================== ĐO THỜI GIAN VÒNG LẶP ===================== */
// Firmware đo thời gian thực giữa 2 vòng FOC bằng bộ đếm chu kỳ DWT và dùng nó làm dt cho bộ ước lượng
// vận tốc, vòng tốc độ và GMO. Các tần số ở trên chỉ còn là giá trị DANH ĐỊNH.
#define __TIMING_GAP_FACTOR             (4u)       // > 4x chu kỳ danh định = gián đoạn (hiệu chỉnh/reset), không tính mất mẫu
#define __TIMING_DIAG_PERIOD_MS         (500)      // chu kỳ gửi gói 0x107
// Chân cho oscilloscope (phải cấu hình GPIO_Output trong CubeMX trước). ODrive v3.x: PA0 = GPIO1, PA1 = GPIO2.
#define __DEBUG_TIMING_GPIO             (0)
#define __DEBUG_TIMING_PORT             (GPIOA)
#define __DEBUG_ISR_PIN                 (GPIO_PIN_0)   // mức cao suốt thời gian callback ADC (20 kHz)
#define __DEBUG_FOC_PIN                 (GPIO_PIN_1)   // đảo mỗi vòng FOC: 2.5 kHz nếu FOC đúng 5 kHz

/* ============ GIM8108-8 (CỘT GDS68 - ĐẤU SAO Y) ========== */
#define __MOT_POLE_PAIRS                (21)
#define __MOT_GEAR_RATIO                (8.0f)

// Datasheet GDS68: R_ll = 0.67 Ohm, L_ll = 0.37 mH -> Đấu Y chia 2:
#define __MOT_PHASE_RESISTANCE_OHM      (0.335f)     // 0.67 / 2
#define __MOT_INDUCTANCE_H              (0.000185f)  // 0.37 mH / 2 = 0.185 mH

// ---- Đo từ log 26/10, ĐÃ QUY VỀ TỐC ĐỘ THẬT ----
// Log ghi RPM do firmware báo, cao hơn thật 1.25x (FOC thực 4 kHz, firmware tính với dt của 5 kHz; tốc độ
// từ encoder / RPM báo = 0.800). Từ bản này dt được đo bằng DWT nên vận tốc là THẬT -> mọi tham số gắn với
// tốc độ phải nhân 1/0.8. Giá trị cũ (đơn vị tốc độ sai) để trong ngoặc.
// Từ thông: độ dốc (Uq - R*iq) theo RPM thật = 0.01839/0.8 = 0.02299 V/RPM -> lambda (0.00836 cũ)
// Đơn vị "volt lệnh": feedforward đúng kể cả khi Vbus thật khác 24 V.
#define __MOT_FLUX_LINKAGE_WB           (0.01045f)
// Kt theo quy ước dq biên độ (iq = dòng pha đỉnh) = 1.5*pp*lambda = 0.329 N.m/A tại rotor (~2.6 N.m/A trục ra)
// nếu Vbus đúng 24 V. CẦN CHỐT BẰNG LOAD CELL. Datasheet ghi 1.0 N.m/A trục ra theo đơn vị dòng của driver GDS68 (cột GDZ468 cùng
// động cơ lại ghi 1.32) -> không dùng trực tiếp cho dq được.
#define __MOT_KT_DQ_NM_PER_AMP          (1.5f * __MOT_POLE_PAIRS * __MOT_FLUX_LINKAGE_WB)
// J/Kt từ các pha tăng tốc tự do ở chế độ mô-men: gia tốc trong log cũng bị phóng 1.25x
// -> 0.90..1.48e-3 A.s^2/rad theo thời gian thật (1.0e-3 cũ). Không phụ thuộc Vbus.
// Đây là con số duy nhất vòng tốc độ và bộ Kalman cần.
#define __MOT_J_OVER_KT                 (1.25e-3f)
// Ma sát động quy ra dòng (hộp số): ~0.07 A khi đang quay; ma sát tĩnh (breakaway) ~0.25-0.3 A.
#define __MOT_COULOMB_A                 (0.07f)

// Field weakening: VÔ DỤNG với động cơ này. Dòng đặc trưng lambda/L = 45 A >> giới hạn 2.2 A, nên Id = -0.8 A
// chỉ giảm từ thông 1.8% (~8 RPM). Log 26/10: bật FW làm tốc độ TỤT 416 -> 326 RPM và dao động tăng 3.6 lần
// (sai góc 1-2 độ điện đủ biến 0.8 A trục d thành mô-men cản). 0 = bỏ qua lệnh 0x06.
#define __FW_ALLOWED                    (1)
// Feedforward back-EMF trục q: uq += omega_e * lambda. Không có nó, khâu I vòng dòng phải tự "đuổi" back-EMF:
// tăng tốc 0 -> 340 RPM trong 0.25 s thì Iq thực chỉ đạt ~0.22 A trên lệnh 0.30 A (thiếu 28% mô-men), và mỗi
// lần rotor bị đẩy quay nhanh Iq tụt về âm (thấy rõ trong log) -> tau_ext của GMO sai theo.
// Nhưng ở chế độ TỐC ĐỘ, phần back-EMF vòng dòng chưa triệt hết lại là giảm chấn điện tự nhiên cho dao động tốc độ;
// feedforward xóa nó -> dao động tăng 7-34% (mô phỏng). Vì vậy:
//   0 = tắt, 1 = chỉ ở chế độ mô-men (CURRENT, gồm cả MIT), 2 = mọi chế độ
#define __FOC_BEMF_FF_MODE              (2)
// LPF cho vận tốc dùng trong feedforward (Hz): back-EMF chỉ đổi theo tốc độ cơ, nhiễu thì không.
#define __FOC_BEMF_FF_LPF_HZ            (15.0f)

#define __V_BUS_VOLTS                   (24.0f)
#define __CURRENT_LIMIT_AMPS            (2.2f)
#define __VOLTAGE_LIMIT_VOLTS           (11.5f)      // giới hạn BIÊN ĐỘ vector (tròn, ưu tiên trục d). Bản trước 8.0
// Log 29/10: chế độ mô-men không tải tăng tốc tới 337 RPM thì Uq = 7.99 V (chạm 8 V) -> vòng dòng hết áp, Iq thực
// tụt về ~0.08 A dù lệnh 0.2-0.45 A. Back-EMF 0.0230 V/RPM: 8 V ~ 340 RPM, 10.5 V ~ 450 RPM.
// Trần phần cứng ~11.0 V (24 V, duty 0.02-0.90, dịch tâm min-max: đỉnh pha = 0.866 x biên độ <= 0.40 x 24 V).
// 10.5 V -> duty lớn nhất 0.879, cửa sổ low-side quanh tâm còn ~3 us, đủ cho ADC lấy mẫu.
#define __PWM_MIN_DUTY_RATIO            (0.02f)
#define __PWM_MAX_DUTY_RATIO            (0.90f)      // Giới hạn max duty <= 90% để shunt low-side đủ thời gian dẫn

/* ===================== CURRENT SENSOR ==================== */
// 0.16117 A/LSB = 3.3 V / 4095 / (10 V/V x 0.5 mOhm) -> đúng bằng gain MẶC ĐỊNH 10 V/V của DRV8301.
// Firmware cũ chưa bao giờ ghi SPI cho DRV8301, nên gain luôn là 10 V/V: 2.2 A chỉ chiếm ~14 LSB.
#define __ADC_CURRENT_SCALE_A_LSB       (0.16117f)                                   // tại gain 10 V/V
#define __ADC_CURRENT_SCALE_AT_GAIN(g)  (__ADC_CURRENT_SCALE_A_LSB * 10.0f / (float)(g))
#define __ADC_CALIB_SAMPLES             (2000)       // 2000 mẫu @ 20 kHz = 100 ms

// Auto-zero offset khi IDLE. DISABLED = 50% duty cả 3 pha = chập cuộn dây qua cầu,
// nên nếu rotor còn quay (trôi sau va chạm, xoay tay) sẽ có dòng hãm chạy qua shunt và
// auto-zero cũ (tau = 40 ms) "học" luôn dòng đó thành offset. Giờ chỉ chạy khi rotor đứng yên.
#define __ADC_AUTOZERO_ALPHA            (0.0005f)    // tau = 1/(alpha * 5 kHz) = 0.4 s
#define __ADC_AUTOZERO_MAX_RPM          (0.5f)
// Mẫu lệch khỏi offset quá ngưỡng này (LSB) không được học: chống bộ khuếch đại dòng trục trặc tạm thời
#define __ADC_AUTOZERO_GATE_LSB         (40.0f)
#define __ADC_AUTOZERO_REACQUIRE_S      (0.5f)     // lệch liên tục lâu hơn thế = mức 0 dịch thật -> lấy lại offset
#define __ADC_OFFSET_PLAUSIBLE_LSB      (100.0f)   // offset hợp lệ: 2048 +- (100 + 4*(gain-10)) LSB
// Đứng yên + DISABLED mà |Id|+|Iq| (lọc 10 Hz) > ngưỡng này quá 0.2 s -> offset sai -> ERROR, cấm chạy
#define __IDLE_CURRENT_FAULT_A          (0.5f)

/* ===================== DRV8301 SPI (TÙY CHỌN) ===================== */
// 1 = cấu hình gain bộ khuếch đại dòng (CSA) của DRV8301 qua SPI. Cần bật SPI trong CubeMX:
//     Full-duplex master, 16-bit, MSB first, CPOL = Low, CPHA = 2 Edge, <= 5 MHz, NSS = Software.
// Board ODrive v3.x (EN_GATE = PB12, shunt 0.5 mOhm - khớp với scale ở trên):
//     SPI3 = PC10 SCK / PC11 MISO / PC12 MOSI, nCS động cơ M0 = PC13.  -> KIỂM TRA LẠI SCHEMATIC.
// DRV8301 phải nằm trên SPI KHÁC với AS5047P (encoder được đọc trong ISR 5 kHz).
// Thanh ghi DRV8301 tự về mặc định mỗi lần kéo EN_GATE xuống, nên firmware ghi lại sau MỖI lần
// reset, đọc lại để xác nhận, và scale dòng luôn lấy theo gain ĐỌC LẠI được (không đọc được -> 10).
#define __DRV_SPI_CONFIG_ENABLE         (0)
#define __DRV_SPI_HANDLE                hspi3
#define __DRV_SPI_CS_PORT               (GPIOC)
#define __DRV_SPI_CS_PIN                (GPIO_PIN_13)
// 10 / 20 / 40 / 80 V/V. 40 -> 0.040 A/LSB (mịn hơn 4x), 80 -> 0.020 A/LSB (8x).
// Bắt đầu với 40; nếu dòng đo ở duty cao vẫn đúng thì nâng lên 80.
#define __DRV_CSA_GAIN                  (40)
#define __DRV_CHECK_PERIOD_MS           (50)         // đọc lại thanh ghi mỗi 50 ms (~10 us mỗi lần)

/* =========== PI DÒNG TÍNH TỪ R, L ========== */
// Chọn 1: Băng thông thấp (150 Hz - cực êm) | Chọn 2: Băng thông cao (250 Hz - cứng vững)
#define __FOC_CURRENT_BW_PRESET         (1)

/* ===================== FLASH STORAGE (MỤC 3 & 11 .MD) ===================== */
// STM32F405RG (1MB Flash): Sector 11 bắt đầu tại 0x080E0000 (128 KB), hoàn toàn tách biệt vùng code.
#define __PARAM_FLASH_SECTOR            (FLASH_SECTOR_11)
#define __PARAM_FLASH_ADDR              (0x080E0000UL)
#define __PARAM_FLASH_MAGIC             (0x47494D38UL) // "GIM8"



#if (__FOC_CURRENT_BW_PRESET == 1)
#define __FOC_CURRENT_BW_HZ             (45.0f)
#else
#define __FOC_CURRENT_BW_HZ             (150.0f)
#endif

#define __FOC_CURRENT_OMEGA_C           (2.0f * M_PI * __FOC_CURRENT_BW_HZ)

// Kp = L * omega_c ; Ki_discrete = (R * omega_c) / f_ctrl
#define __MOT_CURRENT_PID_KP            (__MOT_INDUCTANCE_H * __FOC_CURRENT_OMEGA_C)
#define __MOT_CURRENT_PID_KI            ((__MOT_PHASE_RESISTANCE_OHM * __FOC_CURRENT_OMEGA_C) / (__CTRL_LOOP_FREQ_KHZ * 1000.0f))

/* ===================== VELOCITY ESTIMATOR ===================== */
// 0 = PLL (bản trước), 1 = Kalman 3 trạng thái [goc, van toc, gia toc nhieu tai] dùng Iq lệnh làm đầu vào.
// Mô phỏng vòng kín (encoder sigma 1.6 count, nhiễu dòng như log): so với PLL wn=300, Kalman giảm sai số
// vận tốc khi tăng tốc theo lệnh mô-men từ ~14 RPM xuống ~1 RPM (PLL trễ ~6 ms), nhiễu ước lượng thấp hơn
// ~25%, sụt tốc khi có tải đột ngột ít hơn. Nó KHÔNG làm giảm dao động tốc độ thật - cái đó do nhiễu dòng.
#define __VEL_ESTIMATOR                 (1)
#define __VEL_PLL_BANDWIDTH_RAD_S       (180.0f)
// Cổng chống rung (hysteresis, count) - áp cho cả PLL lẫn Kalman, không áp cho góc FOC. 0 = tắt.
#define __VEL_ENC_DITHER_COUNTS         (0.0f)
// Kalman: R = sigma encoder^2 (đo từ log lúc đứng yên). Q_VEL = biến động mô-men không mô hình hóa (nhiễu dòng,
// cogging); Q_DIST = tốc độ thay đổi của tải/ma sát. Tăng Q_DIST -> bám tải nhanh hơn nhưng nhiễu hơn.
// Với giá trị dưới: K ~ [0.090, 21.0, 2200], cực observer ~ 206 / 237 / 237 rad/s.
#define __KF_ENC_SIGMA_COUNTS           (1.6f)
#define __KF_Q_VEL                      (0.08f)
#define __KF_Q_DIST                     (1.5e3f)

/* ===================== VELOCITY PID ====================== */
// Thiết kế từ J/Kt (plant: omega/iq = 1 / ((J/Kt)*s)):
//   kp = (J/Kt) * wv   [A/(rad/s)],  ki = kp * wi   [A/rad]   -> đổi sang đơn vị RPM của code (x 2*pi/60)
// Bản cũ 0.015 / 0.035: wv ~ 140 rad/s nhưng góc tích phân chỉ 2.3 rad/s -> khâu I quá chậm, tải đột ngột
// mất ~0.7 s mới hồi phục và không đủ sức chống ma sát ở tốc độ thấp.
#define __VEL_LOOP_BW_RAD_S             (110.0f)     // ~24 Hz. Mô phỏng: chống stick-slip tốt hơn 100 rad/s, vẫn dư pha (Kalman gần như không trễ)
#define __VEL_LOOP_INT_RAD_S            (18.0f)      // = wv / 5
// Cùng băng thông THẬT như bản trước: bản trước thấy tốc độ phóng 1.25x nên gain 0.0105 tương đương 0.0131 bây giờ.
#define __MOT_VEL_PID_KP                ((float)(__MOT_J_OVER_KT * __VEL_LOOP_BW_RAD_S * (2.0 * M_PI / 60.0)))  // 0.0196 A/RPM
#define __MOT_VEL_PID_KI                (__MOT_VEL_PID_KP * __VEL_LOOP_INT_RAD_S)                               // 0.393 A/(RPM*s)
#define __MOT_VEL_INTEGRAL_LIM_AMPS     (1.2f)
#define __MOT_VEL_RAMP_RPM_PER_S        (200.0f)
// ---- Ma sát hộp số (đơn vị dòng iq), đo từ log 27/10 ----
// Đang quay 30-340 RPM: Iq xác lập 0.079-0.101 A, gần như PHẲNG theo tốc độ -> ma sát Coulomb, không phải nhớt.
// Đứng yên: ở 10 RPM rotor dính rồi bứt ra mỗi ~0.2 s, Iq đỉnh 0.29-0.32 A ngay trước khi bứt; ở chế độ mô-men
// 0.35 A giữ 1.85 s vẫn không quay -> mức bứt từ trạng thái nghỉ lâu > 0.35 A.
// Tỉ lệ tĩnh/động ~4 lần là nguyên nhân stick-slip: tốc độ thấp "nhiễu" là rotor dính-trượt THẬT (tốc độ tính
// thẳng từ encoder dao động y hệt tốc độ firmware báo), không bộ lọc nào sửa được.
#define __MOT_FRIC_COULOMB_A            (0.085f)
#define __MOT_FRIC_STATIC_FF_A          (0.14f)    // cấp sẵn lúc đứng yên; để THẤP hơn mức bứt (~0.35 A), khâu I lo phần còn lại
#define __MOT_FRIC_BREAKAWAY_A          (0.35f)    // mức bứt đo được (dùng cho mô hình đứng yên của GMO)
#define __MOT_FRIC_STRIBECK_RPM         (4.0f)     // tốc độ mà phần ma sát tĩnh giảm còn 37%
// Feedforward ma sát Stribeck trong vòng TỐC ĐỘ: Iq_ff = sat(rpm*/BAND) * [Ic + (Is - Ic) exp(-(|rpm|/ws)^2)]
#define __VEL_FRICTION_FF_ENABLE        (1)
#define __MOT_VEL_COULOMB_BAND_RPM      (3.0f)
// Feedforward nhớt: bản cũ 0.0018 A/RPM sai mô hình (300 RPM -> 0.54 A trong khi chỉ cần 0.083 A).
#define __MOT_VEL_FF_GAIN_A_PER_RPM     (0.00005f)
// Bù ma sát ở chế độ MÔ-MEN (lệnh 0x03): 1 = motor tự bứt và quay với lệnh nhỏ (không phải mớm tay), mô-men ra
// trục ~ đúng lệnh. Lưu ý: không tải thì Iq bất kỳ > 0.02 A đều tăng tốc tới giới hạn áp (~340 RPM).
// MIT (0x001) không bao giờ cộng bù này.
#define __TORQUE_FRICTION_COMP          (1)
#define __TORQUE_MAX_SPEED_LIMIT_RPM    (60.0f)      // Trần tốc độ khi chạy Torque Mode không tải (đặt 0.0f nếu muốn thả nổi)
#define __TORQUE_SPEED_DAMPING_A_RPM    (0.015f)    // Hệ số giảm chấn giữ tốc độ không vượt quá trần khi không tải

/* ===================== SIGNAL FILTERS ==================== */
// Tần số cắt lọc Id/Iq phải cao hơn nhiều so với băng thông vòng dòng (150 Hz -> cắt ở 800 Hz)
#define __LPF_CURRENT_CUTOFF_HZ         (160.0f)
// Lọc Iq cho GMO và phản hồi MIT (giữ nguyên). Telemetry lên GUI giờ dùng trung bình khối 45 ms.
#define __LPF_TELEM_CUTOFF_HZ           (10.0f)

/* ===================== GMO COLLISION ===================== */
// GIỮ Kt = 0.125 để ngưỡng 0.045 giữ nguyên ý nghĩa bạn đã tinh chỉnh. Với GMO chỉ cần các tham số NHẤT QUÁN
// với nhau theo đơn vị dòng: J = Kt_GMO * (J/Kt đo được) -> phần mô-men quán tính khớp với phần mô-men điện,
// không còn tín hiệu giả khi tăng/giảm tốc mạnh.
#define __GMO_KT_NM_PER_AMP             (0.125f)
#define __GMO_INERTIA_J                 (__GMO_KT_NM_PER_AMP * __MOT_J_OVER_KT)     // 1.5625e-4 (bản đầu 1.8e-4)
// Ma sát chỉnh để tau_ext ~ 0 khi chạy đều: log 26/10 Iq xác lập ~0.08 A @100 RPM và ~0.086 A @416 RPM, trong khi
// bộ cũ (0.018 + 0.0001*w) dự đoán ~0.15 A -> tau_ext luôn lệch -0.01 (100 RPM) đến -0.015 (420 RPM).
#define __GMO_VISCOUS_B                 (0.000025f)  // theo omega thật (0.00002 theo omega bị phóng 1.25x)
#define __GMO_COULOMB_NM                (0.0095f)
// Ma sát tĩnh cho nhánh đứng yên của GMO (= Kt_GMO x mức bứt)
#define __GMO_STATIC_NM                 (__GMO_KT_NM_PER_AMP * __MOT_FRIC_BREAKAWAY_A)
#define __GMO_GAIN_KO_RAD_S             (20.0f)
#define __GMO_THRESHOLD_NM              (0.045f)
#define __GMO_HEADSTART_MS              (600)
#define __GMO_RECOVERY_WAIT_MS          (5000)

/* ============ CHẾ ĐỘ VỊ TRÍ - CÁNH TAY GẠT (lệnh 0x0A..0x0D, telemetry 0x109) ============ */
// Góc tính ở TRỤC RA (sau hộp số), đơn vị ĐỘ. Quy ước: nhìn từ TRÊN xuống, dương = ngược chiều kim đồng hồ (CCW).
// Chạy thử: đặt góc đích +30, bấm Chạy. Nếu cánh tay quay CÙNG chiều kim đồng hồ -> đổi dấu dòng dưới thành (-1.0f).
#define __POS_DIR_SIGN                  (1.0f)
#define __POS_SPEED_DEFAULT_DEG_S       (60.0f)     // tốc độ cánh tay mặc định (= 10 vòng/phút ở trục ra)
#define __POS_SPEED_MAX_DEG_S           (180.0f)    // giới hạn tốc độ nhận từ GUI (rotor 240 RPM, còn xa giới hạn áp)
#define __POS_TARGET_DEFAULT_DEG        (90.0f)
#define __POS_TARGET_LIMIT_DEG          (350.0f)    // |góc đích| tối đa nhận từ GUI
#define __POS_ACCEL_DEG_S2              (600.0f)    // gia tốc = giảm tốc của quỹ đạo hình thang (Iq cần ~0.1 A)
#define __POS_RETRACT_ACCEL_DEG_S2      (2000.0f)   // khi va chạm: phanh/đảo chiều nhanh (Iq cần ~0.35 A)
#define __POS_KP_1_S                    (30.0f)     // khâu P vị trí -> vận tốc [1/s] (~1/4 băng thông vòng tốc độ 110 rad/s)
// Vùng chết khi đứng giữ (có trễ: vào < 1x, thoát > 2x). Phải lớn hơn bước nhảy khi rotor bứt ma sát tĩnh rồi trượt
// (~0.45 độ đỉnh-đỉnh ở trục ra), nếu không cánh tay săn qua lại quanh đích. 0.3 độ ~ 1 mm ở đầu tay dài 20 cm.
#define __POS_DEADBAND_DEG              (0.3f)
#define __POS_DWELL_MS                  (500)       // dừng ở mỗi đầu hành trình trước khi quay lại
// Chờ 5 s (__GMO_RECOVERY_WAIT_MS) CHỈ áp dụng cho chế độ SPEED và TORQUE. Chế độ vị trí:
//  - va chạm khi đang chạy -> dừng, rút về điểm đầu hành trình, dừng bằng thời gian dừng ở 2 đầu rồi chạy tiếp ngay
//  - trường hợp phải thả lỏng (kẹp 2 phía / bị đẩy lúc đứng yên) -> thả lỏng __POS_LIMP_WAIT_MS rồi chạy tiếp
#define __POS_COLLISION_WAIT_MS         (__POS_DWELL_MS)
#define __POS_LIMP_WAIT_MS              (1000)
#define __POS_AUTO_RESUME               (1)         // 1 = chờ xong tự chạy tiếp chu trình; 0 = đứng giữ, chờ lệnh Chạy
// Khi đang RÚT: lực còn sót của vật cản cũ đẩy cánh tay CÙNG chiều rút (tau_ext cùng dấu lúc va chạm) -> bỏ qua;
// vật cản MỚI chắn đường rút đẩy NGƯỢC chiều rút (tau_ext đổi dấu) -> mới báo. Chỉ cần bỏ qua một khoảng rất ngắn
// cho quá độ số học lúc khởi động lại GMO. (Bản trước bỏ qua 150 ms bất kể dấu: SIL cho thấy ở 120-180 độ/s vật cản
// vẫn còn ép sau 150 ms -> bị coi là đường rút bị chặn -> thả lỏng nhầm 4/8 ca.)
#define __POS_GMO_BLANK_MS              (30)
// Thời gian chờ GMO sau khi bấm Chạy, RIÊNG chế độ vị trí. 600 ms chung = mù: SIL chạy 180 độ/s chạm tay sau 288 ms,
// 313 ms sau mới phát hiện, lực ép 18 N.m. Khởi động từ đứng yên chỉ tạo tau_ext giả 0.008 N.m nên 100 ms là đủ.
#define __POS_GMO_HEADSTART_MS          (100)
// Lưới an toàn khi GMO không bắt được (ngưỡng đặt quá cao...): tham chiếu bỏ xa cánh tay quá mức này = bị chặn
#define __POS_MAX_FOLLOW_ERR_DEG        (8.0f)
