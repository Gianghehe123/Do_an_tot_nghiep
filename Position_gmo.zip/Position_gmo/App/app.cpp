// App/app.cpp
#include "app.h"
#include "device.h"
#include <cmath>

extern CAN_HandleTypeDef hcan1;
static CANInterface can(&hcan1);

// COLLISION_STOP và ERROR chỉ được xóa bằng lệnh Stop (0x01) / Arm (0x02)
static inline bool isLatchedStop()
{
    return dev.state == SystemState::COLLISION_STOP || dev.state == SystemState::ERROR;
}

void setup(void)
{
	dev.can = &can;
	    can.init();

	    RB_initMotor();
	    RB_loadParamFromFlash();   // Tự động nạp zeroOffset + LUT 128 điểm đã lưu trong Flash Sector 11

	    RB_startControlClock();
}

void loop(void)
{
    static uint32_t    lastTelemTick            = 0;
    static uint8_t     telemSlot                = 0;
    static ControlType savedModeBeforeCollision = ControlType::VELOCITY;
    static float       savedTargetRpm           = 0.0f;
    static float       savedTargetIq            = 0.0f;

    uint32_t currentTick = HAL_GetTick();

    // 1. Vét sạch hàng đợi lệnh CAN từ ESP32 gửi xuống
    uint32_t   rxStdId = 0;
    uint8_t    cmdId   = 0;
    float      payload = 0.0f;
    MITCommand mitCmd{};

    while (can.pollMessages(rxStdId, cmdId, payload, mitCmd)) {
        if (rxStdId == 0x001) {
            float posErr      = mitCmd.p_des - dev.motor->getMultiTurnRad();
            float velErr      = mitCmd.v_des - dev.motor->getVelocityRadS();
            float totalTorque = mitCmd.kp * posErr + mitCmd.kd * velErr + mitCmd.t_ff;
            float iqCmd       = totalTorque / __GMO_KT_NM_PER_AMP;

            savedModeBeforeCollision = ControlType::CURRENT;
            savedTargetIq            = iqCmd;
            dev.motor->fricCompTorque = false;     // MIT: trở kháng tự tính mô-men, không cộng bù ma sát

            if (std::abs(iqCmd) > 0.02f || mitCmd.kp > 0.01f || mitCmd.kd > 0.01f) {
                if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                if (!isLatchedStop()) {
                    dev.state = SystemState::RUNNING;
                    dev.motor->setControlType(ControlType::CURRENT);
                    dev.motor->setCurrent(iqCmd, 0.0f);
                }
            } else {
                if (dev.state != SystemState::ERROR) dev.state = SystemState::IDLE;
                dev.motor->setControlType(ControlType::DISABLED);
            }
            can.sendMITReplyPacket(1, dev.motor->getMultiTurnRad(),
                                   dev.motor->getVelocityRadS(),
                                   dev.iqTelemetry * __GMO_KT_NM_PER_AMP);
        } else if (rxStdId == 0x100) {
            switch (cmdId) {
                case 0x01: { // Stop: ngắt NGAY, không chặn vòng lặp. Chỉ reset tầng công suất khi đang ERROR.
                    // Bản trước reset ~1.4 s MỖI lần Stop: bấm 3 lần = MCU im 4.1 s (thấy trong log 27/10), FIFO
                    // nhận CAN chỉ 3 khung nên lệnh gửi trong lúc đó bị rơi -> cảm giác "bấm dừng không ăn".
                    const bool wasError = (dev.state == SystemState::ERROR);
                    dev.state = SystemState::IDLE;
                    dev.motor->setControlType(ControlType::DISABLED);
                    dev.motor->fricCompTorque = false;
                    dev.posCycling = false;
                    dev.posRequest = POS_REQ_NONE;
                    savedTargetRpm = 0.0f;
                    savedTargetIq  = 0.0f;
                    if (wasError) RB_resetPowerStage();
                    break;
                }
                case 0x02: // Arm
                    RB_resetPowerStage();
                    dev.runStartTick_ms = HAL_GetTick();
                    dev.state = SystemState::RUNNING;
                    dev.motor->setControlType(savedModeBeforeCollision);
                    if (savedModeBeforeCollision == ControlType::VELOCITY) {
                        dev.motor->setRPM(savedTargetRpm);
                    } else if (savedModeBeforeCollision == ControlType::POSITION) {
                        dev.posRequest = POS_REQ_HOME;
                    } else {
                        dev.motor->setCurrent(savedTargetIq, 0.0f);
                    }
                    break;
                case 0x03: // Set Iq (Torque/Current Mode)
                    dev.motor->fricCompTorque = (__TORQUE_FRICTION_COMP != 0);
                    savedModeBeforeCollision = ControlType::CURRENT;
                    savedTargetIq = payload;
                    if (std::abs(payload) > 0.02f) {
                        if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                        if (!isLatchedStop()) {
                            dev.state = SystemState::RUNNING;
                            dev.motor->setControlType(ControlType::CURRENT);
                            dev.motor->setCurrent(payload, 0.0f);
                        }
                    } else {
                        if (dev.state != SystemState::ERROR) dev.state = SystemState::IDLE;
                        dev.motor->setControlType(ControlType::DISABLED);
                    }
                    break;
                case 0x04: // Calib LUT
                    RB_runEncoderCalibrationBlocking();
                    break;
                case 0x05: // Toggle LUT
                    dev.motor->setUseLUT(payload > 0.5f);
                    break;
                case 0x06: // Toggle Field Weakening (bị khóa nếu __FW_ALLOWED = 0, xem systemConfig.h)
                    dev.motor->setFieldWeakening((__FW_ALLOWED != 0) && (payload > 0.5f));
                    break;
                case 0x07: // Set RPM (Speed Mode)
                    savedModeBeforeCollision = ControlType::VELOCITY;
                    savedTargetRpm = payload;
                    if (std::abs(payload) > 0.5f) {
                        if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                        if (!isLatchedStop()) {
                            dev.state = SystemState::RUNNING;
                            dev.motor->setControlType(ControlType::VELOCITY);
                            dev.motor->setRPM(payload);
                        }
                    } else {
                        if (dev.state != SystemState::ERROR) dev.state = SystemState::IDLE;
                        dev.motor->setControlType(ControlType::DISABLED);
                    }
                    break;
                case 0x08: // Set GMO Collision Threshold (N.m)
                                 if (payload >= 0.005f && payload <= 2.0f) {
                                     dev.gmoThreshold_Nm = payload;
                                 }
                break;
                case 0x09: // Set Torque Mode Speed Saturation Limit (RPM)
                                    if (payload >= 0.0f && payload <= 600.0f) {
                                        dev.motor->torqueSpeedLimit_RPM = payload;
                                    }
                break;
                /* ---------------- CHẾ ĐỘ VỊ TRÍ (cánh tay gạt) ---------------- */
                case 0x0A: // Tốc độ cánh tay [độ/s ở trục ra]. Áp dụng từ hành trình kế tiếp.
                    if (payload >= 1.0f && payload <= __POS_SPEED_MAX_DEG_S) {
                        dev.posSpeed_degS = payload;
                    }
                    break;
                case 0x0B: // Góc đích [độ]. Dương = ngược chiều kim đồng hồ. Áp dụng từ hành trình đi kế tiếp.
                    if (std::abs(payload) <= __POS_TARGET_LIMIT_DEG) {
                        dev.posTarget_deg = payload;
                    }
                    break;
                case 0x0C: // Đặt góc 0 tại vị trí hiện tại. Bị bỏ qua khi đang điều khiển vị trí (cánh tay sẽ giật).
                    if (dev.motor->getControlType() != ControlType::POSITION) {
                        dev.motor->requestPosZero();
                        dev.posZeroSet = true;
                    }
                    break;
                case 0x0D: { // payload >= 0.5: chạy chu trình 0 -> đích -> 0 lặp lại; < 0.5: về 0 rồi đứng giữ
                    savedModeBeforeCollision = ControlType::POSITION;
                    if (!isLatchedStop()) {
                        if (dev.state == SystemState::IDLE) dev.runStartTick_ms = currentTick;
                        if (dev.motor->getControlType() != ControlType::POSITION) {
                            // Khởi tạo tham chiếu nhiều biến: không để ISR chen vào giữa chừng
                            const uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            dev.motor->setControlType(ControlType::POSITION);
                            __set_PRIMASK(primask);
                        }
                        dev.posRequest = (payload > 0.5f) ? POS_REQ_CYCLE : POS_REQ_HOME;
                        dev.state = SystemState::RUNNING;   // đặt SAU posRequest: bộ điều phối chỉ chạy khi RUNNING
                    }
                    break;
                }
                default:
                    break;
            }
        }
    }

    // 1b. Offset dòng sai (đứng yên mà đo thấy dòng lớn): khóa tạm ở ERROR, chặn lệnh chạy.
        //     Khi auto-zero reacquire đã kéo offset về đúng (currentZeroFault == false), tự động mở khóa về IDLE.
        if (dev.currentZeroFault && dev.state != SystemState::RUNNING && dev.state != SystemState::ERROR) {
            dev.state = SystemState::ERROR;
            dev.motor->setControlType(ControlType::DISABLED);
        } else if (!dev.currentZeroFault && dev.state == SystemState::ERROR) {
            dev.state = SystemState::IDLE;
        }

    // 2. Xử lý đếm ngược & tự phục hồi sau va chạm GMO (5 giây)
        if (dev.state == SystemState::COLLISION_STOP) {
                uint32_t elapsed = currentTick - dev.collisionStartTick_ms;
                // 5 s chỉ cho SPEED/TORQUE; chế độ vị trí thả lỏng ngắn hơn (xem __POS_LIMP_WAIT_MS)
                const uint32_t waitMs = (savedModeBeforeCollision == ControlType::POSITION)
                                        ? static_cast<uint32_t>(__POS_LIMP_WAIT_MS)
                                        : static_cast<uint32_t>(__GMO_RECOVERY_WAIT_MS);
                if (elapsed < waitMs) {
                    dev.countdown_sec = static_cast<uint8_t>((waitMs - elapsed) / 1000 + 1);
                } else {
                    dev.countdown_sec = 0;
                    RB_recoverFromCollision();          // Giữ nguyên EN_GATE & điểm 0 của DRV8301, chỉ xóa tích phân!
                    dev.runStartTick_ms = HAL_GetTick();
                    dev.motor->setControlType(savedModeBeforeCollision);
                    if (savedModeBeforeCollision == ControlType::VELOCITY) {
                        dev.motor->setRPM(savedTargetRpm);
                    } else if (savedModeBeforeCollision == ControlType::CURRENT) {
                        dev.motor->setCurrent(savedTargetIq, 0.0f);
                    } else if (savedModeBeforeCollision == ControlType::POSITION) {
                        dev.posRequest = ((__POS_AUTO_RESUME != 0) && dev.posCycling) ? POS_REQ_CYCLE : POS_REQ_HOME;
                    }
                    dev.state = SystemState::RUNNING;
                }
            } else {
                dev.countdown_sec = 0;
            }

    // 3. Chia pha gửi Telemetry CAN mỗi 15ms (mỗi gói lặp lại sau 45 ms)
    if (currentTick - lastTelemTick >= __TELEMETRY_PERIOD_MS) {
        lastTelemTick = currentTick;

        if (telemSlot == 0) {
            // Id/Iq = trung bình khối trong 45 ms. Ia/Ib giữ giá trị tức thời để còn thấy nhiễu ADC thô.
            float idAvg = 0.0f, iqAvg = 0.0f;
            RB_popCurrentTelemetry(idAvg, iqAvg);
            can.sendCurrents(dev.motor->getIa(), dev.motor->getIb(), idAvg, iqAvg);
            telemSlot = 1;
        } else if (telemSlot == 1) {
            // Chế độ vị trí: đang rút lui / chờ sau va chạm cũng báo là va chạm để GUI tô vùng đỏ và đếm ngược
            const PosPhase ph = static_cast<PosPhase>(dev.posPhase);
            const bool posHit = (ph == PosPhase::RETRACT || ph == PosPhase::WAIT_AFTER_HIT) &&
                                dev.motor->getControlType() == ControlType::POSITION;
            uint8_t isCollided = (dev.state == SystemState::COLLISION_STOP || posHit) ? 1 : 0;
            const uint8_t countdown = posHit ? dev.posCountdown_sec : dev.countdown_sec;
            // byte 6 = AGC của AS5047P, byte 7 = cờ chẩn đoán (bit0 LF, bit1 COF, bit2 MAGH, bit3 MAGL)
            const uint16_t diag = dev.encDiag;
            can.sendGMOPacket(dev.tauExtEst_Nm, dev.gmoThreshold_Nm, isCollided, countdown,
                              static_cast<uint8_t>(diag & 0xFF), static_cast<uint8_t>((diag >> 8) & 0xFF));
            telemSlot = 2;
        } else {
            // LUT bit = LUT THỰC SỰ đang dùng (bật + đã hiệu chỉnh trong phiên này). Bản cũ báo ON
            // ngay cả khi chưa hiệu chỉnh, lúc đó FOC đang chạy góc raw không có offset điện.
            uint8_t flags = (dev.motor->isLutActive() ? 0x01 : 0x00) |
                            (dev.motor->getFieldWeakening() ? 0x02 : 0x00) |
                            (savedModeBeforeCollision == ControlType::CURRENT ? 0x04 : 0x00) |
                            (savedModeBeforeCollision == ControlType::POSITION ? 0x08 : 0x00);
            can.sendStatus(static_cast<uint8_t>(dev.state), flags,
                           RB_popVelocityTelemetryRpm(), dev.motor->getUq(),
                           dev.encoder->getRawCounts());
            // Gói 0x109 gửi mọi lúc (kể cả IDLE) để GUI hiện góc khi xoay tay tìm vị trí đặt góc 0
            const uint8_t posFlags = static_cast<uint8_t>((dev.posZeroSet ? 0x01 : 0x00) |
                                                          (dev.posCycling ? 0x02 : 0x00) |
                                                          (dev.motor->isPosTrajDone() ? 0x04 : 0x00) |
                                                          ((dev.posHits & 0x0F) << 4));
            const bool posActive = (dev.motor->getControlType() == ControlType::POSITION);
            can.sendPositionStatus(dev.motor->getOutputAngleDeg(),
                                   posActive ? dev.motor->getPosRefDeg() : dev.motor->getOutputAngleDeg(),
                                   dev.posPhase, posFlags);
            telemSlot = 0;
        }
    }

    // 4. Thời gian thực của vòng lặp (gói 0x107). Thiết kế: FOC 200.0 us, PWM 50 us, mất mẫu = 0.
    //    Cùng các số này xem được bằng Live Expressions qua biến lastTiming.
    static uint32_t   lastTimingTick = 0;
    static TimingStats lastTiming{};
    if (currentTick - lastTimingTick >= __TIMING_DIAG_PERIOD_MS) {
        lastTimingTick = currentTick;
        RB_popTimingStats(lastTiming);
        auto to01 = [](float us) -> uint16_t {
            float v = us * 10.0f + 0.5f;
            return static_cast<uint16_t>(v > 65535.0f ? 65535.0f : (v < 0.0f ? 0.0f : v));
        };
        const uint32_t lost = lastTiming.lostSamples;
        can.sendTimingDiag(to01(lastTiming.focPeriodAvg_us), to01(lastTiming.focPeriodMax_us),
                           to01(lastTiming.focExecMax_us), static_cast<uint8_t>(lost > 255u ? 255u : lost),
                           static_cast<uint8_t>(lastTiming.pwmPeriod_us + 0.5f));
    }

#if (__DRV_SPI_CONFIG_ENABLE)
    // 5. Đọc lại cấu hình DRV8301 định kỳ: nếu thanh ghi bị reset (sụt áp PVDD...) mà firmware vẫn
    //    dùng scale của gain cao, dòng thật sẽ lớn hơn dòng đo -> dừng ngay, chờ lệnh Stop/Arm.
    static uint32_t lastDrvCheckTick = 0;
    if (currentTick - lastDrvCheckTick >= __DRV_CHECK_PERIOD_MS) {
        lastDrvCheckTick = currentTick;
        if (!RB_checkPowerStage()) {
            dev.state = SystemState::ERROR;
        }
    }
#endif
}
