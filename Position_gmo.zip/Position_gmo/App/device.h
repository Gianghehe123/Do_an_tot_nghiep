// App/device.h
#pragma once
#include "systemConfig.h"
#include "FOCLib/MotorController/motor.h"
#include "Libs/can.h"

enum class SystemState : uint8_t {
    IDLE           = 0,
    CALIBRATING    = 1,
    RUNNING        = 2,
    COLLISION_STOP = 3,
    ERROR          = 4
};

// Pha của chế độ vị trí (cánh tay gạt). ISR ghi, loop()/GUI chỉ đọc.
enum class PosPhase : uint8_t {
    OFF            = 0,   // không ở chế độ vị trí
    HOLD           = 1,   // đứng giữ tại chỗ, chờ lệnh
    HOMING         = 2,   // đang về góc 0 (lệnh Về 0, hoặc trước khi bắt đầu chu trình)
    OUT            = 3,   // hành trình đi: 0 -> góc đích
    DWELL_TARGET   = 4,   // dừng ở góc đích
    BACK           = 5,   // hành trình về: góc đích -> 0
    DWELL_ZERO     = 6,   // dừng ở góc 0
    RETRACT        = 7,   // va chạm khi đang chạy: dừng và rút về điểm bắt đầu hành trình
    WAIT_AFTER_HIT = 8    // đã rút về, chờ __POS_COLLISION_WAIT_MS rồi chạy tiếp
};
constexpr uint8_t POS_REQ_NONE  = 0;
constexpr uint8_t POS_REQ_CYCLE = 1;   // về 0 (nếu đang lệch) rồi chạy chu trình 0 -> đích -> 0 lặp lại
constexpr uint8_t POS_REQ_HOME  = 2;   // về 0 rồi đứng giữ

struct Device {
    Motor*                 motor{nullptr};
    AS5047P*               encoder{nullptr};
    CurrentSensorInjected* currentSensor{nullptr};
    DRV8301Driver*         driver{nullptr};
    CANInterface*          can{nullptr};

    volatile SystemState state{SystemState::IDLE};
    volatile bool        controlLoopEnabled{false};

    // Dữ liệu Telemetry & GMO dùng chung giữa ISR và loop()
    volatile float   idTelemetry{0.0f};   // LPF 10 Hz - dùng cho GMO và phản hồi MIT
    volatile float   iqTelemetry{0.0f};
    volatile float   tauExtEst_Nm{0.0f};
    volatile uint32_t runStartTick_ms{0};
    volatile uint32_t collisionStartTick_ms{0};
    volatile uint8_t  countdown_sec{0};

    // Chẩn đoán
    volatile uint32_t focCount{0};        // số vòng FOC đã chạy (xem bằng Live Expressions)
    volatile uint16_t encDiag{0xFFFF};    // DIAAGC của AS5047P (0xFFFF = chưa đọc được)
    volatile bool     drvConfigOk{false}; // DRV8301 đã xác nhận gain qua SPI
    volatile bool     offsetCalOk{false}; // lần hiệu chỉnh offset dòng gần nhất có thành công không
    volatile bool     currentZeroFault{false}; // đứng yên + DISABLED mà vẫn đo thấy dòng lớn -> cấm chạy

    volatile float   gmoThreshold_Nm{__GMO_THRESHOLD_NM}; // Ngưỡng va chạm động (chỉnh từ GUI qua lệnh 0x08)

    // Chế độ vị trí: loop() ghi giá trị đặt + yêu cầu, ISR (bộ điều phối) thực hiện. float 32 bit đọc/ghi nguyên tử.
    volatile float    posSpeed_degS{__POS_SPEED_DEFAULT_DEG_S};   // lệnh 0x0A
    volatile float    posTarget_deg{__POS_TARGET_DEFAULT_DEG};    // lệnh 0x0B
    volatile uint8_t  posRequest{POS_REQ_NONE};                   // lệnh 0x0D
    volatile uint8_t  posPhase{0};                                // PosPhase
    volatile bool     posCycling{false};      // đang chạy chu trình -> sau va chạm sẽ chạy tiếp
    volatile bool     posZeroSet{false};      // đã đặt góc 0 trong phiên này (lệnh 0x0C)
    volatile uint16_t posHits{0};             // số lần va chạm trong chế độ vị trí
    volatile uint8_t  posCountdown_sec{0};    // đếm ngược ở pha WAIT_AFTER_HIT
};

inline Device dev;

// Thống kê thời gian thực của vòng lặp trong một cửa sổ (đo bằng bộ đếm chu kỳ DWT)
struct TimingStats {
    float    focPeriodAvg_us{0.0f};   // khoảng cách TB giữa 2 vòng FOC (thiết kế: 200 us @5 kHz)
    float    focPeriodMax_us{0.0f};
    float    focExecMax_us{0.0f};     // thời gian chạy dài nhất của nhánh FOC+GMO trong callback ADC
    float    pwmPeriod_us{0.0f};      // tính từ thanh ghi TIM1 (thiết kế: 50 us @20 kHz)
    uint32_t focCycles{0};
    uint32_t lostSamples{0};          // số trigger ADC bị mất (ISR quá giờ)
    uint32_t gaps{0};                 // số lần gián đoạn dài (hiệu chỉnh, reset) - không tính là mất mẫu
};

/* ============ PROTOTYPES TẦNG 2 ============ */
void RB_initMotor();
void RB_startControlClock();
void RB_stopControlClock();
void RB_updateMotor(float dt_sec);          // dt_sec = thời gian thực kể từ vòng FOC trước
void RB_observeCollision(float dt_sec);
void RB_updatePositionSequencer(float dt_sec);   // bộ điều phối chế độ vị trí, chạy trong ISR sau GMO
void RB_popTimingStats(TimingStats& out);   // đọc + xóa thống kê thời gian (gọi trong loop())
void RB_runEncoderCalibrationBlocking();

// Reset tầng công suất: ép DISABLED -> EN_GATE reset -> ghi lại cấu hình DRV8301 -> cập nhật scale dòng
// -> hiệu chỉnh offset với cầu Hi-Z. Dùng thay cho mọi lời gọi driver->resetGateBlocking() trực tiếp.
void RB_resetPowerStage();
// Gọi định kỳ trong loop(): đọc lại thanh ghi DRV8301; sai -> trả về false (đã ép DISABLED).
bool RB_checkPowerStage();

// Telemetry: trung bình khối giữa 2 lần gửi (chống aliasing khi lấy mẫu 22 Hz một tín hiệu 5 kHz)
void  RB_popCurrentTelemetry(float& id_A, float& iq_A);
float RB_popVelocityTelemetryRpm();


bool RB_loadParamFromFlash();               // Đọc zeroOffset + LUT 128 điểm từ Flash lúc khởi động (Mục 5 & 11 .MD)
bool RB_saveParamToFlash(float zeroOffset, const float* lut);
void RB_recoverFromCollision();             // Phục hồi sau va chạm GMO mà KHÔNG kéo EN_GATE xuống thấp
