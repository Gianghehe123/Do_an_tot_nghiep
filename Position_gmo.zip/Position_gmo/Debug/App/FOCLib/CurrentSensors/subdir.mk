################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../App/FOCLib/CurrentSensors/currentSensorInjected.cpp 

OBJS += \
./App/FOCLib/CurrentSensors/currentSensorInjected.o 

CPP_DEPS += \
./App/FOCLib/CurrentSensors/currentSensorInjected.d 


# Each subdirectory must supply rules for building sources it contributes
App/FOCLib/CurrentSensors/%.o App/FOCLib/CurrentSensors/%.su App/FOCLib/CurrentSensors/%.cyclo: ../App/FOCLib/CurrentSensors/%.cpp App/FOCLib/CurrentSensors/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++17 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F405xx -c -I../Core/Inc -I"C:/Users/giang/Desktop/GMO/App" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-App-2f-FOCLib-2f-CurrentSensors

clean-App-2f-FOCLib-2f-CurrentSensors:
	-$(RM) ./App/FOCLib/CurrentSensors/currentSensorInjected.cyclo ./App/FOCLib/CurrentSensors/currentSensorInjected.d ./App/FOCLib/CurrentSensors/currentSensorInjected.o ./App/FOCLib/CurrentSensors/currentSensorInjected.su

.PHONY: clean-App-2f-FOCLib-2f-CurrentSensors

