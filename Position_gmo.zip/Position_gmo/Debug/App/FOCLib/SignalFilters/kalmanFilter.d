App/FOCLib/SignalFilters/kalmanFilter.o: \
 ../App/FOCLib/SignalFilters/kalmanFilter.cpp \
 ../App/FOCLib/SignalFilters/kalmanFilter.h
../App/FOCLib/SignalFilters/kalmanFilter.h:
