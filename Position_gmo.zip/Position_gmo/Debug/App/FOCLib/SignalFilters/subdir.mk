################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../App/FOCLib/SignalFilters/kalmanFilter.cpp \
../App/FOCLib/SignalFilters/lowpassFilter.cpp 

OBJS += \
./App/FOCLib/SignalFilters/kalmanFilter.o \
./App/FOCLib/SignalFilters/lowpassFilter.o 

CPP_DEPS += \
./App/FOCLib/SignalFilters/kalmanFilter.d \
./App/FOCLib/SignalFilters/lowpassFilter.d 


# Each subdirectory must supply rules for building sources it contributes
App/FOCLib/SignalFilters/%.o App/FOCLib/SignalFilters/%.su App/FOCLib/SignalFilters/%.cyclo: ../App/FOCLib/SignalFilters/%.cpp App/FOCLib/SignalFilters/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++17 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F405xx -c -I../Core/Inc -I"C:/Users/giang/Desktop/GMO/App" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-App-2f-FOCLib-2f-SignalFilters

clean-App-2f-FOCLib-2f-SignalFilters:
	-$(RM) ./App/FOCLib/SignalFilters/kalmanFilter.cyclo ./App/FOCLib/SignalFilters/kalmanFilter.d ./App/FOCLib/SignalFilters/kalmanFilter.o ./App/FOCLib/SignalFilters/kalmanFilter.su ./App/FOCLib/SignalFilters/lowpassFilter.cyclo ./App/FOCLib/SignalFilters/lowpassFilter.d ./App/FOCLib/SignalFilters/lowpassFilter.o ./App/FOCLib/SignalFilters/lowpassFilter.su

.PHONY: clean-App-2f-FOCLib-2f-SignalFilters

