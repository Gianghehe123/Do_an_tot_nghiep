App/FOCLib/SignalFilters/lowpassFilter.o: \
 ../App/FOCLib/SignalFilters/lowpassFilter.cpp \
 ../App/FOCLib/SignalFilters/lowpassFilter.h
../App/FOCLib/SignalFilters/lowpassFilter.h:
