################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../App/Libs/as5047p.cpp \
../App/Libs/can.cpp 

OBJS += \
./App/Libs/as5047p.o \
./App/Libs/can.o 

CPP_DEPS += \
./App/Libs/as5047p.d \
./App/Libs/can.d 


# Each subdirectory must supply rules for building sources it contributes
App/Libs/%.o App/Libs/%.su App/Libs/%.cyclo: ../App/Libs/%.cpp App/Libs/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++17 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F405xx -c -I../Core/Inc -I"C:/Users/giang/Desktop/GMO/App" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-App-2f-Libs

clean-App-2f-Libs:
	-$(RM) ./App/Libs/as5047p.cyclo ./App/Libs/as5047p.d ./App/Libs/as5047p.o ./App/Libs/as5047p.su ./App/Libs/can.cyclo ./App/Libs/can.d ./App/Libs/can.o ./App/Libs/can.su

.PHONY: clean-App-2f-Libs

