#include "can_bus.h"
#include <cstring>

CANBus::CANBus(CAN_HandleTypeDef* hcan) : hcan_(hcan) {}

bool CANBus::init() {
    CAN_FilterTypeDef filter;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = 0x0000;
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = 0x0000;
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14;

    if (HAL_CAN_ConfigFilter(hcan_, &filter) != HAL_OK) return false;
    return (HAL_CAN_Start(hcan_) == HAL_OK);
}

bool CANBus::receiveCommand(uint16_t target_id, uint8_t& out_cmd_id, float& out_payload) {
    if (HAL_CAN_GetRxFifoFillLevel(hcan_, CAN_RX_FIFO0) > 0) {
        CAN_RxHeaderTypeDef rx_header;
        uint8_t rx_data[8];

        if (HAL_CAN_GetRxMessage(hcan_, CAN_RX_FIFO0, &rx_header, rx_data) == HAL_OK) {
            if (rx_header.IDE == CAN_ID_STD && rx_header.StdId == target_id && rx_header.DLC >= 1) {
                out_cmd_id = rx_data[0];
                if (rx_header.DLC >= 5) {
                    std::memcpy(&out_payload, &rx_data[1], sizeof(float));
                } else {
                    out_payload = 0.0f;
                }
                return true;
            }
        }
    }
    return false;
}

bool CANBus::sendFOCStatus(uint16_t std_id, uint8_t state, uint8_t err_code, float actual_rpm, float vq) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = std_id & 0x7FF;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = state;
    tx_data[1] = err_code;

    int16_t rpm_scaled = static_cast<int16_t>(actual_rpm * 10.0f);
    int16_t vq_scaled  = static_cast<int16_t>(vq * 100.0f);

    std::memcpy(&tx_data[2], &rpm_scaled, sizeof(int16_t));
    std::memcpy(&tx_data[4], &vq_scaled, sizeof(int16_t));
    tx_data[6] = 0;
    tx_data[7] = 0;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}

bool CANBus::sendGMOTelemetry(uint16_t std_id, float iq, float te, float tau_ext, uint8_t col_status, uint8_t countdown_tenths) {
    CAN_TxHeaderTypeDef tx_header;
    uint8_t tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = std_id & 0x7FF;
    tx_header.ExtId              = 0;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    int16_t iq_ma      = static_cast<int16_t>(iq * 1000.0f);      // mA
    int16_t te_mnm     = static_cast<int16_t>(te * 1000.0f);      // mNm
    int16_t tau_mnm    = static_cast<int16_t>(tau_ext * 1000.0f); // mNm

    std::memcpy(&tx_data[0], &iq_ma, sizeof(int16_t));
    std::memcpy(&tx_data[2], &te_mnm, sizeof(int16_t));
    std::memcpy(&tx_data[4], &tau_mnm, sizeof(int16_t));
    tx_data[6] = col_status;
    tx_data[7] = countdown_tenths;

    if (HAL_CAN_GetTxMailboxesFreeLevel(hcan_) > 0) {
        return (HAL_CAN_AddTxMessage(hcan_, &tx_header, tx_data, &tx_mailbox) == HAL_OK);
    }
    return false;
}
