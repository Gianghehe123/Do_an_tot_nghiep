#pragma once

#include "main.h"
#include "as5047p.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

enum class FOCState : uint8_t {
    IDLE = 0,
    ALIGNING = 1,
    RUNNING = 2,
    ERROR_STATE = 3
};

enum class FOCMode : uint8_t {
    SPEED = 0,
    DUTY = 1
};

namespace FOCError {
    constexpr uint8_t NONE           = 0x00;
    constexpr uint8_t ENCODER_FAIL   = 0x01;
    constexpr uint8_t GATE_DISABLED  = 0x02;
    constexpr uint8_t TARGET_IS_ZERO = 0x04;
    constexpr uint8_t NOT_ALIGNED    = 0x08;
    constexpr uint8_t VOLTAGE_SAT    = 0x10;
    constexpr uint8_t COLLISION_HIT  = 0x40;
}

class FOCController {
public:
    FOCController(TIM_HandleTypeDef* htim, AS5047P* encoder,
                  ADC_HandleTypeDef* hadc1, ADC_HandleTypeDef* hadc2,
                  GPIO_TypeDef* gate_port, uint16_t gate_pin,
                  uint8_t pole_pairs = 21, float vbus = 48.0f);

    void init();
    void arm();
    void disarm();
    void setMode(FOCMode mode);
    void setTargetRPM(float rpm);
    void setTargetDuty(float duty_percent);
    void calibrateCurrentOffset();

    void update(float dt);

    // Trích xuất dữ liệu Telemetry cho CAN
    void getFilteredTelemetry(float& out_id, float& out_iq, float& out_te, float& out_tau_ext,
                              uint8_t& out_col_status, uint8_t& out_countdown_tenths);

    FOCState getState() const { return state_; }
    FOCMode  getMode() const { return mode_; }
    uint8_t  getErrorCode() const { return error_code_; }
    float    getTargetRPM() const { return target_rpm_; }
    float    getTargetDuty() const { return target_duty_; }
    float    getActualRPM() const { return actual_rpm_; }
    float    getVq() const { return vq_; }

private:
    TIM_HandleTypeDef* htim_;
    AS5047P*           encoder_;
    ADC_HandleTypeDef* hadc1_;
    ADC_HandleTypeDef* hadc2_;
    GPIO_TypeDef*      gate_port_;
    uint16_t           gate_pin_;
    uint8_t            pole_pairs_;
    float              vbus_;

    FOCState state_{FOCState::IDLE};
    FOCMode  mode_{FOCMode::SPEED};
    uint8_t  error_code_{FOCError::NONE};

    // Shunt Calib
    uint16_t adc_offset_b_{2048};
    uint16_t adc_offset_c_{2048};
    float current_scale_{0.16117f}; // Ampe / LSB[cite: 1]

    float inst_id_{0.0f};
    float inst_iq_{0.0f};

    // --- THAM SỐ VẬT LÝ & GMO ---
    float kt_{0.0955f};             // Hằng số mô-men Kt (Nm/A)[cite: 10]
    float j_total_{0.00025f};        // Quán tính quy đổi rotor
    float tau_c_{0.012f};           // Ma sát Coulomb hộp số
    float b_fric_{0.00035f};        // Ma sát nhớt
    float ko_{55.0f};               // Băng thông GMO (tăng lên để bắt va chạm nhạy)

    // Ngưỡng chạm nhẹ & Nhận biết thả tay
    float collision_thresh_{0.1f}; // Ngưỡng chạm
    float release_thresh_{0.05f};   // Ngưỡng nhận biết đã thả tay: 0.015 Nm
    float pause_v_limit_{0.01f};     // Giới hạn áp khi dừng để ăn dòng <= 0.1A

    float z_gmo_{0.0f};
    float tau_ext_{0.0f};
    float te_instant_{0.0f};

    // Quản lý trạng thái dừng do va chạm
    bool     is_paused_collision_{false};
    uint8_t  hit_debounce_{0};
    float    release_timer_{0.0f};
    float    saved_target_rpm_{0.0f};
    float    saved_target_duty_{0.0f};

    // Bộ lọc tích lũy CAN
    uint32_t telem_count_{0};
    float    telem_sum_id_{0.0f};
    float    telem_sum_iq_{0.0f};
    float    telem_sum_te_{0.0f};
    float    telem_sum_tau_ext_{0.0f};

    // Điều khiển vận tốc
    float target_rpm_{0.0f};
    float current_target_rpm_{0.0f};
    float target_duty_{0.0f};
    float actual_rpm_{0.0f};
    float zero_elec_offset_{0.0f};
    float prev_mech_rad_{0.0f};

    float kp_{0.08f};
    float ki_{0.4f};
    float integral_err_{0.0f};
    float vq_{0.0f};
    float v_limit_{12.0f};

    uint32_t align_start_tick_{0};

    void sampleCurrents(float theta_e);
    void updateGMO(float dt, float omega_rad_s);
    void applySVPWM(float vd, float vq, float theta_e);
    void setPWMDuty(float duty_u, float duty_v, float duty_w);
};
