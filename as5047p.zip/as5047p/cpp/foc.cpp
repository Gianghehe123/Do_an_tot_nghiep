#include "foc.h"
#include <algorithm>

FOCController::FOCController(TIM_HandleTypeDef* htim, AS5047P* encoder,
                             ADC_HandleTypeDef* hadc1, ADC_HandleTypeDef* hadc2,
                             GPIO_TypeDef* gate_port, uint16_t gate_pin,
                             uint8_t pole_pairs, float vbus)
    : htim_(htim), encoder_(encoder), hadc1_(hadc1), hadc2_(hadc2),
      gate_port_(gate_port), gate_pin_(gate_pin), pole_pairs_(pole_pairs), vbus_(vbus) {}

void FOCController::init() {
    HAL_GPIO_WritePin(gate_port_, gate_pin_, GPIO_PIN_SET);
    HAL_Delay(100);

    HAL_ADCEx_InjectedStart(hadc1_);
    HAL_ADCEx_InjectedStart(hadc2_);

    HAL_TIM_PWM_Start(htim_, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(htim_, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(htim_, TIM_CHANNEL_3);
    HAL_TIMEx_PWMN_Start(htim_, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(htim_, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(htim_, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(htim_, TIM_CHANNEL_4); // Trigger ADC Injected 20kHz[cite: 27]

    disarm();
    calibrateCurrentOffset();
}

void FOCController::calibrateCurrentOffset() {
    setPWMDuty(0.5f, 0.5f, 0.5f);
    HAL_Delay(50);

    uint32_t sum_b = 0;
    uint32_t sum_c = 0;
    for (int i = 0; i < 300; ++i) {
        sum_b += HAL_ADCEx_InjectedGetValue(hadc1_, ADC_INJECTED_RANK_1);
        sum_c += HAL_ADCEx_InjectedGetValue(hadc2_, ADC_INJECTED_RANK_1);
        HAL_Delay(1);
    }
    adc_offset_b_ = static_cast<uint16_t>(sum_b / 300);
    adc_offset_c_ = static_cast<uint16_t>(sum_c / 300);
}

void FOCController::sampleCurrents(float theta_e) {
    uint16_t raw_b = HAL_ADCEx_InjectedGetValue(hadc1_, ADC_INJECTED_RANK_1);
    uint16_t raw_c = HAL_ADCEx_InjectedGetValue(hadc2_, ADC_INJECTED_RANK_1);

    float ib = (static_cast<float>(raw_b) - static_cast<float>(adc_offset_b_)) * current_scale_;
    float ic = (static_cast<float>(raw_c) - static_cast<float>(adc_offset_c_)) * current_scale_;
    float ia = -(ib + ic);

    float i_alpha = ia;
    float i_beta  = (ib - ic) * 0.57735027f;

    float cos_th = std::cos(theta_e);
    float sin_th = std::sin(theta_e);
    inst_id_ =  i_alpha * cos_th + i_beta * sin_th;
    inst_iq_ = -i_alpha * sin_th + i_beta * cos_th;

    te_instant_ = kt_ * inst_iq_;
}

void FOCController::updateGMO(float dt, float omega_rad_s) {
    // 1. Mô-men ma sát bù trừ
    float tau_fric = 0.0f;
    if (std::abs(omega_rad_s) > 0.3f) {
        tau_fric = tau_c_ * ((omega_rad_s > 0.0f) ? 1.0f : -1.0f) + b_fric_ * omega_rad_s;
    }

    // 2. Thuật toán vi phân động lượng GMO
    float p_rotor = j_total_ * omega_rad_s;
    float r_instant = ko_ * (p_rotor - z_gmo_);
    z_gmo_ += (te_instant_ - tau_fric + r_instant) * dt;
    tau_ext_ = r_instant;

    // 3. Máy trạng thái phát hiện chạm nhẹ & Đếm lùi tự động chạy tiếp
    if (state_ == FOCState::RUNNING) {
        if (!is_paused_collision_) {
            // Đang chạy bình thường: Bắt chạm nhẹ
            if (std::abs(tau_ext_) > collision_thresh_) {
                hit_debounce_++;
                if (hit_debounce_ >= 3) { // 3 ms liên tiếp -> xác nhận chạm tay
                    is_paused_collision_ = true;
                    release_timer_ = 0.0f;
                    saved_target_rpm_  = target_rpm_;
                    saved_target_duty_ = target_duty_;
                    current_target_rpm_ = 0.0f;
                    integral_err_ = 0.0f;
                    error_code_ |= FOCError::COLLISION_HIT;
                }
            } else {
                hit_debounce_ = 0;
                error_code_ &= ~FOCError::COLLISION_HIT;
            }
        }
        else {
            // Đang tạm dừng: Kiểm tra xem đã thả tay chưa
            if (std::abs(tau_ext_) < release_thresh_ && std::abs(actual_rpm_) < 5.0f) {
                // Đã thả tay: Bắt đầu tích lũy thời gian nghỉ 3 giây
                release_timer_ += dt;
                if (release_timer_ >= 3.0f) {
                    // Đã qua 3 giây từ lúc thả tay -> Tự động chạy tiếp!
                    is_paused_collision_ = false;
                    target_rpm_  = saved_target_rpm_;
                    target_duty_ = saved_target_duty_;
                    release_timer_ = 0.0f;
                    hit_debounce_  = 0;
                    error_code_ &= ~FOCError::COLLISION_HIT;
                }
            } else {
                // Tay vẫn còn chạm/chặn trục: Giữ nguyên dừng, reset bộ đếm 3s
                release_timer_ = 0.0f;
            }
        }
    }

    // Tích lũy Telemetry
    telem_sum_id_      += inst_id_;
    telem_sum_iq_      += inst_iq_;
    telem_sum_te_      += te_instant_;
    telem_sum_tau_ext_ += tau_ext_;
    telem_count_++;
}

void FOCController::getFilteredTelemetry(float& out_id, float& out_iq, float& out_te, float& out_tau_ext,
                                        uint8_t& out_col_status, uint8_t& out_countdown_tenths) {
    if (telem_count_ > 0) {
        out_id      = telem_sum_id_ / static_cast<float>(telem_count_);
        out_iq      = telem_sum_iq_ / static_cast<float>(telem_count_);
        out_te      = telem_sum_te_ / static_cast<float>(telem_count_);
        out_tau_ext = telem_sum_tau_ext_ / static_cast<float>(telem_count_);

        if (!is_paused_collision_) {
            out_col_status = 0; // Bình thường
            out_countdown_tenths = 0;
        } else {
            if (release_timer_ <= 0.05f) {
                out_col_status = 1; // Đang bị chạm / giữ tay
                out_countdown_tenths = 30;
            } else {
                out_col_status = 2; // Đã thả tay, đang đếm ngược 3s
                float remain = std::max(0.0f, 3.0f - release_timer_);
                out_countdown_tenths = static_cast<uint8_t>(remain * 10.0f);
            }
        }

        telem_sum_id_      = 0.0f;
        telem_sum_iq_      = 0.0f;
        telem_sum_te_      = 0.0f;
        telem_sum_tau_ext_ = 0.0f;
        telem_count_       = 0;
    } else {
        out_id = 0.0f; out_iq = 0.0f; out_te = 0.0f; out_tau_ext = 0.0f;
        out_col_status = 0; out_countdown_tenths = 0;
    }
}

void FOCController::arm() {
    if (state_ == FOCState::IDLE || state_ == FOCState::ERROR_STATE) {
        state_ = FOCState::ALIGNING;
        align_start_tick_ = HAL_GetTick();
        integral_err_ = 0.0f;
        z_gmo_ = 0.0f;
        tau_ext_ = 0.0f;
        is_paused_collision_ = false;
        release_timer_ = 0.0f;
        hit_debounce_ = 0;
    }
}

void FOCController::disarm() {
    state_ = FOCState::IDLE;
    target_rpm_ = 0.0f;
    current_target_rpm_ = 0.0f;
    target_duty_ = 0.0f;
    integral_err_ = 0.0f;
    vq_ = 0.0f;
    z_gmo_ = 0.0f;
    tau_ext_ = 0.0f;
    is_paused_collision_ = false;
    release_timer_ = 0.0f;
    hit_debounce_ = 0;
    setPWMDuty(0.5f, 0.5f, 0.5f);
}

void FOCController::setMode(FOCMode mode) {
    mode_ = mode;
    target_rpm_ = 0.0f;
    current_target_rpm_ = 0.0f;
    target_duty_ = 0.0f;
    integral_err_ = 0.0f;
    vq_ = 0.0f;
    z_gmo_ = 0.0f;
    is_paused_collision_ = false;
}

void FOCController::setTargetRPM(float rpm) {
    target_rpm_ = rpm;
    if (is_paused_collision_) saved_target_rpm_ = rpm;
}

void FOCController::setTargetDuty(float duty_percent) {
    target_duty_ = std::max(-100.0f, std::min(duty_percent, 100.0f));
    if (is_paused_collision_) saved_target_duty_ = target_duty_;
}

void FOCController::update(float dt) {
    if (encoder_->isError()) {
        error_code_ |= FOCError::ENCODER_FAIL;
        disarm();
        state_ = FOCState::ERROR_STATE;
        return;
    } else {
        error_code_ &= ~FOCError::ENCODER_FAIL;
    }

    float raw_elec_rad = (encoder_->getMechanicalAngleDeg() * static_cast<float>(pole_pairs_)) * (M_PI / 180.0f);
    float theta_e = raw_elec_rad - zero_elec_offset_;
    while (theta_e >= 2.0f * M_PI) theta_e -= 2.0f * M_PI;
    while (theta_e < 0.0f) theta_e += 2.0f * M_PI;

    sampleCurrents(theta_e);

    float current_mech_rad = encoder_->getMechanicalAngleDeg() * (M_PI / 180.0f);
    float d_theta = current_mech_rad - prev_mech_rad_;
    if (d_theta > M_PI) d_theta -= 2.0f * M_PI;
    if (d_theta < -M_PI) d_theta += 2.0f * M_PI;
    prev_mech_rad_ = current_mech_rad;

    float omega_mech_rad_s = d_theta / dt;
    float raw_rpm = omega_mech_rad_s * (60.0f / (2.0f * M_PI));
    actual_rpm_ += 0.15f * (raw_rpm - actual_rpm_);

    float actual_rad_s = actual_rpm_ * (2.0f * M_PI / 60.0f);
    updateGMO(dt, actual_rad_s);

    switch (state_) {
        case FOCState::IDLE:
            setPWMDuty(0.5f, 0.5f, 0.5f);
            break;

        case FOCState::ALIGNING: {
            applySVPWM(2.0f, 0.0f, 0.0f);
            if (HAL_GetTick() - align_start_tick_ >= 1000) {
                float mech_deg = encoder_->getMechanicalAngleDeg();
                zero_elec_offset_ = std::fmod(mech_deg * static_cast<float>(pole_pairs_) * (M_PI / 180.0f), 2.0f * M_PI);
                state_ = FOCState::RUNNING;
            }
            break;
        }

        case FOCState::RUNNING: {
            // NẾU ĐANG TRONG TRẠNG THÁI TẠM DỪNG VA CHẠM:
            // Khóa chặt điện áp ở mức 0.08V (để dòng điện tối đa chỉ đạt <= 0.1A)
            if (is_paused_collision_) {
                float speed_error = 0.0f - actual_rpm_;
                integral_err_ += ki_ * speed_error * dt;
                integral_err_ = std::max(-pause_v_limit_, std::min(integral_err_, pause_v_limit_));

                vq_ = (kp_ * speed_error) + integral_err_;
                vq_ = std::max(-pause_v_limit_, std::min(vq_, pause_v_limit_));

                applySVPWM(0.0f, vq_, theta_e);
            }
            else {
                // CHẠY BÌNH THƯỜNG (Êm ru như cũ)[cite: 8]
                if (mode_ == FOCMode::SPEED) {
                    float ramp_rate = 150.0f * dt;
                    if (current_target_rpm_ < target_rpm_) current_target_rpm_ = std::min(current_target_rpm_ + ramp_rate, target_rpm_);
                    else if (current_target_rpm_ > target_rpm_) current_target_rpm_ = std::max(current_target_rpm_ - ramp_rate, target_rpm_);

                    float speed_error = current_target_rpm_ - actual_rpm_;
                    integral_err_ += ki_ * speed_error * dt;
                    integral_err_ = std::max(-v_limit_, std::min(integral_err_, v_limit_));

                    vq_ = (kp_ * speed_error) + integral_err_;
                    vq_ = std::max(-v_limit_, std::min(vq_, v_limit_));

                    applySVPWM(0.0f, vq_, theta_e);
                } else {
                    vq_ = (target_duty_ / 100.0f) * (vbus_ * 0.57735f);
                    applySVPWM(0.0f, vq_, theta_e);
                }
            }
            break;
        }

        case FOCState::ERROR_STATE:
            setPWMDuty(0.5f, 0.5f, 0.5f);
            break;
    }

    if (HAL_GPIO_ReadPin(gate_port_, gate_pin_) != GPIO_PIN_SET) {
        error_code_ |= FOCError::GATE_DISABLED;
    } else {
        error_code_ &= ~FOCError::GATE_DISABLED;
    }
}

void FOCController::applySVPWM(float vd, float vq, float theta_e) {
    float cos_th = std::cos(theta_e);
    float sin_th = std::sin(theta_e);
    float v_alpha = vd * cos_th - vq * sin_th;
    float v_beta  = vd * sin_th + vq * cos_th;

    float v_a = v_alpha;
    float v_b = -0.5f * v_alpha + 0.8660254f * v_beta;
    float v_c = -0.5f * v_alpha - 0.8660254f * v_beta;

    float v_min = std::min({v_a, v_b, v_c});
    float v_max = std::max({v_a, v_b, v_c});
    float v_center = 0.5f * (v_max + v_min);

    float duty_u = (v_a - v_center) / vbus_ + 0.5f;
    float duty_v = (v_b - v_center) / vbus_ + 0.5f;
    float duty_w = (v_c - v_center) / vbus_ + 0.5f;

    setPWMDuty(duty_u, duty_v, duty_w);
}

void FOCController::setPWMDuty(float duty_u, float duty_v, float duty_w) {
    duty_u = std::max(0.02f, std::min(duty_u, 0.98f));
    duty_v = std::max(0.02f, std::min(duty_v, 0.98f));
    duty_w = std::max(0.02f, std::min(duty_w, 0.98f));

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(htim_);
    __HAL_TIM_SET_COMPARE(htim_, TIM_CHANNEL_1, static_cast<uint32_t>(duty_u * arr));
    __HAL_TIM_SET_COMPARE(htim_, TIM_CHANNEL_2, static_cast<uint32_t>(duty_v * arr));
    __HAL_TIM_SET_COMPARE(htim_, TIM_CHANNEL_3, static_cast<uint32_t>(duty_w * arr));
}
