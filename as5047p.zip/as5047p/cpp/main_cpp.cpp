#include "main_cpp.h"
#include "as5047p.h"
#include "can_bus.h"
#include "foc.h"

extern SPI_HandleTypeDef hspi1;
extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;

static AS5047P encoder(&hspi1, GPIOA, GPIO_PIN_15, 21);
static CANBus  can(&hcan1);
static FOCController foc(&htim1, &encoder, &hadc1, &hadc2, GPIOB, GPIO_PIN_12, 21, 48.0f);

void run_loop(void) {
    encoder.init();
    can.init();
    foc.init();

    uint32_t last_foc_tick = 0;
    uint32_t last_status_tick = 0;
    uint8_t cmd_id = 0;
    float   cmd_payload = 0.0f;

    while (1) {
        uint32_t current_tick = HAL_GetTick();

        // 1. Vòng lặp FOC và GMO chạy ở 1 kHz
        if (current_tick - last_foc_tick >= 1) {
            last_foc_tick = current_tick;
            encoder.update();
            foc.update(0.001f);
        }

        // 2. Nhận lệnh CAN
        if (can.receiveCommand(0x100, cmd_id, cmd_payload)) {
            switch (cmd_id) {
                case 0x01: foc.disarm(); break;
                case 0x02: foc.arm(); break;
                case 0x03:
                    if (foc.getMode() == FOCMode::SPEED) foc.setTargetRPM(cmd_payload);
                    else foc.setTargetDuty(cmd_payload);
                    break;
                case 0x04: {
                    float fid, fiq, fte, ftau; uint8_t fcol_st, fcount;
                    foc.getFilteredTelemetry(fid, fiq, fte, ftau, fcol_st, fcount);
                    can.sendFOCStatus(0x102, static_cast<uint8_t>(foc.getState()), foc.getErrorCode(), foc.getActualRPM(), foc.getVq());
                    can.sendGMOTelemetry(0x103, fiq, fte, ftau, fcol_st, fcount);
                    break;
                }
                case 0x05:
                    foc.setMode((cmd_payload > 0.5f) ? FOCMode::DUTY : FOCMode::SPEED);
                    break;
                case 0x06:
                    foc.calibrateCurrentOffset();
                    break;
                default: break;
            }
        }

        // 3. Gửi Telemetry 20Hz (50ms)
        if (current_tick - last_status_tick >= 50) {
            last_status_tick = current_tick;
            float fid, fiq, fte, ftau; uint8_t fcol_st, fcount;
            foc.getFilteredTelemetry(fid, fiq, fte, ftau, fcol_st, fcount);

            can.sendFOCStatus(0x102, static_cast<uint8_t>(foc.getState()), foc.getErrorCode(), foc.getActualRPM(), foc.getVq());
            can.sendGMOTelemetry(0x103, fiq, fte, ftau, fcol_st, fcount);
        }
    }
}
