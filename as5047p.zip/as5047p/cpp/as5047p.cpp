#include "as5047p.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

AS5047P::AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs)
    : hspi_(hspi), cs_port_(cs_port), cs_pin_(cs_pin), pole_pairs_(pole_pairs) {}

void AS5047P::init() {
    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_SET);
    HAL_Delay(10);
    readRegister(CMD_ANGLECOM);
    first_run_ = true;
}

bool AS5047P::checkParity(uint16_t data) {
    uint8_t count = 0;
    for (int i = 0; i < 16; ++i) {
        if (data & (1 << i)) count++;
    }
    return (count % 2 == 0);
}

uint16_t AS5047P::readRegister(uint16_t cmd) {
    uint16_t rx_data = 0;

    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_RESET);
    // Độ trễ phần cứng đảm bảo CS ổn định
    for(volatile int i = 0; i < 10; ++i);

    HAL_SPI_TransmitReceive(hspi_, reinterpret_cast<uint8_t*>(&cmd),
                            reinterpret_cast<uint8_t*>(&rx_data), 1, 10);

    HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_SET);
    // Đảm bảo thời gian nghỉ t_CSn >= 350ns trước lệnh kế tiếp
    for(volatile int i = 0; i < 20; ++i);

    return rx_data;
}

bool AS5047P::update() {
    uint16_t rx_data = readRegister(CMD_ANGLECOM);
    if ((rx_data & (1 << 14)) || !checkParity(rx_data)) {
        has_error_ = true;
        return false;
    }

    has_error_ = false;
    raw_data_  = rx_data & 0x3FFF;

    int32_t calib_raw = static_cast<int32_t>(raw_data_) - zero_offset_;
    if (calib_raw < 0) calib_raw += 16384;

    // 1. Góc cơ học tức thời KHÔNG LỌC (Dùng riêng cho chuyển mạch FOC)
    float instant_mech_deg = (static_cast<float>(calib_raw) / RESOLUTION) * 360.0f;
    mech_angle_deg_ = instant_mech_deg;

    // Góc điện không bị trễ thời gian
    elec_angle_deg_ = std::fmod(instant_mech_deg * static_cast<float>(pole_pairs_), 360.0f);
    if (elec_angle_deg_ < 0.0f) elec_angle_deg_ += 360.0f;
    elec_angle_rad_ = elec_angle_deg_ * (static_cast<float>(M_PI) / 180.0f);

    // 2. Góc cơ lọc (Chỉ dùng để tính vận tốc mượt, không dùng cho FOC)
    float diff = instant_mech_deg - filtered_mech_deg_;
    if (diff > 180.0f) diff -= 360.0f;
    else if (diff < -180.0f) diff += 360.0f;

    filtered_mech_deg_ += 0.25f * diff;
    if (filtered_mech_deg_ >= 360.0f) filtered_mech_deg_ -= 360.0f;
    else if (filtered_mech_deg_ < 0.0f) filtered_mech_deg_ += 360.0f;

    return true;
}

void AS5047P::setZeroOffset() {
    zero_offset_ = raw_data_;
    first_run_   = true;
}

uint16_t AS5047P::getRaw() const { return raw_data_; }
float AS5047P::getMechanicalAngleDeg() const { return mech_angle_deg_; }
float AS5047P::getElectricalAngleDeg() const { return elec_angle_deg_; }
float AS5047P::getElectricalAngleRad() const { return elec_angle_rad_; }
bool AS5047P::isError() const { return has_error_; }
