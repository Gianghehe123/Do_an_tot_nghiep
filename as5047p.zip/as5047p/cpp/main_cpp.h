#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Hàm duy nhất được gọi từ main.c
void run_loop(void);

#ifdef __cplusplus
}
#endif
