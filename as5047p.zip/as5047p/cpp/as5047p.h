#pragma once

#include "main.h"
#include <cstdint>

class AS5047P {
public:
    static constexpr uint16_t CMD_ANGLECOM = 0xFFFF;
    static constexpr float    RESOLUTION   = 16384.0f;

    AS5047P(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin, uint8_t pole_pairs = 21);

    void init();
    bool update();

    uint16_t getRaw() const;
    float    getMechanicalAngleDeg() const;
    float    getElectricalAngleDeg() const;
    float    getElectricalAngleRad() const;
    bool     isError() const;
    void     setZeroOffset();

private:
    SPI_HandleTypeDef* hspi_;
    GPIO_TypeDef*      cs_port_;
    uint16_t           cs_pin_;
    uint8_t            pole_pairs_;

    uint16_t raw_data_{0};
    uint16_t zero_offset_{0};
    float    mech_angle_deg_{0.0f};
    float    elec_angle_deg_{0.0f};
    float    elec_angle_rad_{0.0f};
    bool     has_error_{false};

    // Biến cho bộ lọc
    float    filtered_mech_deg_{0.0f};
    bool     first_run_{true};

    uint16_t readRegister(uint16_t cmd);
    static bool checkParity(uint16_t data);
};
