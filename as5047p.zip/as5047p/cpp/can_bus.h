#pragma once

#include "main.h"
#include <cstdint>

class CANBus {
public:
    explicit CANBus(CAN_HandleTypeDef* hcan);

    bool init();
    bool receiveCommand(uint16_t target_id, uint8_t& out_cmd_id, float& out_payload);
    bool sendFOCStatus(uint16_t std_id, uint8_t state, uint8_t err_code, float actual_rpm, float vq);
    bool sendGMOTelemetry(uint16_t std_id, float iq, float te, float tau_ext, uint8_t col_status, uint8_t countdown_tenths);

private:
    CAN_HandleTypeDef* hcan_;
};
