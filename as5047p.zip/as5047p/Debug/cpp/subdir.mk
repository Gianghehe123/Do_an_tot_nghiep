################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../cpp/as5047p.cpp \
../cpp/can_bus.cpp \
../cpp/foc.cpp \
../cpp/main_cpp.cpp 

OBJS += \
./cpp/as5047p.o \
./cpp/can_bus.o \
./cpp/foc.o \
./cpp/main_cpp.o 

CPP_DEPS += \
./cpp/as5047p.d \
./cpp/can_bus.d \
./cpp/foc.d \
./cpp/main_cpp.d 


# Each subdirectory must supply rules for building sources it contributes
cpp/%.o cpp/%.su cpp/%.cyclo: ../cpp/%.cpp cpp/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F405xx -c -I../Core/Inc -I"C:/Users/giang/Desktop/as5047p/cpp" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-cpp

clean-cpp:
	-$(RM) ./cpp/as5047p.cyclo ./cpp/as5047p.d ./cpp/as5047p.o ./cpp/as5047p.su ./cpp/can_bus.cyclo ./cpp/can_bus.d ./cpp/can_bus.o ./cpp/can_bus.su ./cpp/foc.cyclo ./cpp/foc.d ./cpp/foc.o ./cpp/foc.su ./cpp/main_cpp.cyclo ./cpp/main_cpp.d ./cpp/main_cpp.o ./cpp/main_cpp.su

.PHONY: clean-cpp

