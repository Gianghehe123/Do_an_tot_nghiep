#include "main_cpp.h"
#include "main.h"
#include "uart.h"
#include <cmath>

// Gọi các ngoại vi từ main.c
extern "C" {
    extern UART_HandleTypeDef huart2;
    extern ADC_HandleTypeDef hadc1; // Đọc ADC từ chân PA0
}

// Khởi tạo UART
Uart serial(&huart2);

// Cấu hình thông số BLDC
static const int POLE_PAIRS = 7;        // Số cặp cực của động cơ (thay theo động cơ của bạn)
static const float THETA_OFFSET = 0.0f; // Góc lệch bù ban đầu

void main_cpp(void) {
    serial.println("=== AS5600 Real Angle Reader Started ===");

    while (1) {
        // 1. Kích hoạt và đọc ADC 12-bit (0 - 4095) từ chân PA0
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
            uint32_t adc_val = HAL_ADC_GetValue(&hadc1);

            // 2. Chuyển đổi sang góc cơ (0.0 đến 360.0 độ)
            float mech_angle = ((float)adc_val / 4095.0f) * 360.0f;

            // 3. Tính góc điện: theta_e = (p * theta_m - offset) % 360
            float elec_angle = fmod((POLE_PAIRS * mech_angle - THETA_OFFSET), 360.0f);
            if (elec_angle < 0.0f) {
                elec_angle += 360.0f;
            }

            // 4. In ra Serial để quan sát
            serial.printf("\rADC: %4lu | Mech Angle: %6.2f deg | Elec Angle: %6.2f deg   ",
                          adc_val, mech_angle, elec_angle);
        }
        HAL_ADC_Stop(&hadc1);

        // Lấy mẫu mỗi 50ms (20Hz)
        HAL_Delay(50);
    }
}
