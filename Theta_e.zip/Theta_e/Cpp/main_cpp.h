#ifndef MAIN_CPP_H_
#define MAIN_CPP_H_

#ifdef __cplusplus
extern "C" {
#endif

void main_cpp(void);

#ifdef __cplusplus
}
#endif

#endif /* MAIN_CPP_H_ */
