#include "uart.h"

Uart::Uart(UART_HandleTypeDef* huart_handle) : huart(huart_handle) {}

void Uart::write(const uint8_t* data, uint16_t size, uint32_t timeout) {
    if (huart != nullptr) {
        HAL_UART_Transmit(huart, const_cast<uint8_t*>(data), size, timeout);
    }
}

void Uart::print(const char* str) {
    write(reinterpret_cast<const uint8_t*>(str), strlen(str));
}

void Uart::println(const char* str) {
    print(str);
    print("\r\n");
}

void Uart::printf(const char* format, ...) {
    char buffer[256];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    print(buffer);
}



