#ifndef UART_H_
#define UART_H_

#include "main.h"
#include <cstdarg>
#include <cstdio>
#include <cstring>

class Uart {
private:
    UART_HandleTypeDef* huart;

public:
    explicit Uart(UART_HandleTypeDef* huart_handle);

    void write(const uint8_t* data, uint16_t size, uint32_t timeout = 100);
    void print(const char* str);
    void println(const char* str);
    void printf(const char* format, ...);
};

#endif /* UART_H_ */
