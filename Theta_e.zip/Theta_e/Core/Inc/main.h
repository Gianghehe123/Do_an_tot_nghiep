/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SPI3_nCS_DRV0_Pin GPIO_PIN_13
#define SPI3_nCS_DRV0_GPIO_Port GPIOC
#define SPI3_nCS_DRV1_Pin GPIO_PIN_14
#define SPI3_nCS_DRV1_GPIO_Port GPIOC
#define ADC_Pin GPIO_PIN_0
#define ADC_GPIO_Port GPIOA
#define HALL_Pin GPIO_PIN_1
#define HALL_GPIO_Port GPIOA
#define HALL_EXTI_IRQn EXTI1_IRQn
#define HALLC4_Pin GPIO_PIN_4
#define HALLC4_GPIO_Port GPIOC
#define HALLC4_EXTI_IRQn EXTI4_IRQn
#define M0_Temp_Pin GPIO_PIN_5
#define M0_Temp_GPIO_Port GPIOC
#define DRV_EN_GATE_Pin GPIO_PIN_12
#define DRV_EN_GATE_GPIO_Port GPIOB
#define DRV_GATE_A_Pin GPIO_PIN_13
#define DRV_GATE_A_GPIO_Port GPIOB
#define DRV_GATE_B_Pin GPIO_PIN_14
#define DRV_GATE_B_GPIO_Port GPIOB
#define DRV_GATE_C_Pin GPIO_PIN_15
#define DRV_GATE_C_GPIO_Port GPIOB
#define DRV_nFAULT_Pin GPIO_PIN_2
#define DRV_nFAULT_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
