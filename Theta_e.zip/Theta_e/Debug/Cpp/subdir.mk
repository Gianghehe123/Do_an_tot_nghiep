################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Cpp/main_cpp.cpp \
../Cpp/uart.cpp 

OBJS += \
./Cpp/main_cpp.o \
./Cpp/uart.o 

CPP_DEPS += \
./Cpp/main_cpp.d \
./Cpp/uart.d 


# Each subdirectory must supply rules for building sources it contributes
Cpp/%.o Cpp/%.su Cpp/%.cyclo: ../Cpp/%.cpp Cpp/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F405xx -c -I../Core/Inc -I"C:/Users/giang/Desktop/Theta_e/Cpp" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Cpp

clean-Cpp:
	-$(RM) ./Cpp/main_cpp.cyclo ./Cpp/main_cpp.d ./Cpp/main_cpp.o ./Cpp/main_cpp.su ./Cpp/uart.cyclo ./Cpp/uart.d ./Cpp/uart.o ./Cpp/uart.su

.PHONY: clean-Cpp

